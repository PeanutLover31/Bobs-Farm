import pygame
import time
import random
import json
import os
import math
from datetime import datetime 


pygame.init()

# 
pygame.mixer.init()

# 
plant_sound = pygame.mixer.Sound('plant.mp3')
coin_sound = pygame.mixer.Sound('midas.mp3')
jacko_sound = pygame.mixer.Sound('jacko.mp3')
gjo_sound = pygame.mixer.Sound('gjo.mp3')
mole_sound = pygame.mixer.Sound('mole.mp3')
midas_sound = pygame.mixer.Sound('coin.mp3')
# 

SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 700
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Bob's Farm")

# 
FULLSCREEN = False

#

xp_amount = 0
player_level = 1
xp_to_next_level = 5000
xp_open = False
xp_collection_animations = []

# Halloween Event
halloween_event_active = True
halloween_event_end_date = datetime(2025, 11, 13)  # 13 Kasım'da bitiyor
halloween_tab_open = False
treatcoin_count = 0
halloween_shop_open = False

# Halloween items
carrotcake_count = 0
vodoo_count = 0

# Halloween boxes
halloween_box_animation_active = False
halloween_box_animation_timer = 0
halloween_box_animation_duration = 3.0
halloween_box_reward = None
halloween_box_animation_stage = 0


dog_animation_active = False
dog_animation_timer = 0
dog_animation_duration = 3.0  # 3 saniye
dog_animation_dog_type = None
dog_animation_stage = 0
dog_reward_display_timer = 0
dog_reward_display_duration = 2.0  # Ödül gösterim süresi

xp_button_rect = pygame.Rect(SCREEN_WIDTH - 200, SCREEN_HEIGHT - 50, 32, 32)
xp_reward_button_rect = pygame.Rect(SCREEN_WIDTH - 250, 10, 32, 32)

active_npc = None
npc_spawn_timer = 0
npc_spawn_interval = random.uniform(5, 10) 

wardrobe_current_dog_index = 0 

message_text = ""
message_timer = 0
MESSAGE_DURATION = 2.0  # seconds

LIGHT_GREEN = (144, 238, 144)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BROWN = (139, 69, 19)
GOLDEN_YELLOW = (255, 215, 0)
GREEN_BUTTON = (60, 179, 113)
RED_BUTTON = (220, 20, 60)
BLUE_BUTTON = (65, 105, 225)
TASK_BUTTON = (255, 165, 0)  # 

cotton_count = 0
seed_cotton_count = 5

shop_current_dog_index = 0
vip_current_dog_index = 0
jamal_current_dog_index = 0

# 
GAME_STATE_LOGIN = 0
GAME_STATE_TUTORIAL = 1
GAME_STATE_PLAYING = 2
TASK_MENU_OPEN = 3
FARM_VISIT_MENU = 4  # 
VISITING_FARM = 5     
current_game_state = GAME_STATE_LOGIN  # 
# 
base_character_speed = 200
character_speed = base_character_speed
vip_shop_open = False
ticket_count = 0
# 
COLOR_RANGE_R_MIN = 140
COLOR_RANGE_R_MAX = 145
COLOR_RANGE_G_MIN = 230
COLOR_RANGE_G_MAX = 240
COLOR_RANGE_B_MIN = 140
COLOR_RANGE_B_MAX = 145

# Finansman Sistemi
finance_open = False
finance_current_index = 0
finance_cookie_count = 0
active_finances = []  # Maksimum 2 finansman seçilebilir
finance_button_rect = pygame.Rect(SCREEN_WIDTH - 150, SCREEN_HEIGHT - 50, 32, 32)

def initialize_box_animation():
    global box_animation_active, box_animation_timer, box_animation_duration
    global box_animation_reward, box_animation_box_type, box_animation_stage
    global reward_display_timer, reward_display_duration
    
    box_animation_active = False
    box_animation_timer = 0
    box_animation_duration = 3.0
    box_animation_reward = None
    box_animation_box_type = None
    box_animation_stage = 0
    reward_display_timer = 0
    reward_display_duration = 3.0  # Reward display duration (3 seconds)
    
last_midnight_check = None
last_morning_check = None

achievement_images = {}

visit_button_rect = pygame.Rect(SCREEN_WIDTH // 2 - 75, 10, 150, 32)

# Initialize box animation system
initialize_box_animation()

# 
visiting_farm = False
visited_farm_owner = None
visited_farm_data = None

phone_open = False
phone_current_tab = "adopter"  # "adopter" or "trendshop"
current_buttons_in_phone = []
phone_button_rect = pygame.Rect(SCREEN_WIDTH - 100, SCREEN_HEIGHT - 50, 32, 32)

mehmet_shop_open = False
kebab_count = 0
current_buttons_in_mehmet_shop = []


USER_DATA_FILE = "user_data.json"
current_user = None
login_screen_active = True
register_screen_active = False
login_error = ""
register_error = ""
username_input = ""
password_input = ""


xp_current_page = 0
xp_rewards_per_page = 3



def make_transparent_with_range(surface, r_range, g_range, b_range):
    """
    Makes all pixels within a specific RGB range transparent on the given surface.
    surface: Pygame surface to make transparent.
    r_range: (min, max) range for the Red component.
    g_range: (min, max) range for the Green component.
    b_range: (min, max) range for the Blue component.
    """
    surface = surface.convert_alpha()

    pixel_array = pygame.PixelArray(surface)
    for x in range(surface.get_width()):
        for y in range(surface.get_height()):
            r, g, b, a = surface.get_at((x, y))

            if (r_range[0] <= r <= r_range[1] and
                g_range[0] <= g <= g_range[1] and
                b_range[0] <= b <= b_range[1]):

                pixel_array[x, y] = (r, g, b, 0)

    del pixel_array
    return surface

def load_user_data():
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def save_user_data(data):
    with open(USER_DATA_FILE, "w") as f:
        json.dump(data, f)


def register_user(username, password):
    user_data = load_user_data()
    if username in user_data:
        return False, "Kullanıcı adı zaten alınmış"
    if len(username) < 3:
        return False, "Kullanıcı adı en az 3 karakter olmalı"
    if len(password) < 4:
        return False, "Şifre en az 4 karakter olmalı"
    
    user_data[username] = {
        "password": password,
        "game_data": {
            "gold_amount": 0,
            "carrot_count": 0,
            "wheat_count": 0,
            "corn_count": 0,
            "cotton_count": 0,
            "ticket_count": 0,
            "seed_carrot_count": 5,
            "seed_wheat_count": 5,
            "seed_corn_count": 5,
            "seed_cotton_count": 5,
            "active_dogs": [],
            "vip_dogs_owned": [],  # VIP köpekler için yeni liste
            "tasks": {
                "harvest_10_carrots": {"progress": 0, "completed": False},
                "harvest_8_wheat": {"progress": 0, "completed": False},
                "till_20_soil": {"progress": 0, "completed": False},
                "buy_first_dog": {"progress": 0, "completed": False}
            },
            "crops_data": []
        }
    }
    save_user_data(user_data)
    return True, ""

def login_user(username, password):
    user_data = load_user_data()
    if username not in user_data:
        return False, "Kullanıcı adı bulunamadı"
    if user_data[username]["password"] != password:
        return False, "Yanlış şifre"
    return True, ""





def save_game_data(username):
    global gold_amount, carrot_count, wheat_count, corn_count, cotton_count, ticket_count, kebab_count
    global seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count, active_dogs, TASKS, game_map
    global current_character_style, FINANCES, active_finances, finance_cookie_count, ACHIEVEMENTS
    global last_midnight_check, last_morning_check

    user_data = load_user_data()
    
    if username in user_data:
        # Köpekleri kaydet - BASE isimlerini ve outfit bilgilerini kaydet
        dogs_to_save = []
        for dog in active_dogs:
            dog_data = {
                "base_name": dog.base_name,
                "current_outfit": dog.current_outfit,
                "outfits": dog.outfits
            }
            dogs_to_save.append(dog_data)
            
        # Mahsul verilerini kaydet
        crops_data = []
        for y in range(MAP_HEIGHT_TILES):
            for x in range(MAP_WIDTH_TILES):
                tile = game_map[y][x]
                if tile["plant_type"] is not None:
                    crops_data.append({
                        "position": (x, y),
                        "plant_type": tile["plant_type"],
                        "plant_stage": tile["plant_stage"],
                        "growth_time": tile["growth_time"]
                    })
        
        # Görevleri kaydet
        tasks_data = {}
        for task_id, task in TASKS.items():
            tasks_data[task_id] = {
                "progress": task["progress"],
                "completed": task["completed"]
            }
        
        # VIP köpekleri kaydet - base isimlerini kaydet
        vip_dogs = [dog.base_name for dog in active_dogs if dog.base_name in VIP_DOG_REQUIREMENTS]
        
        # Finansman verilerini kaydet
        finances_data = {}
        for finance_name, finance_data in FINANCES.items():
            finance_save_data = {
                "current_level": finance_data["current_level"],
                "activated_time": finance_data.get("activated_time")
            }
            # King Midas için last_reward_time'ı da kaydet
            if finance_name == "kingmidas" and "last_reward_time" in finance_data:
                finance_save_data["last_reward_time"] = finance_data["last_reward_time"]
            finances_data[finance_name] = finance_save_data
        
        # Achievement'ları kaydet
        achievements_data = {}
        for ach_id, ach_data in ACHIEVEMENTS.items():
            achievements_data[ach_id] = {
                "completed": ach_data["completed"]
            }
        
        # Son kontrol zamanlarını kaydet
        last_midnight_check_ts = last_midnight_check.timestamp() if last_midnight_check else None
        last_morning_check_ts = last_morning_check.timestamp() if last_morning_check else None
        
        user_data[username]["game_data"] = {
            "character_style": current_character_style,
            "gold_amount": gold_amount,
            "carrot_count": carrot_count,
            "wheat_count": wheat_count,
            "corn_count": corn_count,
            "kebab_count": kebab_count,
            "cotton_count": cotton_count,
            "ticket_count": ticket_count,
            "seed_carrot_count": seed_carrot_count,
            "seed_wheat_count": seed_wheat_count,
            "seed_corn_count": seed_corn_count,
            "seed_cotton_count": seed_cotton_count,
            "active_dogs": dogs_to_save,
            "vip_dogs_owned": vip_dogs,
            "tasks": tasks_data,
            "crops_data": crops_data,
            "finances": finances_data,
            "active_finances": active_finances,
            "finance_cookie_count": finance_cookie_count,
            "achievements": achievements_data,
            "last_midnight_check": last_midnight_check_ts,
            "last_morning_check": last_morning_check_ts,
            "xp_amount": xp_amount,
            "player_level": player_level,
            "xp_to_next_level": xp_to_next_level,
            "claimed_rewards": list(claimed_rewards)
        }
        save_user_data(user_data)
        print("Game data saved successfully!")

def load_game_data(username):
    global gold_amount, carrot_count, wheat_count, corn_count, cotton_count, ticket_count, kebab_count
    global seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count, active_dogs, TASKS, game_map
    global current_character_style, FINANCES, active_finances, finance_cookie_count, ACHIEVEMENTS
    global last_midnight_check, last_morning_check
    global xp_amount, player_level, xp_to_next_level, claimed_rewards

    user_data = load_user_data()
    if username in user_data:
        if "game_data" not in user_data[username]:
            # Yeni oyuncu için varsayılan veriler
            user_data[username]["game_data"] = {
                "gold_amount": 0,
                "carrot_count": 0,
                "wheat_count": 0,
                "corn_count": 0,
                "cotton_count": 0,
                "seed_carrot_count": 5,
                "seed_wheat_count": 5,
                "seed_corn_count": 5,
                "seed_cotton_count": 5,
                "ticket_count": 0,
                "kebab_count": 0,
                "active_dogs": [],
                "vip_dogs_owned": [],
                "tasks": {
                    "harvest_fiftin_corns": {"progress": 0, "completed": False},
                    "harvest_45_carrot": {"progress": 0, "completed": False},
                    "till_100_soil": {"progress": 0, "completed": False},
                    "buy_three_dog": {"progress": 0, "completed": False}
                },
                "crops_data": [],
                "character_style": "classic",
                "finances": {},
                "active_finances": [],
                "finance_cookie_count": 0,
                "achievements": {},
                "last_midnight_check": None,
                "last_morning_check": None
            }
            save_user_data(user_data)
        
        game_data = user_data[username]["game_data"]
        
        # Temel kaynakları yükle
        gold_amount = game_data.get("gold_amount", 0)
        kebab_count = game_data.get("kebab_count", 0)
        carrot_count = game_data.get("carrot_count", 0)
        wheat_count = game_data.get("wheat_count", 0)
        corn_count = game_data.get("corn_count", 0)
        ticket_count = game_data.get("ticket_count", 0)
        cotton_count = game_data.get("cotton_count", 0)
        seed_carrot_count = game_data.get("seed_carrot_count", 5)
        seed_wheat_count = game_data.get("seed_wheat_count", 5)
        seed_corn_count = game_data.get("seed_corn_count", 5)
        seed_cotton_count = game_data.get("seed_cotton_count", 5)
        current_character_style = game_data.get("character_style", "classic")
        xp_amount = game_data.get("xp_amount", 0)
        player_level = game_data.get("player_level", 1)
        xp_to_next_level = game_data.get("xp_to_next_level", 5000)
        claimed_rewards = set(game_data.get("claimed_rewards", []))
        # Görevleri yükle
        saved_tasks = game_data.get("tasks", {})
        for task_id, task_data in saved_tasks.items():
            if task_id in TASKS:
                TASKS[task_id]["progress"] = task_data.get("progress", 0)
                TASKS[task_id]["completed"] = task_data.get("completed", False)

        # Finansman verilerini yükle
        saved_finances = game_data.get("finances", {})
        for finance_name, finance_data in saved_finances.items():
            if finance_name in FINANCES:
                FINANCES[finance_name]["current_level"] = finance_data.get("current_level", 0)
                FINANCES[finance_name]["activated_time"] = finance_data.get("activated_time")
                # King Midas için last_reward_time'ı yükle
                if finance_name == "kingmidas" and "last_reward_time" in finance_data:
                    FINANCES[finance_name]["last_reward_time"] = finance_data["last_reward_time"]

        active_finances = game_data.get("active_finances", [])
        finance_cookie_count = game_data.get("finance_cookie_count", 0)
        
        # Achievement'ları yükle
        saved_achievements = game_data.get("achievements", {})
        for ach_id, ach_data in saved_achievements.items():
            if ach_id in ACHIEVEMENTS:
                ACHIEVEMENTS[ach_id]["completed"] = ach_data.get("completed", False)
        
        # Son kontrol zamanlarını yükle
        last_midnight_check_ts = game_data.get("last_midnight_check")
        last_morning_check_ts = game_data.get("last_morning_check")
        
        last_midnight_check = datetime.fromtimestamp(last_midnight_check_ts) if last_midnight_check_ts else None
        last_morning_check = datetime.fromtimestamp(last_morning_check_ts) if last_morning_check_ts else None

        # Mahsul verilerini yükle
        crops_data = game_data.get("crops_data", [])
        # Önce tüm tile'ları resetle
        for y in range(MAP_HEIGHT_TILES):
            for x in range(MAP_WIDTH_TILES):
                if x < half_width_tiles:
                    # Sol taraf (dekorasyon)
                    if random.random() < 0.05:
                        game_map[y][x] = {
                            "type": random.choice(["rose1", "rose2", "rose3"]),
                            "plant_stage": 0,
                            "growth_time": 0,
                            "plant_type": None
                        }
                    else:
                        game_map[y][x] = {
                            "type": "empty_soil",
                            "plant_stage": 0,
                            "growth_time": 0,
                            "plant_type": None
                        }
                else:
                    # Sağ taraf (ekilebilir)
                    game_map[y][x] = {
                        "type": "empty_soil",
                        "plant_stage": 0,
                        "growth_time": 0,
                        "plant_type": None
                    }
        
        # Kayıtlı mahsulleri yerleştir
        for crop in crops_data:
            x, y = crop["position"]
            if 0 <= y < len(game_map) and 0 <= x < len(game_map[0]):
                plant_type = crop["plant_type"]
                plant_stage = crop["plant_stage"]
                growth_time = crop["growth_time"]
                
                growth_stages = PLANT_GROWTH_DURATIONS.get(plant_type, {})
                stage_info = growth_stages.get(plant_stage, {})
                image_name = stage_info.get("image", "empty_soil")
                
                game_map[y][x] = {
                    "type": image_name,
                    "plant_stage": plant_stage,
                    "growth_time": growth_time,
                    "plant_type": plant_type
                }

        # Shop ve agent tile'larını yerleştir
        game_map[shop_karo_y][shop_karo_x]["type"] = "shop_stand"
        game_map[agent_tile_y][agent_tile_x]["type"] = "agent"

        # Köpekleri yükle - YENİ SİSTEM
        active_dogs.clear()  # Önce temizle
        saved_dogs_data = game_data.get("active_dogs", [])
        
        for dog_data in saved_dogs_data:
            base_name = dog_data.get("base_name", "")
            current_outfit = dog_data.get("current_outfit", "base")
            outfits = dog_data.get("outfits", ["base"])
            
            # Outfitli ismi oluştur
            if current_outfit == "base":
                dog_name = base_name
            else:
                dog_name = f"{base_name}_{current_outfit}"
            
            # Geçerli pozisyon bul
            valid_position = False
            attempts = 0
            max_attempts = 20

            while not valid_position and attempts < max_attempts:
                spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images.get(base_name, {}).get("idle", pygame.Surface((48, 48))).get_width())
                spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images.get(base_name, {}).get("idle", pygame.Surface((48, 48))).get_height())
        
                temp_dog = Dog(dog_name, spawn_x, spawn_y)
                valid_position = temp_dog.is_position_valid(spawn_x, spawn_y)
                attempts += 1

            if valid_position:
                new_dog = Dog(dog_name, spawn_x, spawn_y)
                new_dog.outfits = outfits
                new_dog.current_outfit = current_outfit
                active_dogs.append(new_dog)
                print(f"Loaded dog: {new_dog.base_name} with outfit: {new_dog.current_outfit}")

        # VIP köpekleri yükle (backward compatibility)
        vip_dogs_owned = game_data.get("vip_dogs_owned", [])
        for dog_name in vip_dogs_owned:
            if not any(dog.base_name == dog_name for dog in active_dogs):
                spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images.get(dog_name, {}).get("idle", pygame.Surface((48, 48))).get_width())
                spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images.get(dog_name, {}).get("idle", pygame.Surface((48, 48))).get_height())
                new_dog = Dog(dog_name, spawn_x, spawn_y)
                active_dogs.append(new_dog)

    check_finance_rewards_on_login()
    
    print(f"Game loaded successfully for {username}!")



def draw_login_screen(screen):
    screen.fill(LIGHT_GREEN)
    
    # 
    title_text = font_main.render("Bob's Farm", True, BLACK)
    screen.blit(title_text, (SCREEN_WIDTH//2 - title_text.get_width()//2, 100))
    
    # 
    pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH//2 - 150, 200, 300, 40), border_radius=5)
    pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH//2 - 150, 260, 300, 40), border_radius=5)

    # 
    username_label = font_main.render("Username:", True, BLACK)
    screen.blit(username_label, (SCREEN_WIDTH//2 - 150, 170))
    
    password_label = font_main.render("Password:", True, BLACK)
    screen.blit(password_label, (SCREEN_WIDTH//2 - 150, 230))
    
    username_surface = font_main.render(username_input, True, BLACK)
    screen.blit(username_surface, (SCREEN_WIDTH//2 - 140, 210))
    
    # 
    password_surface = font_main.render("*" * len(password_input), True, BLACK)
    screen.blit(password_surface, (SCREEN_WIDTH//2 - 140, 270))

    # 
    login_button = pygame.Rect(SCREEN_WIDTH//2 - 150, 320, 140, 40)
    register_button = pygame.Rect(SCREEN_WIDTH//2 + 10, 320, 140, 40)
    
    pygame.draw.rect(screen, GREEN_BUTTON, login_button, border_radius=5)
    pygame.draw.rect(screen, BLUE_BUTTON, register_button, border_radius=5)
    
    login_text = font_main.render("Login", True, WHITE)
    register_text = font_main.render("Join", True, WHITE)
    
    screen.blit(login_text, (login_button.centerx - login_text.get_width()//2, login_button.centery - login_text.get_height()//2))
    screen.blit(register_text, (register_button.centerx - register_text.get_width()//2, register_button.centery - register_text.get_height()//2))

    # 
    if login_error:
        error_text = font_small.render(login_error, True, RED_BUTTON)
        screen.blit(error_text, (SCREEN_WIDTH//2 - error_text.get_width()//2, 370))


def draw_visit_farm_menu(screen):
    menu_width = SCREEN_WIDTH * 0.7
    menu_height = SCREEN_HEIGHT * 0.7
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2

    pygame.draw.rect(screen, BROWN, (menu_x, menu_y, menu_width, menu_height), border_radius=10)
    pygame.draw.rect(screen, WHITE, (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=8)

    title_text = font_main.render("Visit Your Friends", True, BLACK)
    screen.blit(title_text, (menu_x + menu_width // 2 - title_text.get_width() // 2, menu_y + 15))

    # 
    user_data = load_user_data()
    # 
    available_farms = [user for user in user_data.keys() if user != current_user and "game_data" in user_data[user]]
    
    farm_y_offset = 60
    farm_buttons = []
    
    for i, farm_owner in enumerate(available_farms):
        farm_rect = pygame.Rect(menu_x + 20, menu_y + farm_y_offset, menu_width - 40, 50)
        pygame.draw.rect(screen, (200, 200, 200), farm_rect, border_radius=5)
        
        farm_text = font_main.render(f"{farm_owner}'s Farm", True, BLACK)
        screen.blit(farm_text, (farm_rect.x + 10, farm_rect.y + 15))
        
        farm_buttons.append({"rect": farm_rect, "owner": farm_owner})
        farm_y_offset += 60

    # Close button
    close_button_rect = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 50, 80, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button_rect, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_button_rect.centerx - close_text.get_width() // 2, close_button_rect.centery - close_text.get_height() // 2))

    return farm_buttons, close_button_rect

def load_farm_data(username):
    user_data = load_user_data()
    if username in user_data:
        # 
        if "game_data" in user_data[username]:
            return user_data[username]["game_data"]
        else:
            # 
            # 
            # 
            print(f"Warning: 'game_data' key missing for visited user '{username}'. Returning empty farm data.")
            return {} # 
    return None # 

def draw_visited_farm(screen, farm_data):
    screen.fill(LIGHT_GREEN)
    
    # 
    for y in range(MAP_HEIGHT_TILES):
        for x in range(half_width_tiles, MAP_WIDTH_TILES):
            screen.blit(tile_images["empty_soil"], (x * TILE_SIZE, y * TILE_SIZE))

    # 
    if "crops_data" in farm_data:
        for crop in farm_data["crops_data"]:
            x, y = crop["position"]
            if 0 <= x < MAP_WIDTH_TILES and 0 <= y < MAP_HEIGHT_TILES:
                plant_type = crop["plant_type"]
                plant_stage = crop["plant_stage"]
                growth_time = crop["growth_time"]
                
                # 
                growth_stages = PLANT_GROWTH_DURATIONS.get(plant_type, {})
                stage_info = growth_stages.get(plant_stage, {})
                image_name = stage_info.get("image", "empty_soil")
                
                if image_name in tile_images:
                    screen.blit(tile_images[image_name], (x * TILE_SIZE, y * TILE_SIZE))

    # 
    if "active_dogs" in farm_data:
        for dog_name in farm_data["active_dogs"]:
            if dog_name in dog_images:
                spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[dog_name]["idle"].get_width())
                spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[dog_name]["idle"].get_height())
                screen.blit(dog_images[dog_name]["idle"], (int(spawn_x), int(spawn_y)))

    # 
    pygame.draw.rect(screen, (200, 200, 200, 200), (10, 10, 300, 120), border_radius=10)
    owner_text = font_main.render(f"Farm Owner: {visited_farm_owner}", True, BLACK)
    screen.blit(owner_text, (20, 20))
    
    carrot_text = font_small.render(f"Carrot: {farm_data.get('carrot_count', 0)}", True, BLACK)
    screen.blit(carrot_text, (20, 50))
    
    wheat_text = font_small.render(f"Weath: {farm_data.get('wheat_count', 0)}", True, BLACK)
    screen.blit(wheat_text, (20, 80))
    
    corn_text = font_small.render(f"Corn: {farm_data.get('corn_count', 0)}", True, BLACK)
    screen.blit(corn_text, (20, 110))
    
    # 
    exit_button = pygame.Rect(SCREEN_WIDTH - 110, 10, 100, 30)
    pygame.draw.rect(screen, RED_BUTTON, exit_button, border_radius=5)
    exit_text = font_small.render("Leave Farm", True, WHITE)
    screen.blit(exit_text, (exit_button.centerx - exit_text.get_width() // 2, exit_button.centery - exit_text.get_height() // 2))
    
    return exit_button


def draw_register_screen(screen):
    screen.fill(LIGHT_GREEN)
    
    # 
    title_text = font_main.render("Create Account", True, BLACK)
    screen.blit(title_text, (SCREEN_WIDTH//2 - title_text.get_width()//2, 100))

    # 
    pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH//2 - 150, 200, 300, 40), border_radius=5)
    pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH//2 - 150, 260, 300, 40), border_radius=5)
    
    # 
    username_label = font_main.render("Username:", True, BLACK)
    screen.blit(username_label, (SCREEN_WIDTH//2 - 150, 170))
    
    password_label = font_main.render("Password:", True, BLACK)
    screen.blit(password_label, (SCREEN_WIDTH//2 - 150, 230))
    
    username_surface = font_main.render(username_input, True, BLACK)
    screen.blit(username_surface, (SCREEN_WIDTH//2 - 140, 210))

    # 
    password_surface = font_main.render("*" * len(password_input), True, BLACK)
    screen.blit(password_surface, (SCREEN_WIDTH//2 - 140, 270))
    
    # 
    register_button = pygame.Rect(SCREEN_WIDTH//2 - 150, 320, 300, 40)
    back_button = pygame.Rect(SCREEN_WIDTH//2 - 150, 370, 300, 40)
    
    pygame.draw.rect(screen, BLUE_BUTTON, register_button, border_radius=5)
    pygame.draw.rect(screen, GREEN_BUTTON, back_button, border_radius=5)
    
    register_text = font_main.render("Create Account", True, WHITE)
    back_text = font_main.render("Go Back", True, WHITE)

    screen.blit(register_text, (register_button.centerx - register_text.get_width()//2, register_button.centery - register_text.get_height()//2))
    screen.blit(back_text, (back_button.centerx - back_text.get_width()//2, back_button.centery - back_text.get_height()//2))
    
    # 
    if register_error:
        error_text = font_small.render(register_error, True, RED_BUTTON)
        screen.blit(error_text, (SCREEN_WIDTH//2 - error_text.get_width()//2, 420))



npc_images = {
    "rat": {
        "idle": pygame.image.load('rat_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('rat_r1.png').convert_alpha(), pygame.image.load('rat_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('rat_l1.png').convert_alpha(), pygame.image.load('rat_l2.png').convert_alpha()],
        "scared": [pygame.image.load('rat_r1.png').convert_alpha(), pygame.image.load('rat_r2.png').convert_alpha()]  # Koşma animasyonu için aynı görseller
    },
    "turtle": {
        "idle": pygame.image.load('tur_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('tur_r1.png').convert_alpha(), pygame.image.load('tur_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('tur_l1.png').convert_alpha(), pygame.image.load('tur_l2.png').convert_alpha()],
        "hide": [pygame.image.load('turkab1.png').convert_alpha(), pygame.image.load('turkab2.png').convert_alpha()]
    }
}


for npc_type, states in npc_images.items():
    npc_images[npc_type] = {}
    for state, value in states.items():
        if isinstance(value, list):
            scaled_images = []
            for img in value:
                img = make_transparent_with_range(img,
                                                (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                                (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                                (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
                scaled_images.append(pygame.transform.scale(img, (48, 48)))
            npc_images[npc_type][state] = scaled_images
        else:
            img = make_transparent_with_range(value,
                                            (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                            (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                            (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
            npc_images[npc_type][state] = pygame.transform.scale(img, (48, 48))

FINANCES = {
    "jackolantern": {
        "name": "Jack-O-Lantern",
        "description": "In exchange for Bob's infinite restlessness, he leaves extra seeds every night; mysterious but absolutely real.",
        "levels": {
            1: {"speed_boost": 0.05, "seeds": 50, "price": 500, "cookie_price": 0},
            2: {"speed_boost": 0.07, "seeds": 70, "price": 1000, "cookie_price": 10},
            3: {"speed_boost": 0.09, "seeds": 90, "price": 2000, "cookie_price": 18}
        },
        "current_level": 0,
        "activated_time": None
    },
    "grandmaj": {
        "name": "Grandma J",
        "description": "To make her dearly beloved grandchild happy, Grandma Josephine is ready to bake some cookies. Let her cook!",
        "levels": {
            1: {"cookies": 3, "price": 500, "cookie_price": 0},
            2: {"cookies": 4, "price": 1000, "cookie_price": 10},
            3: {"cookies": 6, "price": 2000, "cookie_price": 18}
        },
        "current_level": 0,
        "activated_time": None
    },
    "molefriend": {
        "name": "Mole Friend",
        "description": "This adorable mole is carving out an intricate maze under Bob's farm. But what's the purpose?",
        "levels": {
            1: {"growth_speed": 0.10, "price": 500, "cookie_price": 0},
            2: {"growth_speed": 0.15, "price": 1000, "cookie_price": 10},
            3: {"growth_speed": 0.20, "price": 2000, "cookie_price": 18}
        },
        "current_level": 0,
        "activated_time": None
    },
    "kingmidas": {
        "name": "King Midas",
        "description": "This king who turns everything he touches into gold is obsessed with dogs. And he has donkey ears!",
        "levels": {
            1: {"gold_per_interval": 3, "interval_minutes": 10, "price": 500, "cookie_price": 0},
            2: {"gold_per_interval": 4, "interval_minutes": 10, "price": 1000, "cookie_price": 10},
            3: {"gold_per_interval": 10, "interval_minutes": 5, "price": 2000, "cookie_price": 18}
        },
        "current_level": 0,
        "activated_time": None,
        "last_reward_time": None
    }
}


# Halloween rewards
HALLOWEEN_BOX_REWARDS = {
    "pumpkin_bobbo": 0.15,      # %15 şans
    "inferno_skele-dog": 0.15,  # %15 şans  
    "ghost_akbash": 0.15,       # %15 şans
    "zombie_sultan": 0.15,      # %15 şans
    "cerberus": 0.20,           # %20 şans
    "candycorn": 0.20           # %20 şans
}

XP_REWARDS = {}
for level in range(1, 201):  # 1'den 200'e kadar
    XP_REWARDS[level] = {"type": "mystery_box", "icon": "trendshop"}
    
# Güncellenmiş Mystery Box reward pools
MYSTERY_BOX_REWARDS = {
    "common": [
        {"type": "gold", "amount": (50, 100)},
        {"type": "cookie", "amount": (1, 3)},
        {"type": "seeds", "amount": (10, 20)},
        {"type": "gold", "amount": (75, 125)},
        {"type": "cookie", "amount": (2, 4)}
    ],
    "rare": [
        {"type": "gold", "amount": (100, 200)},
        {"type": "cookie", "amount": (5, 6)},
        {"type": "seeds", "amount": (25, 40)},
        {"type": "ticket", "amount": (1, 2)},
        {"type": "gold", "amount": (150, 250)},
        {"type": "finance", "chance": 0.1},  # %10 şans finansman
        {"type": "outfit", "chance": 0.15}   # %15 şans outfit
    ],
    "epic": [
        {"type": "gold", "amount": (300, 400)},
        {"type": "cookie", "amount": (7, 8)},
        {"type": "ticket", "amount": (2, 3)},
        {"type": "seeds", "amount": (40, 60)},
        {"type": "special_dog", "dog_type": "bobbo", "chance": 0.3},
        {"type": "special_dog", "dog_type": "emerald", "chance": 0.3},
        {"type": "finance", "chance": 0.2},  # %20 şans finansman
        {"type": "outfit", "chance": 0.25}   # %25 şans outfit
    ],
    "legendary": [
        {"type": "gold", "amount": (600, 1000)},
        {"type": "cookie", "amount": (10, 12)},
        {"type": "ticket", "amount": (3, 5)},
        {"type": "special_dog", "dog_type": "skele-dog", "chance": 0.4},
        {"type": "special_dog", "dog_type": "fire", "chance": 0.4},
        {"type": "special_dog", "dog_type": "bobbo", "chance": 0.5},
        {"type": "special_dog", "dog_type": "emerald", "chance": 0.5},
        {"type": "finance", "chance": 0.3},  # %30 şans finansman
        {"type": "outfit", "chance": 0.35}   # %35 şans outfit
    ],
    "mythical": [
        {"type": "gold", "amount": (1000, 1500)},
        {"type": "cookie", "amount": (15, 20)},
        {"type": "ticket", "amount": (5, 8)},
        {"type": "special_dog", "dog_type": "skele-dog", "chance": 0.8},
        {"type": "special_dog", "dog_type": "fire", "chance": 0.8},
        {"type": "special_dog", "dog_type": "bobbo", "chance": 0.8},
        {"type": "special_dog", "dog_type": "emerald", "chance": 0.8},
        {"type": "finance", "chance": 0.5},  # %50 şans finansman
        {"type": "outfit", "chance": 0.6}    # %60 şans outfit
    ]
}

def get_unowned_dogs():
    """Oyuncunun sahip olmadığı köpekleri döndürür"""
    owned_base_names = [dog.base_name for dog in active_dogs]
    all_dogs = list(DOG_PRICES.keys()) + list(SPECIAL_DOG_REQUIREMENTS.keys()) + list(VIP_DOG_REQUIREMENTS.keys())
    
    # Tüm köpekleri topla (tekilleştir)
    all_unique_dogs = set(all_dogs)
    
    # Sahip olunmayanları filtrele
    unowned_dogs = [dog for dog in all_unique_dogs if dog not in owned_base_names]
    
    return unowned_dogs

def get_unowned_finances():
    """Oyuncunun sahip olmadığı finansmanları döndürür"""
    owned_finances = [name for name, data in FINANCES.items() if data["current_level"] > 0]
    all_finances = list(FINANCES.keys())
    
    unowned_finances = [finance for finance in all_finances if finance not in owned_finances]
    return unowned_finances

def get_unowned_outfits():
    """Oyuncunun sahip olmadığı outfit'leri döndürür"""
    unowned_outfits = []
    
    for outfit_name, req in OUTFIT_REQUIREMENTS.items():
        base_dog = req["dog"]
        
        # Köpeğin sahip olunup olunmadığını kontrol et
        dog_owned = any(dog.base_name == base_dog for dog in active_dogs)
        
        if dog_owned:
            # Köpek sahipse, outfit'in sahip olunup olunmadığını kontrol et
            for dog in active_dogs:
                if dog.base_name == base_dog and outfit_name not in dog.outfits:
                    unowned_outfits.append(outfit_name)
                    break
        else:
            # Köpek sahip değilse, outfit de sahip değil demektir
            unowned_outfits.append(outfit_name)
    
    return unowned_outfits

def get_random_finance_reward():
    """Rastgele bir finansman ödülü döndürür - YENİ SİSTEM"""
    owned_finances = [name for name, data in FINANCES.items() if data["current_level"] > 0]
    unowned_finances = [name for name in FINANCES.keys() if name not in owned_finances]
    
    # Eğer sahip olunmayan finansman varsa, onları tercih et
    if unowned_finances:
        selected_finance = random.choice(unowned_finances)
        return {"type": "finance", "finance": selected_finance, "reward_type": "new_finance"}
    else:
        # Tüm finansmanlar sahipse, rastgele birini yükselt
        all_finances = list(FINANCES.keys())
        finance_to_upgrade = random.choice(all_finances)
        current_level = FINANCES[finance_to_upgrade]["current_level"]
        
        # Maksimum seviyede değilse yükselt
        if current_level < 3:
            return {"type": "finance", "finance": finance_to_upgrade, "reward_type": "upgrade"}
        else:
            # Maksimum seviyedeyse, altın ödülü ver
            return {"type": "gold", "amount": (200, 300)}
def get_random_outfit_reward():
    """Rastgele bir outfit ödülü döndürür"""
    unowned_outfits = get_unowned_outfits()
    
    if unowned_outfits:
        # Sahip olunmayan outfit'lerden rastgele seç
        selected_outfit = random.choice(unowned_outfits)
        return {"type": "outfit_reward", "outfit": selected_outfit}
    else:
        # Tüm outfit'ler sahipse, altın ödülü ver
        return {"type": "gold", "amount": (200, 300)}

# Box rarity distribution and chances
BOX_RARITY_CHANCES = {
    "common": 0.35,      # 50% chance
    "rare": 0.30,        # 30% chance  
    "epic": 0.15,        # 15% chance
    "legendary": 13.,   # 4% chance
    "mythical": 0.7     # 1% chance
}



def get_random_box_rarity():
    """Selects random box rarity"""
    rand = random.random()
    cumulative = 0.0
    
    for rarity, chance in BOX_RARITY_CHANCES.items():
        cumulative += chance
        if rand <= cumulative:
            return rarity
    
    return "common"  # Fallback

def get_reward_description(reward):
    """Reward description to show in XP path"""
    if reward["type"] == "mystery_box":
        return "Mystery Box"
    return "Mystery Reward"







claimed_rewards = set()

character_images = {
    "classic": {
        "idle": pygame.image.load('d.png').convert_alpha(),
        "walk_right": [pygame.image.load('r1.png').convert_alpha(), pygame.image.load('r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('l1.png').convert_alpha(), pygame.image.load('l2.png').convert_alpha()],
        "walk_down": [pygame.image.load('ö1.png').convert_alpha(), pygame.image.load('ö2.png').convert_alpha()],
        "walk_up": [pygame.image.load('g1.png').convert_alpha(), pygame.image.load('g2.png').convert_alpha()],
    },
    "odin": {
        "idle": pygame.image.load('bobd.png').convert_alpha(),
        "walk_right": [pygame.image.load('bobr1.png').convert_alpha(), pygame.image.load('bobr2.png').convert_alpha()],
        "walk_left": [pygame.image.load('bobl1.png').convert_alpha(), pygame.image.load('bobl2.png').convert_alpha()],
        "walk_down": [pygame.image.load('bobö1.png').convert_alpha(), pygame.image.load('bobö2.png').convert_alpha()],
        "walk_up": [pygame.image.load('bobg1.png').convert_alpha(), pygame.image.load('bobg2.png').convert_alpha()],
    }
}


odin_hoe_animation_images = [
    pygame.image.load('bobç1.png').convert_alpha(),
    pygame.image.load('bobç2.png').convert_alpha()
]

bob_hoe_animation_images = [
    pygame.image.load('c1.png').convert_alpha(),
    pygame.image.load('c2.png').convert_alpha()
]


for key, value in character_images["odin"].items():
    if isinstance(value, list):
        scaled_images = []
        for img in value:
            img = make_transparent_with_range(img,
                                            (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                            (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                            (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
            scaled_images.append(pygame.transform.scale(img, (64, 64)))
        character_images["odin"][key] = scaled_images
    else:
        img = make_transparent_with_range(value,
                                        (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                        (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                        (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
        character_images["odin"][key] = pygame.transform.scale(img, (64, 64))



scaled_odin_hoe_animation_images = []
for img in odin_hoe_animation_images:
    img = make_transparent_with_range(img,
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
    scaled_odin_hoe_animation_images.append(pygame.transform.scale(img, (64, 64)))

current_character_style = "classic"  
wardrobe_open = False


wardrobe_button_rect = pygame.Rect(SCREEN_WIDTH - 50, SCREEN_HEIGHT - 50, 32, 32)



scaled_hoe_animation_images = []
for img in bob_hoe_animation_images:
    img = make_transparent_with_range(img,
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
    scaled_hoe_animation_images.append(pygame.transform.scale(img, (64, 64)))



for style in character_images:
    for key, value in character_images[style].items():
        if isinstance(value, list):
            scaled_images = []
            for img in value:
                img = make_transparent_with_range(img,
                                                (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                                (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                                (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
                scaled_images.append(pygame.transform.scale(img, (64, 64)))
            character_images[style][key] = scaled_images
        else:
            img = make_transparent_with_range(value,
                                            (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                            (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                            (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
            character_images[style][key] = pygame.transform.scale(img, (64, 64))


TILE_SIZE = 64

# Define outfit_images before the Dog class

def load_achievement_images():
    achievement_icons = {
        "ach_collector": pygame.image.load('ach_collecter.png').convert_alpha(),
        "ach_dogwhisperer": pygame.image.load('ach_dogwhisperer.png').convert_alpha(),
        "ach_wealthy": pygame.image.load('ach_wealthy.png').convert_alpha(),
        "ach_tycoon": pygame.image.load('ach_tycoon.png').convert_alpha()
    }
    
    for name, img in achievement_icons.items():
        img = make_transparent_with_range(img,
                                        (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                        (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                        (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
        achievement_images[name] = pygame.transform.scale(img, (48, 48))

# Oyun başlangıcında achievement resimlerini yükle
load_achievement_images()

tile_images = {
    "empty_soil": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('bt.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "tilled_soil": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('t.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "mehmet": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('mehmet.png').convert_alpha(),
        (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
        (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
        (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (int(TILE_SIZE * 1.5), int(TILE_SIZE * 1.5))
    ),
    "kebab": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('kebab.png').convert_alpha(),
        (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
        (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
        (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "rose1": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('rose1.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "rose2": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('rose2.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "rose3": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('rose3.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    # 
    "carrot_seedling": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('hf1.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "medium_carrot_sprout": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('hf2.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "large_carrot_sprout": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('hf3.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "unharvested_carrot": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('ht.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    # 
    "wheat_seedling": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('b1.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "medium_wheat": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('b2.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "large_wheat": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('b3.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "unharvested_wheat": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('bh.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    # 
    "corn_seedling": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('m1.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "medium_corn": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('m2.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "large_corn": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('m3.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "unharvested_corn": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('mh.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "cotton_seedling": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pt.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "medium_cotton": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pf.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "large_cotton": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pç.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    
    "unharvested_cotton": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('ph.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (TILE_SIZE, TILE_SIZE)
    ),
    "shop_stand": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('shop.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (int(TILE_SIZE * 1.5), int(TILE_SIZE * 1.5))
    ),
    "jamal": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('adam.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (int(TILE_SIZE * 1.5), int(TILE_SIZE * 1.5))
    ),
    
    "dog_paraoh_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('paraoh_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_charlie_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('charlie_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_master_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('master_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "ticket": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('ticket.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "agent": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('agent.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (int(TILE_SIZE * 1.5), int(TILE_SIZE * 1.5))
    )
}

# 
dog_images_raw = {
    "banana": {
        "idle": pygame.image.load('banana_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('banana_r1.png').convert_alpha(), pygame.image.load('banana_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('banana_l1.png').convert_alpha(), pygame.image.load('banana_l2.png').convert_alpha()]
    },
    "banana_subway": {  # Yeni outfit
        "idle": pygame.image.load('banana_subway_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('banana_subway_r1.png').convert_alpha(), pygame.image.load('banana_subway_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('banana_subway_l1.png').convert_alpha(), pygame.image.load('banana_subway_l2.png').convert_alpha()]
    },
    "dolly": {
        "idle": pygame.image.load('dolly_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('dolly_r1.png').convert_alpha(), pygame.image.load('dolly_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('dolly_l1.png').convert_alpha(), pygame.image.load('dolly_l2.png').convert_alpha()]
    },
    "shelby": {
        "idle": pygame.image.load('shelby_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('shelby_r1.png').convert_alpha(), pygame.image.load('shelby_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('shelby_l1.png').convert_alpha(), pygame.image.load('shelby_l2.png').convert_alpha()]
     },
    "pat": {
        "idle": pygame.image.load('pat_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('pat_r1.png').convert_alpha(), pygame.image.load('pat_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('pat_l1.png').convert_alpha(), pygame.image.load('pat_l2.png').convert_alpha()]
    },
    "hina": {
        "idle": pygame.image.load('hina_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('hina_r1.png').convert_alpha(), pygame.image.load('hina_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('hina_l1.png').convert_alpha(), pygame.image.load('hina_l2.png').convert_alpha()]
    },
    "emerald": {
        "idle": pygame.image.load('emerald_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('emerald_r1.png').convert_alpha(), pygame.image.load('emerald_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('emerald_l1.png').convert_alpha(), pygame.image.load('emerald_l2.png').convert_alpha()]
    },
    "skele-dog": {
        "idle": pygame.image.load('skele_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('skele_r1.png').convert_alpha(), pygame.image.load('skele_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('skele_l1.png').convert_alpha(), pygame.image.load('skele_l2.png').convert_alpha()]
    },
    "fire": {
        "idle": pygame.image.load('evil_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('evil_r1.png').convert_alpha(), pygame.image.load('evil_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('evil_l1.png').convert_alpha(), pygame.image.load('evil_l2.png').convert_alpha()]
    },
    
    "paraoh": {
        "idle": pygame.image.load('paraoh_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('paraoh_r1.png').convert_alpha(), pygame.image.load('paraoh_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('paraoh_l1.png').convert_alpha(), pygame.image.load('paraoh_l2.png').convert_alpha()]
    },
    "charlie": {
        "idle": pygame.image.load('charlie_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('charlie_r1.png').convert_alpha(), pygame.image.load('charlie_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('charlie_l1.png').convert_alpha(), pygame.image.load('charlie_l2.png').convert_alpha()]
    },
    "rex": {
        "idle": pygame.image.load('rex_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('rex_r1.png').convert_alpha(), pygame.image.load('rex_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('rex_l1.png').convert_alpha(), pygame.image.load('rex_l2.png').convert_alpha()]
    },
    "rex_knight": { 
        "idle": pygame.image.load('rex_knight_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('rex_knight_r1.png').convert_alpha(), pygame.image.load('rex_knight_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('rex_knight_l1.png').convert_alpha(), pygame.image.load('rex_knight_l2.png').convert_alpha()]
    },
    "choco_big": {  
        "idle": pygame.image.load('choco_big_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('choco_big_r1.png').convert_alpha(), pygame.image.load('choco_big_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('choco_big_l1.png').convert_alpha(), pygame.image.load('choco_big_l2.png').convert_alpha()]
    },
    "dolly_gangster": { 
        "idle": pygame.image.load('dolly_gangster_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('dolly_gangster_r1.png').convert_alpha(), pygame.image.load('dolly_gangster_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('dolly_gangster_l1.png').convert_alpha(), pygame.image.load('dolly_gangster_l2.png').convert_alpha()]
    },
    "master": {
        "idle": pygame.image.load('master_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('master_r1.png').convert_alpha(), pygame.image.load('master_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('master_l1.png').convert_alpha(), pygame.image.load('master_l2.png').convert_alpha()]
    },
    "skele-dog_inferno": {  
        "idle": pygame.image.load('skele-dog_inferno_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('skele-dog_inferno_r1.png').convert_alpha(), pygame.image.load('skele-dog_inferno_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('skele-dog_inferno_l1.png').convert_alpha(), pygame.image.load('skele-dog_inferno_l2.png').convert_alpha()]
    },
    "master_king": { 
        "idle": pygame.image.load('master_king_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('master_king_r1.png').convert_alpha(), pygame.image.load('master_king_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('master_king_l1.png').convert_alpha(), pygame.image.load('master_king_l2.png').convert_alpha()]
    },
    "sam": {
        "idle": pygame.image.load('sam_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('sam_r1.png').convert_alpha(), pygame.image.load('sam_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('sam_l1.png').convert_alpha(), pygame.image.load('sam_l2.png').convert_alpha()]
    },
    "akita": {
        "idle": pygame.image.load('akita_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('akita_r1.png').convert_alpha(), pygame.image.load('akita_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('akita_l1.png').convert_alpha(), pygame.image.load('akita_l2.png').convert_alpha()]
    },
    "sultan": {
        "idle": pygame.image.load('sultan_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('sultan_r1.png').convert_alpha(), pygame.image.load('sultan_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('sultan_l1.png').convert_alpha(), pygame.image.load('sultan_l2.png').convert_alpha()]
    },
    "akbash": {
        "idle": pygame.image.load('akbash_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('akbash_r1.png').convert_alpha(), pygame.image.load('akbash_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('akbash_l1.png').convert_alpha(), pygame.image.load('akbash_l2.png').convert_alpha()]
    },
    "walter": {
        "idle": pygame.image.load('walter_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('walter_r1.png').convert_alpha(), pygame.image.load('walter_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('walter_l1.png').convert_alpha(), pygame.image.load('walter_l2.png').convert_alpha()]
    },
    "sussy": {
        "idle": pygame.image.load('sussy_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('sussy_r1.png').convert_alpha(), pygame.image.load('sussy_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('sussy_l1.png').convert_alpha(), pygame.image.load('sussy_l2.png').convert_alpha()]
    },
    "cerberus": {
        "idle": pygame.image.load('cerberus_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('cerberus_r1.png').convert_alpha(), pygame.image.load('cerberus_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('cerberus_l1.png').convert_alpha(), pygame.image.load('cerberus_l2.png').convert_alpha()]
    },
    "candycorn": {
        "idle": pygame.image.load('candycorn_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('candycorn_w1.png').convert_alpha(), pygame.image.load('candycorn_w2.png').convert_alpha()],
        "walk_left": [pygame.image.load('candycorn_w1.png').convert_alpha(), pygame.image.load('candycorn_w2.png').convert_alpha()]
    },
    # Halloween outfit'leri
    "akbash_ghost": {
        "idle": pygame.image.load('akbash_ghost_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('akbash_ghost_r1.png').convert_alpha(), pygame.image.load('akbash_ghost_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('akbash_ghost_l1.png').convert_alpha(), pygame.image.load('akbash_ghost_l2.png').convert_alpha()]
    },
    "sultan_zombie": {
        "idle": pygame.image.load('sultan_zombie_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('sultan_zombie_r1.png').convert_alpha(), pygame.image.load('sultan_zombie_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('sultan_zombie_l1.png').convert_alpha(), pygame.image.load('sultan_zombie_l2.png').convert_alpha()]
    },
    "kangal": {
        "idle": pygame.image.load('kangal_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('kangal_r1.png').convert_alpha(), pygame.image.load('kangal_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('kangal_l1.png').convert_alpha(), pygame.image.load('kangal_l2.png').convert_alpha()]
    },
    "choco": {
        "idle": pygame.image.load('choco_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('choco_r1.png').convert_alpha(), pygame.image.load('choco_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('choco_l1.png').convert_alpha(), pygame.image.load('choco_l2.png').convert_alpha()]
    },
    "momo_autumn": {  # Yeni Autumn Momo outfit
        "idle": pygame.image.load('momo_autumn_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('momo_autumn_r1.png').convert_alpha(), pygame.image.load('momo_autumn_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('momo_autumn_l1.png').convert_alpha(), pygame.image.load('momo_autumn_l2.png').convert_alpha()]
    },
    "bobbo_pumpkin": {  # Yeni Pumpkin Bobbo outfit
        "idle": pygame.image.load('bobbo_pumpkin_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('bobbo_pumpkin_w1.png').convert_alpha(), pygame.image.load('bobbo_pumpkin_w2.png').convert_alpha()],
        "walk_left": [pygame.image.load('bobbo_pumpkin_w1.png').convert_alpha(), pygame.image.load('bobbo_pumpkin_w2.png').convert_alpha()]
    },
    "bobbo": {
    "idle": pygame.image.load('bobbo_d.png').convert_alpha(),
    "walk_right": [pygame.image.load('bobbo_w1.png').convert_alpha(), pygame.image.load('bobbo_w2.png').convert_alpha()],
    "walk_left": [pygame.image.load('bobbo_w1.png').convert_alpha(), pygame.image.load('bobbo_w2.png').convert_alpha()]
    },
    "lighty": {
    "idle": pygame.image.load('lighty_d.png').convert_alpha(),
    "walk_right": [pygame.image.load('lighty_r1.png').convert_alpha(), pygame.image.load('lighty_r2.png').convert_alpha()],
    "walk_left": [pygame.image.load('lighty_l1.png').convert_alpha(), pygame.image.load('lighty_l2.png').convert_alpha()]
    },
    "momo": {
    "idle": pygame.image.load('momo_d.png').convert_alpha(),
    "walk_right": [pygame.image.load('momo_r1.png').convert_alpha(), pygame.image.load('momo_r2.png').convert_alpha()],
    "walk_left": [pygame.image.load('momo_l1.png').convert_alpha(), pygame.image.load('momo_l2.png').convert_alpha()]
    },
    "pam": {
        "idle": pygame.image.load('pam_d.png').convert_alpha(),
        "walk_right": [pygame.image.load('pam_r1.png').convert_alpha(), pygame.image.load('pam_r2.png').convert_alpha()],
        "walk_left": [pygame.image.load('pam_l1.png').convert_alpha(), pygame.image.load('pam_l2.png').convert_alpha()]
    }
}





dog_images = {}
for dog_name, states in dog_images_raw.items():
    dog_images[dog_name] = {}
    for state, value in states.items():
        if isinstance(value, list):
            scaled_images = []
            for img in value:
                img = make_transparent_with_range(img,
                                                  (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                                  (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                                  (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
                scaled_images.append(pygame.transform.scale(img, (48, 48))) # Slightly smaller than character
            dog_images[dog_name][state] = scaled_images
        else:
            img = make_transparent_with_range(value,
                                              (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                              (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                              (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX))
            dog_images[dog_name][state] = pygame.transform.scale(img, (48, 48))



dog_shop_images = {
    "banana": pygame.transform.scale(pygame.image.load('shop_banana.png').convert_alpha(), 
                                    (int(1920/3), int(1080/3))),  # 640x360 boyutunda
    "dolly": pygame.transform.scale(pygame.image.load('shop_dolly.png').convert_alpha(), 
                                   (int(1920/3), int(1080/3))),
    "shelby": pygame.transform.scale(pygame.image.load('shop_shelby.png').convert_alpha(), 
                                    (int(1920/3), int(1080/3))),
    "pat": pygame.transform.scale(pygame.image.load('shop_pat.png').convert_alpha(), 
                                    (int(1920/3), int(1080/3))),  # 640x360 boyutunda
    "hina": pygame.transform.scale(pygame.image.load('shop_hina.png').convert_alpha(), 
                                   (int(1920/3), int(1080/3))),
    "rex": pygame.transform.scale(pygame.image.load('shop_rex.png').convert_alpha(), 
                                    (int(1920/3), int(1080/3))),
   
}



icon_images = {
    "carrot": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('havuc_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "xp": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('lpoint.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "xp_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('licon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "wheat": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('bugday_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "corn": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('misir_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "kingmidas": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('kingmidas.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (48, 48)
    ),
    "seed_carrot": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('seed_carrot.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "seed_wheat": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('seed_wheat.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "seed_corn": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('seed_corn.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "cotton": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pamuk_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "seed_cotton": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pamuk_tohum.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "wardrobe": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('gardrop.png').convert_alpha(),
                                (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "gold": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('gold_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "finance": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('finance.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "ghost": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('ghost.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "lenny": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('lenny.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (64, 64)
    ),
    "carrotcake": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('carrotcake.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "vodoo": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('vodoo.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "treatcoin": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('treatcoin.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "pumpkinbox": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pumpkinbox.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (64, 64)
    ),
    "ghostjs": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('ghostjs.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (256, 256)
    ),
    "cookie": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('cookie.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "jackolantern": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('jackolantern.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (48, 48)
    ),
    "grandmaj": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('grandmaj.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (48, 48)
    ),
    "molefriend": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('molefriend.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (48, 48)
    ),
    "dog_banana_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('banana_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_dolly_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('dolly_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_bobbo_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('bobbo_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_lighty_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('lighty_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_momo_autumn_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('momo_autumn_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_bobbo_pumpkin_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('bobbo_pumpkin_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_shelby_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('shelby_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_pat_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pat_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_choco_big_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('choco_big_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_dolly_gangster_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('dolly_gangster_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_hina_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('hina_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_walter_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('walter_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_sussy_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('sussy_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "kebab": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('kebab.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_emerald_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('emerald_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_skele-dog_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('skele_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    "dog_skele-dog_inferno_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('skele-dog_inferno_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (24, 24)
    ),
    
    "tasks": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('tasks.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_fire_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('evil_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_master_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('master_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_charlie_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('charlie_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_paraoh_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('paraoh_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "ticket": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('ticket.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "phone": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('phone.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "adopter": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('adopter.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (48, 48)
    ),
    "trendshop": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('trendshop.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (48, 48)
    ),
    "dog_banana_subway_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('banana_subway_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_rex_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('rex_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_sam_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('sam_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_akita_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('akita_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_rex_knight_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('rex_knight_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_master_king_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('master_king_d.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_choco_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('choco_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_sultan_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('sultan_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_akbash_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('akbash_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_kangal_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('kangal_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_pam_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('pam_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    ),
    "dog_momo_icon": pygame.transform.scale(
        make_transparent_with_range(pygame.image.load('momo_icon.png').convert_alpha(),
                                    (COLOR_RANGE_R_MIN, COLOR_RANGE_R_MAX),
                                    (COLOR_RANGE_G_MIN, COLOR_RANGE_G_MAX),
                                    (COLOR_RANGE_B_MIN, COLOR_RANGE_B_MAX)),
        (32, 32)
    )
}

# 
MAP_WIDTH_TILES = SCREEN_WIDTH // TILE_SIZE
MAP_HEIGHT_TILES = SCREEN_HEIGHT // TILE_SIZE

game_map = []
for y in range(MAP_HEIGHT_TILES):
    row = []
    for x in range(MAP_WIDTH_TILES):
        row.append({"type": "empty_soil", "plant_stage": 0, "growth_time": 0, "plant_type": None})
    game_map.append(row)

half_width_tiles = MAP_WIDTH_TILES // 2

for y in range(MAP_HEIGHT_TILES):
    for x in range(half_width_tiles, MAP_WIDTH_TILES):
        game_map[y][x]["type"] = "empty_soil"


# 
for y in range(MAP_HEIGHT_TILES):
    for x in range(half_width_tiles):  # 
        # 
        if random.random() < 0.05:
            game_map[y][x]["type"] = random.choice(["rose1", "rose2", "rose3"])
            game_map[y][x]["plant_type"] = None
            

# 
shop_tile_width = tile_images["shop_stand"].get_width() // TILE_SIZE
shop_tile_height = tile_images["shop_stand"].get_height() // TILE_SIZE

shop_karo_x = (half_width_tiles // 2) - (shop_tile_width // 2)
shop_karo_y = (MAP_HEIGHT_TILES // 2) - (shop_tile_height // 2)

if 0 <= shop_karo_y < MAP_HEIGHT_TILES and 0 <= shop_karo_x < MAP_WIDTH_TILES:
    game_map[shop_karo_y][shop_karo_x]["type"] = "shop_stand"


# 
agent_tile_x = 1  # 
agent_tile_y = 2  # 
# 
game_map[agent_tile_y][agent_tile_x]["type"] = "agent"

# 
PLANT_GROWTH_DURATIONS = {
    "carrot": {
        0: {"image": "tilled_soil", "duration": 0},
        1: {"image": "carrot_seedling", "duration": 10},
        2: {"image": "medium_carrot_sprout", "duration": 10},
        3: {"image": "large_carrot_sprout", "duration": 10},
        4: {"image": "unharvested_carrot", "duration": 10}
    },
    "wheat": {
        0: {"image": "tilled_soil", "duration": 0},
        1: {"image": "wheat_seedling", "duration": 15},
        2: {"image": "medium_wheat", "duration": 15},
        3: {"image": "large_wheat", "duration": 15},
        4: {"image": "unharvested_wheat", "duration": 15}
    },
    "corn": {
        0: {"image": "tilled_soil", "duration": 0},
        1: {"image": "corn_seedling", "duration": 20},
        2: {"image": "medium_corn", "duration": 20},
        3: {"image": "large_corn", "duration": 20},
        4: {"image": "unharvested_corn", "duration": 20}
    },
    "cotton": {
        0: {"image": "tilled_soil", "duration": 0},
        1: {"image": "cotton_seedling", "duration": 30},
        2: {"image": "medium_cotton", "duration": 30},
        3: {"image": "large_cotton", "duration": 30},
        4: {"image": "unharvested_cotton", "duration": 30}
    }
}


# 
selected_seed_type = "carrot"
seed_types = ["carrot", "wheat", "corn", "cotton"]  # 

# 
PRODUCT_PRICES = {
    "carrot": 1,
    "wheat": 2,
    "corn": 3,
    "cotton": 5
}

# 
SEED_PRICES = {
    "carrot": 0.75,
    "wheat": 1.50,
    "corn": 2.25,
    "cotton": 3.75
}

# 
DOG_PRICES = {
    "banana": 100,
    "walter": 125,
    "dolly": 150,
    "shelby": 200,
    "sussy": 225,
    "pat": 250,
    "hina": 300,
    "sultan": 325,
    "rex": 350
}

# 
SPECIAL_DOG_REQUIREMENTS = {
    "sultan": {"carrot": 100},
    "akbash": {"carrot": 100},
    "kangal": {"carrot": 100},
    "choco": {"cotton": 100},
    "lighty": {"wheat": 100},
    "pam": {"cotton": 100},
    "walter": {"wheat": 100},
    "sussy": {"corn": 100}
}

# 
VIP_DOG_REQUIREMENTS = {
    "momo": {"tickets": 1},
    "paraoh": {"tickets": 2},
    "akita": {"tickets": 3},
    "charlie": {"tickets": 4},
    "sam": {"tickets": 5},
    "master": {"tickets": 6}
}


OUTFIT_PRICES = {
    "banana_subway": 100,
    "dolly_gangster": 130,
    "rex_knight": 150,
    "master_king": 200
}

OUTFIT_REQUIREMENTS = {
    "subway": {"dog": "banana", "price": 100},
    "gangster": {"dog": "dolly", "price": 130},
    "knight": {"dog": "rex", "price": 150},
    "king": {"dog": "master", "price": 200},
    "big": {"dog": "choco", "price": 120},
    "autumn": {"dog": "momo", "price": 250},
    "pumpkin": {"dog": "bobbo", "price": 0},
    "ghost": {"dog": "akbash", "price": 0},      # Ücretsiz - kutudan çıkacak
    "zombie": {"dog": "sultan", "price": 0},     # Ücretsiz - kutudan çıkacak
    "inferno": {"dog": "skele-dog", "price": 0} 
}

OUTFIT_DISPLAY_NAMES = {
    "subway": "Subway",
    "gangster": "Gangster", 
    "knight": "Knight",
    "king": "King",
    "big": "Big",
    "autumn": "Autumn",
    "pumpkin": "Pumpkin",
    "inferno": "Inferno",
    "zombie": "Zombie",
    "ghost": "Ghost"
}


ACHIEVEMENTS = {
    "seed_collector": {
        "name": "Seed Collector",
        "description": "Harvest 100 of each crop type",
        "icon": "ach_collector",
        "completed": False,
        "hidden": False
    },
    "dog_whisperer": {
        "name": "Dog Whisperer",
        "description": "Own 20 dogs in your account",
        "icon": "ach_dogwhisperer", 
        "completed": False,
        "hidden": False
    },
    "wealthy_farmer": {
        "name": "Wealthy Farmer",
        "description": "Have 100,000 gold at once",
        "icon": "ach_wealthy",
        "completed": False,
        "hidden": False
    },
    "farming_tycoon": {
        "name": "Farming Tycoon",
        "description": "Have 500 of each crop at once",
        "icon": "ach_tycoon",
        "completed": False,
        "hidden": False
    }
}

TASKS = {
    "harvest_fiftin_corns": {
        "name": "Harvest 30 Corn",
        "description": "Harvest 30 corns from your farm",
        "target": 30,
        "progress": 0,
        "reward": 50,
        "completed": False,
        "type": "harvest",
        "item": "corn"
    },
    "harvest_45_carrot": {
        "name": "Harvest 45 Carrot",
        "description": "Harvest 45 carrot from your farm",
        "target": 45,
        "progress": 0,
        "reward": 30,
        "completed": False,
        "type": "harvest",
        "item": "carrot"
    },
    "till_100_soil": {
        "name": "Till 100 Soil Patches",
        "description": "Till 100 empty soil patches",
        "target": 1,
        "progress": 0,
        "reward": 500,
        "completed": False,
        "type": "till"
    },
    "buy_three_dog": {
        "name": "Adopt Three Friends",
        "description": "Adopt three dog",
        "target": 3,
        "progress": 0,
        "reward": 100,
        "completed": False,
        "type": "buy_dog"
    }
}


character_x = -character_images["classic"]["idle"].get_width()
character_y = SCREEN_HEIGHT // 2 - character_images["classic"]["idle"].get_height() // 2
character_speed = 200


current_animation_frame = 0
animation_speed = 0.15
animation_timer = 0.0


hoe_animation_playing = False
hoe_current_frame = 0
hoe_animation_speed = 0.2
hoe_animation_timer = 0.0
target_tile_coords = None


current_state = "idle"
current_character_style = "classic"  

# 
carrot_count = 0
wheat_count = 0
corn_count = 0

# 
seed_carrot_count = 5
seed_wheat_count = 5
seed_corn_count = 5

#  
gold_amount = 0

#  
active_dogs = []

#  
font_main = pygame.font.Font(None, 28)
font_small = pygame.font.Font(None, 20)
font_tutorial = pygame.font.Font(None, 24)
font_gold = pygame.font.Font(None, 32)



#  
task_button_rect = pygame.Rect(SCREEN_WIDTH - 50, 10, 32, 32)

#  
jamal_shop_open = False
current_buttons_in_jamal_shop = []

def process_tile(tile_x, tile_y, selected_seed_type_arg):
    """Processes the specified tile (tills, plants a seed, or harvests)."""
    global carrot_count, wheat_count, corn_count, cotton_count
    global seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count

    tile_x = int(tile_x)
    tile_y = int(tile_y)

    if not (0 <= tile_x < MAP_WIDTH_TILES and 0 <= tile_y < MAP_HEIGHT_TILES):
        return None

    target_tile = game_map[tile_y][tile_x]

    if tile_x < half_width_tiles:
        return None

    if target_tile["type"] == "empty_soil":
        target_tile["type"] = "tilled_soil"
        target_tile["plant_stage"] = 0
        target_tile["growth_time"] = 0
        target_tile["plant_type"] = None
        update_task_progress("till")
        return "tilled_soil"
        award_xp_for_action("till", (tile_x * TILE_SIZE, tile_y * TILE_SIZE))
    
    elif target_tile["type"] == "tilled_soil":
        if selected_seed_type_arg == "carrot" and seed_carrot_count > 0:
            target_tile["type"] = PLANT_GROWTH_DURATIONS[selected_seed_type_arg][1]["image"]
            target_tile["plant_stage"] = 1
            target_tile["growth_time"] = 0
            target_tile["plant_type"] = selected_seed_type_arg
            seed_carrot_count -= 1
            plant_sound.play()
            return "seed_planted"
            award_xp_for_action("plant", (tile_x * TILE_SIZE, tile_y * TILE_SIZE))
        elif selected_seed_type_arg == "wheat" and seed_wheat_count > 0:
            target_tile["type"] = PLANT_GROWTH_DURATIONS[selected_seed_type_arg][1]["image"]
            target_tile["plant_stage"] = 1
            target_tile["growth_time"] = 0
            target_tile["plant_type"] = selected_seed_type_arg
            seed_wheat_count -= 1
            plant_sound.play()
            return "seed_planted"
        elif selected_seed_type_arg == "corn" and seed_corn_count > 0:
            target_tile["type"] = PLANT_GROWTH_DURATIONS[selected_seed_type_arg][1]["image"]
            target_tile["plant_stage"] = 1
            target_tile["growth_time"] = 0
            target_tile["plant_type"] = selected_seed_type_arg
            seed_corn_count -= 1
            plant_sound.play()
            return "seed_planted"
        elif selected_seed_type_arg == "cotton" and seed_cotton_count > 0:
            target_tile["type"] = PLANT_GROWTH_DURATIONS[selected_seed_type_arg][1]["image"]
            target_tile["plant_stage"] = 1
            target_tile["growth_time"] = 0
            target_tile["plant_type"] = selected_seed_type_arg
            seed_cotton_count -= 1
            plant_sound.play()
            return "seed_planted"
        else:
            print("No seeds of the selected type!")
            return "no_seeds"

    elif target_tile["plant_type"] and \
         target_tile["type"] == PLANT_GROWTH_DURATIONS[target_tile["plant_type"]][len(PLANT_GROWTH_DURATIONS[target_tile["plant_type"]]) - 1]["image"]:

        harvested_item_type = target_tile["plant_type"]
        update_task_progress("harvest", harvested_item_type)
        award_xp_for_action("harvest", (tile_x * TILE_SIZE, tile_y * TILE_SIZE))

        extra = 0
        



        #  
        if harvested_item_type == "carrot":
            carrot_count += 1 + extra
        elif harvested_item_type == "wheat":
            wheat_count += 1
        elif harvested_item_type == "corn":
            corn_count += 1 + extra
        elif harvested_item_type == "cotton":
            cotton_count += 1

        target_tile["type"] = "empty_soil"
        target_tile["plant_stage"] = 0
        target_tile["growth_time"] = 0
        target_tile["plant_type"] = None
        plant_sound.play()
        return "harvested"
    return None

def draw_dialog_box(screen, text_lines, char_img=None):
    box_width = SCREEN_WIDTH * 0.8
    box_height = SCREEN_HEIGHT * 0.2
    box_x = (SCREEN_WIDTH - box_width) // 2
    box_y = 20

    pygame.draw.rect(screen, BROWN, (box_x, box_y, box_width, box_height), border_radius=10)
    pygame.draw.rect(screen, WHITE, (box_x + 5, box_y + 5, box_width - 10, box_height - 10), border_radius=8)

    text_y_offset = 15
    char_img_offset = 0
    if char_img:
        char_img_draw_x = box_x + 10
        char_img_draw_y = box_y + box_height - char_img.get_height() - 10
        screen.blit(char_img, (char_img_draw_x, char_img_draw_y))
        char_img_offset = char_img.get_width() + 10

    text_x_start = box_x + 15 + char_img_offset

    for line in text_lines:
        text_surface = font_tutorial.render(line, True, BLACK)
        screen.blit(text_surface, (text_x_start, box_y + text_y_offset))
        text_y_offset += font_tutorial.get_height() + 5


class TutorialManager:
    def __init__(self):
        self.stage = 0
        self.active = True
        self.dialog_duration = 4.5
        self.current_state = "idle"  # Add the missing attribute

        self.tutorial_messages = [
            "Welcome, aspiring farmer! I'm coming to guide you through the basics of farming.",
            "I'm running to you while running with WASD keys - as you will do.",
            "Feel free to move around and get a feel for the controls.",
            "Great! Now let's head over to the right side of the screen. This is where your farmable land is.",
            "Alright, we're at the empty soil. The first step in farming is to till the land.",
            "To till the soil, stand near a patch and press 'SPACE' or click with your left mouse button.",
            "Excellent! The soil is tilled. Now it's ready for planting a seed.",
            "Today, we'll plant a carrot. You can select different seeds by pressing '1' for carrot, '2' for wheat, '3' for corn and '4' for cotton.",
            "Make sure 'Carrot' is selected. Now, stand near the tilled soil and press 'SPACE' or left click again to plant the carrot seed.",
            "Perfect! A little carrot seedling is now in the ground. You can see its tiny leaves.",
            "Now comes the waiting game. Crops take time to grow. We'll speed this up for the tutorial.",
            "As time passes, your plant will grow through different stages. Just observe and be patient.",
            "-",
            "To harvest your ripe crop, stand next to it and press 'SPACE' or left click, just like tilling and planting.",
            "Fantastic! You've harvested your first carrot. This will be added to your inventory.",
            "Now that you know how to grow and harvest, let's visit the shop. It's on the left side of the screen.",
            "I'm moving towards the shop stand now. When you get close, you can interact with it.",
            "To open the shop, stand next to the shop stand and press 'SPACE' or left click.",
            "Welcome to the shop! Here you can sell the crops you've grown and buy new seeds.",
            "Let's sell the carrot you just harvested. Click the 'Sell' button next to the carrot icon.",
            "Great! You've earned some gold. Gold is essential for buying new seeds and upgrading your farm later on.",
            "Now let's buy some wheat seeds. Click the 'Buy' button next to the wheat seed icon.",
            "You've successfully purchased wheat seeds! You can now plant them in your tilled soil.",
            "To exit the shop, click the 'Close' button at the bottom.",
            "That concludes our farming tutorial! You are now equipped with the basic knowledge to start your farming adventure.",
            "Remember these steps, and don't hesitate to experiment with different crops. Good luck, farmer!"
        ]
        self.tutorial_actions = [
            {"type": "message", "message_index": 0, "duration": self.dialog_duration},
            {"type": "message", "message_index": 1, "duration": self.dialog_duration},
            {"type": "move", "target_x": SCREEN_WIDTH // 4, "target_y": SCREEN_HEIGHT // 2, "message_index": 2, "duration": self.dialog_duration},
            {"type": "message", "message_index": 3, "duration": self.dialog_duration},
            {"type": "move", "target_x": (half_width_tiles + 1) * TILE_SIZE, "target_y": (MAP_HEIGHT_TILES // 2) * TILE_SIZE, "message_index": 4, "duration": self.dialog_duration},
            {"type": "message", "message_index": 5, "duration": self.dialog_duration},
            {"type": "action", "action_type": "till", "tile_x": half_width_tiles + 1, "tile_y": MAP_HEIGHT_TILES // 2, "message_index": 6, "duration": self.dialog_duration},
            {"type": "message", "message_index": 6, "duration": self.dialog_duration},
            {"type": "message", "message_index": 7, "duration": self.dialog_duration},
            {"type": "message", "message_index": 8, "duration": self.dialog_duration},
            {"type": "action", "action_type": "plant", "tile_x": half_width_tiles + 1, "tile_y": MAP_HEIGHT_TILES // 2, "seed_type": "carrot", "message_index": 9, "duration": self.dialog_duration},
            {"type": "message", "message_index": 9, "duration": self.dialog_duration},
            {"type": "move", "target_x": (half_width_tiles + 3) * TILE_SIZE, "target_y": (MAP_HEIGHT_TILES // 2) * TILE_SIZE, "message_index": 10, "duration": self.dialog_duration},
            {"type": "message", "message_index": 11, "duration": self.dialog_duration},
            {"type": "message", "message_index": 12, "duration": self.dialog_duration, "wait_for_growth": True, "plant_type": "carrot", "tile_x": half_width_tiles + 1, "tile_y": MAP_HEIGHT_TILES // 2},
            {"type": "move", "target_x": (half_width_tiles + 1) * TILE_SIZE, "target_y": (MAP_HEIGHT_TILES // 2) * TILE_SIZE, "message_index": 13, "duration": self.dialog_duration},
            {"type": "message", "message_index": 13, "duration": self.dialog_duration},
            {"type": "action", "action_type": "harvest", "tile_x": half_width_tiles + 1, "tile_y": MAP_HEIGHT_TILES // 2, "message_index": 14, "duration": self.dialog_duration},
            {"type": "message", "message_index": 14, "duration": self.dialog_duration},
            {"type": "message", "message_index": 15, "duration": self.dialog_duration},
            {"type": "move", "target_x": shop_karo_x * TILE_SIZE, "target_y": shop_karo_y * TILE_SIZE, "message_index": 16, "duration": self.dialog_duration},
            {"type": "message", "message_index": 17, "duration": self.dialog_duration},
            {"type": "action", "action_type": "open_shop", "message_index": 18, "duration": self.dialog_duration},
            {"type": "message", "message_index": 18, "duration": self.dialog_duration},
            {"type": "message", "message_index": 19, "duration": self.dialog_duration},
            {"type": "action", "action_type": "sell", "item_type": "carrot", "message_index": 20, "duration": self.dialog_duration},
            {"type": "message", "message_index": 20, "duration": self.dialog_duration},
            {"type": "message", "message_index": 21, "duration": self.dialog_duration},
            {"type": "action", "action_type": "buy", "item_type": "wheat", "message_index": 22, "duration": self.dialog_duration},
            {"type": "message", "message_index": 22, "duration": self.dialog_duration},
            {"type": "message", "message_index": 23, "duration": self.dialog_duration},
            {"type": "action", "action_type": "close_shop", "message_index": 24, "duration": self.dialog_duration},
            {"type": "message", "message_index": 24, "duration": self.dialog_duration},
            {"type": "message", "message_index": 25, "duration": self.dialog_duration},
            {"type": "end_tutorial"}
        ]
        self.current_action_index = 0
        self.action_timer = 0
        self.is_performing_action = False
        self.current_target_x = 0
        self.current_target_y = 0

    def update(self, dt):
        global character_x, character_y, current_state, hoe_animation_playing, selected_seed_type
        global carrot_count, wheat_count, corn_count, seed_carrot_count, seed_wheat_count, seed_corn_count, gold_amount
        global shop_open, target_tile_coords, shop_current_tab

        if not self.active:
            return

        current_action = self.tutorial_actions[self.current_action_index]
        action_type = current_action["type"]

        if action_type == "message":
            if "wait_for_growth" in current_action and current_action["wait_for_growth"]:
                tile_x = current_action["tile_x"]
                tile_y = current_action["tile_y"]
                plant_type = current_action["plant_type"]

                if game_map[tile_y][tile_x]["type"] == PLANT_GROWTH_DURATIONS[plant_type][len(PLANT_GROWTH_DURATIONS[plant_type]) - 1]["image"]:
                    self.action_timer = 0
                    self.current_action_index += 1
            else:
                self.action_timer += dt
                if self.action_timer >= current_action["duration"]:
                    self.action_timer = 0
                    self.current_action_index += 1
        elif action_type == "move":
            if not self.is_performing_action:
                self.current_target_x = current_action["target_x"]
                self.current_target_y = current_action["target_y"]
                self.is_performing_action = True
                self.action_timer = 0

            dx = self.current_target_x - character_x
            dy = self.current_target_y - character_y
            dist = (dx**2 + dy**2)**0.5

            if dist > character_speed * dt:
                character_x += character_speed * (dx / dist) * dt
                character_y += character_speed * (dy / dist) * dt

                if abs(dx) > abs(dy):
                    current_state = "walk_right" if dx > 0 else "walk_left"
                else:
                    current_state = "walk_down" if dy > 0 else "walk_up"
            else:
                character_x = self.current_target_x
                character_y = self.current_target_y
                current_state = "idle"
                self.is_performing_action = False
                self.action_timer = 0
                self.current_action_index += 1

        elif action_type == "action":
            if not self.is_performing_action:
                self.is_performing_action = True
                self.action_timer = 0

                if current_action["action_type"] == "till":
                    target_tile_coords = (current_action["tile_x"], current_action["tile_y"])
                    hoe_animation_playing = True
                elif current_action["action_type"] == "plant":
                    selected_seed_type = current_action["seed_type"]
                    target_tile_coords = (current_action["tile_x"], current_action["tile_y"])
                    hoe_animation_playing = True
                elif current_action["action_type"] == "harvest":
                    target_tile_coords = (current_action["tile_x"], current_action["tile_y"])
                    hoe_animation_playing = True
                elif current_action["action_type"] == "open_shop":
                    shop_open = True
                    shop_current_tab = "crops_seeds"
                    self.is_performing_action = False
                    self.action_timer = 0
                    self.current_action_index += 1
                elif current_action["action_type"] == "sell":
                    sell_item(current_action["item_type"])
                    self.is_performing_action = False
                    self.current_action_index += 1
                elif current_action["action_type"] == "buy":
                    buy_seed(current_action["item_type"])
                    self.is_performing_action = False
                    self.current_action_index += 1
                elif current_action["action_type"] == "close_shop":
                    shop_open = False
                    self.is_performing_action = False
                    self.current_action_index += 1

            if hoe_animation_playing and (current_action["action_type"] == "till" or current_action["action_type"] == "plant" or current_action["action_type"] == "harvest"):
                pass
            else:
                self.action_timer += dt
                if self.action_timer >= current_action["duration"]:
                    self.action_timer = 0
                    if self.is_performing_action:
                        self.is_performing_action = False

        elif action_type == "end_tutorial":
            self.active = False
            character_x = SCREEN_WIDTH // 2 - character_images[current_character_style]["idle"].get_width() // 2
            character_y = SCREEN_HEIGHT // 2 - character_images[current_character_style]["idle"].get_height() // 2
            current_state = "idle"

    def draw(self, screen_surface):
        # Draw the current tutorial message
        if self.current_action_index < len(self.tutorial_actions):
            current_action = self.tutorial_actions[self.current_action_index]
            if "message_index" in current_action:
                message = self.tutorial_messages[current_action["message_index"]]
                wrapped_text = self.wrap_text(message, font_tutorial, SCREEN_WIDTH * 0.7)
                draw_dialog_box(screen_surface, wrapped_text)

    def wrap_text(self, text, font, max_width):
        if not text:
            return []
        
        words = text.split(' ')
        lines = []
        current_line = []
        for word in words:
            test_line = ' '.join(current_line + [word])
            if font.size(test_line)[0] <= max_width:
                current_line.append(word)
            else:
                lines.append(' '.join(current_line))
                current_line = [word]
        lines.append(' '.join(current_line))
        return lines


# 
OBSTACLES = [
    # 
    {"x": shop_karo_x * TILE_SIZE, "y": shop_karo_y * TILE_SIZE, 
     "width": tile_images["shop_stand"].get_width(), "height": tile_images["shop_stand"].get_height()},
    
    
    # 
    {"x": agent_tile_x * TILE_SIZE, "y": agent_tile_y * TILE_SIZE,
     "width": tile_images["agent"].get_width(), "height": tile_images["agent"].get_height()}
]

class Dog:
    def __init__(self, name, x, y):
        # Outfit durumuna göre base_name ve current_outfit belirle
        if "_" in name:
            self.base_name = name.split('_')[0]
            self.current_outfit = name.split('_')[1]
        else:
            self.base_name = name
            self.current_outfit = "base"
        
        self.name = name
        self.x = x
        self.y = y
        
        # Outfit listesini başlat - base her zaman var
        self.outfits = ["base"]
        
        # Görselleri yükle
        self.load_images()
        
        self.width = self.images["idle"].get_width()
        self.height = self.images["idle"].get_height()
        self.speed = self.get_dog_speed(self.base_name)
        self.current_state = "idle"
        self.animation_frame = 0
        self.animation_timer = 0.0
        self.animation_speed = 0.25
        self.target_x = x
        self.target_y = y
        self.ability_timer = 0
        self.last_ability_time = 0
        self.set_random_target()
    
    def load_images(self):
        """Köpeğin görsellerini yükler - DEBUG için print ekleyelim"""
        print(f"Loading images for: {self.name}")
        self.images = dog_images.get(self.name, {})
        
        # Eğer outfit görseli bulunamazsa base görselleri kullan
        if not self.images:
            print(f"Warning: Outfit images for {self.name} not found, trying base: {self.base_name}")
            self.images = dog_images.get(self.base_name, {})
            
        # Hala görsel yoksa hata ver
        if not self.images:
            print(f"ERROR: No images found for {self.base_name}")
    
    def change_outfit(self, outfit_name):
        """Köpeğin outfit'ini değiştirir - DEBUG için"""
        print(f"Changing outfit for {self.base_name} from '{self.current_outfit}' to '{outfit_name}'")
        
        if outfit_name not in self.outfits:
            print(f"Warning: Outfit {outfit_name} not available for {self.base_name}")
            return False
        
        # Yeni ismi oluştur
        if outfit_name == "base":
            new_name = self.base_name
        else:
            new_name = f"{self.base_name}_{outfit_name}"
        
        # Yeni ismi kontrol et
        if new_name not in dog_images:
            print(f"Warning: Outfit images for {new_name} not found in dog_images!")
            return False
        
        self.name = new_name
        self.current_outfit = outfit_name
        self.load_images()  # Görselleri yeniden yükle
        
        print(f"Outfit changed successfully to {outfit_name}")
        return True
    
    def add_outfit(self, outfit_name):
        """Köpeğe yeni outfit ekler"""
        if outfit_name not in self.outfits:
            self.outfits.append(outfit_name)
            return True
        return False

            
    
            
    def get_dog_speed(self, name):
        # 
        speed_settings = {
            "banana": 60,
            "dolly": 60,
            "shelby": 60,
            "pat": 60,
            "hina": 60,
            "emerald": 60,
            "skele-dog": 60,
            "fire": 60,
            "paraoh": 60,
            "charlie": 60,
            "master": 60,
            "rex": 60,
            "sam": 60,
            "akita": 60,
            "choco": 60,
            "pam": 60,
            "momo": 60,
            "kangal": 60,
            "sultan": 60,
            "lighty": 60,
            "bobbo": 45,
            "akbash": 60
        }
        return speed_settings.get(name, 15)  # 
    
    def is_position_valid(self, new_x, new_y):
        # 
        dog_rect = pygame.Rect(new_x, new_y, self.width, self.height)
        
        # 
        # Character rectangle - use current_character_style
        bob_rect = pygame.Rect(character_x, character_y, 
                         character_images[current_character_style]["idle"].get_width(), 
                         character_images[current_character_style]["idle"].get_height())
    
        # Check collision with character
        if dog_rect.colliderect(bob_rect):
          return False        
        # 
        shop_rect = pygame.Rect(shop_karo_x * TILE_SIZE, shop_karo_y * TILE_SIZE,
                              tile_images["shop_stand"].get_width(),
                              tile_images["shop_stand"].get_height())
        if dog_rect.colliderect(shop_rect):
            return False
        
       

       
        
        # 
        agent_rect = pygame.Rect(agent_tile_x * TILE_SIZE, agent_tile_y * TILE_SIZE,
                               tile_images["agent"].get_width(),
                               tile_images["agent"].get_height())
        if dog_rect.colliderect(agent_rect):
            return False
        
        # 
        if new_x + self.width > half_width_tiles * TILE_SIZE:
            return False
            
        return True
    
    def set_random_target(self):
        min_x = 0
        max_x = (half_width_tiles * TILE_SIZE) - self.width
        min_y = 0
        max_y = SCREEN_HEIGHT - self.height

        attempts = 0
        max_attempts = 20
        
        while attempts < max_attempts:
            target_x = random.uniform(min_x, max_x)
            target_y = random.uniform(min_y, max_y)
            
            if self.is_position_valid(target_x, target_y):
                self.target_x = target_x
                self.target_y = target_y
                return
            
            attempts += 1
        
        # 
        self.target_x = self.x
        self.target_y = self.y

    
            
    
        
        
        
        
    
    def update(self, dt):
        
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = (dx**2 + dy**2)**0.5

        if dist < self.speed * dt * 0.5:  # 
            self.x = self.target_x
            self.y = self.target_y
            self.current_state = "idle"
            # 
            if random.random() < 0.02:  
                self.set_random_target()
        else:
            # 
            step_size = min(1.0, self.speed * dt * 0.5)  # 
            if dist > 0:
                step_dx = (dx / dist) * step_size
                step_dy = (dy / dist) * step_size
                
                new_x = self.x + step_dx
                new_y = self.y + step_dy
                
                if self.is_position_valid(new_x, new_y):
                    self.x = new_x
                    self.y = new_y
                else:
                    self.set_random_target()
                    return

            # 
            if dist > 0:  # Only change state if actually moving
             if abs(dx) > abs(dy):
               if dx > 0:
                 self.current_state = "walk_right" if "walk_right" in self.images else "idle"
               else:
                  self.current_state = "walk_left" if "walk_left" in self.images else "idle"
             else:
               if dx > 0:
                  self.current_state = "walk_right" if "walk_right" in self.images else "idle"
               elif dx < 0:
                  self.current_state = "walk_left" if "walk_left" in self.images else "idle"
               else:
                  self.current_state = "idle"
            else:
                  self.current_state = "idle"
                  
        self.animation_timer += dt
        if self.animation_timer >= self.animation_speed:
            self.animation_timer = 0.0
            if self.current_state != "idle":
                if isinstance(self.images[self.current_state], list):
                    self.animation_frame = (self.animation_frame + 1) % len(self.images[self.current_state])
                else:
                    self.animation_frame = 0
            else:
                self.animation_frame = 0

    def draw(self, screen_surface):
     img_to_draw = None
     try:
        if self.current_state == "idle" or self.current_state not in self.images:
            img_to_draw = self.images["idle"]
        else:
            if isinstance(self.images[self.current_state], list):
                img_to_draw = self.images[self.current_state][self.animation_frame]
            else:
                img_to_draw = self.images[self.current_state]
     except (KeyError, IndexError) as e:
        # If any error occurs, use idle image as fallback
        print(f"Error drawing dog {self.name}: {e}")
        if "idle" in self.images:
            img_to_draw = self.images["idle"]
        else:
            # If no idle image, skip drawing
            return
    
     if img_to_draw:
        screen_surface.blit(img_to_draw, (int(self.x), int(self.y)))

class XPAnimation:
    def __init__(self, x, y, xp_amount):
        self.x = x
        self.y = y
        self.xp_amount = xp_amount
        self.timer = 0
        self.duration = 1.5  # 1.5 saniye
        self.speed = 50  # Piksel/saniye
        self.alpha = 255
        
    def update(self, dt):
        self.timer += dt
        self.y -= self.speed * dt
        self.alpha = max(0, 255 * (1 - (self.timer / self.duration)))
        
        return self.timer < self.duration
        
    def draw(self, screen):
        font = pygame.font.Font(None, 28)
        text = font.render(f"+{self.xp_amount} XP", True, (255, 215, 0))
        text.set_alpha(int(self.alpha))
        screen.blit(text, (int(self.x), int(self.y)))


    
class NPC:
    def __init__(self, npc_type, x, y):
        self.type = npc_type
        self.x = x
        self.y = y
        self.images = npc_images[npc_type]
        self.width = self.images["idle"].get_width()
        self.height = self.images["idle"].get_height()
        self.speed = 40 if npc_type == "rat" else 20  # Normal hız
        self.scared_speed = 80  # Rat için korkunca hız
        self.current_state = "idle"
        self.animation_frame = 0
        self.animation_timer = 0.0
        self.animation_speed = 0.25
        self.target_x = x
        self.target_y = y
        self.is_scared = False
        self.hiding = False  # Turtle için
        self.hide_timer = 0
        self.set_random_target()
        
    def set_random_target(self):
        min_x = 0
        max_x = (half_width_tiles * TILE_SIZE) - self.width
        min_y = 0
        max_y = SCREEN_HEIGHT - self.height

        attempts = 0
        max_attempts = 20
        
        while attempts < max_attempts:
            target_x = random.uniform(min_x, max_x)
            target_y = random.uniform(min_y, max_y)
            
            if self.is_position_valid(target_x, target_y):
                self.target_x = target_x
                self.target_y = target_y
                return
            
            attempts += 1
        
        # Eğer geçerli bir pozisyon bulunamazsa, mevcut pozisyonda kalsın
        self.target_x = self.x
        self.target_y = self.y
    
    def is_position_valid(self, new_x, new_y):
        # Köpeklerle çarpışma kontrolü
        for dog in active_dogs:
            dog_rect = pygame.Rect(dog.x, dog.y, dog.width, dog.height)
            npc_rect = pygame.Rect(new_x, new_y, self.width, self.height)
            if npc_rect.colliderect(dog_rect):
                return False
                
        # Karakterle çarpışma kontrolü
        bob_rect = pygame.Rect(character_x, character_y, 
                             character_images[current_character_style]["idle"].get_width(), 
                             character_images[current_character_style]["idle"].get_height())
        npc_rect = pygame.Rect(new_x, new_y, self.width, self.height)
        if npc_rect.colliderect(bob_rect):
            return False
            
        # Engellerle çarpışma kontrolü
        for obstacle in OBSTACLES:
            obstacle_rect = pygame.Rect(obstacle["x"], obstacle["y"], 
                                       obstacle["width"], obstacle["height"])
            if npc_rect.colliderect(obstacle_rect):
                return False
                
        return True
    
    def check_player_proximity(self):
        # Bob'un pozisyonu
        bob_center_x = character_x + character_images[current_character_style]["idle"].get_width() // 2
        bob_center_y = character_y + character_images[current_character_style]["idle"].get_height() // 2
        
        # NPC'nin merkezi
        npc_center_x = self.x + self.width // 2
        npc_center_y = self.y + self.height // 2
        
        # Mesafe hesapla
        distance = math.sqrt((bob_center_x - npc_center_x)**2 + (bob_center_y - npc_center_y)**2)
        
        if distance < 150:  # Yakınlık mesafesi
            if self.type == "rat" and not self.is_scared:
                self.is_scared = True
                # Rat için Bob'un ters yönüne kaç
                dx = npc_center_x - bob_center_x
                dy = npc_center_y - bob_center_y
                dist = max(1, math.sqrt(dx*dx + dy*dy))
                self.target_x = self.x + (dx/dist) * 200  # 200 piksel uzağa kaç
                self.target_y = self.y + (dy/dist) * 200
                
            elif self.type == "turtle" and not self.hiding:
                self.hiding = True
                self.hide_timer = 3.0  # 3 saniye saklanacak
        else:
            if self.type == "rat":
                self.is_scared = False
            elif self.type == "turtle" and self.hiding and self.hide_timer <= 0:
                self.hiding = False
                self.set_random_target()
    
    def update(self, dt):
        self.check_player_proximity()
        
        if self.type == "turtle" and self.hiding:
            self.hide_timer -= dt
            if self.hide_timer <= 0:
                self.hiding = False
                self.set_random_target()
            return
            
        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = math.sqrt(dx*dx + dy*dy)
        
        current_speed = self.scared_speed if (self.type == "rat" and self.is_scared) else self.speed
        
        if dist < current_speed * dt * 0.5:
            self.x = self.target_x
            self.y = self.target_y
            self.current_state = "idle"
            if random.random() < 0.02 and not self.is_scared:
                self.set_random_target()
        else:
            step_size = min(1.0, current_speed * dt * 0.5)
            if dist > 0:
                step_dx = (dx / dist) * step_size
                step_dy = (dy / dist) * step_size
                
                new_x = self.x + step_dx
                new_y = self.y + step_dy
                
                if self.is_position_valid(new_x, new_y):
                    self.x = new_x
                    self.y = new_y
                else:
                    self.set_random_target()
                    return

            if abs(dx) > abs(dy):
                self.current_state = "walk_right" if dx > 0 else "walk_left"
            else:
                self.current_state = "walk_right" if dx > 0 else "walk_left" if dx < 0 else "idle"

        self.animation_timer += dt
        if self.animation_timer >= self.animation_speed:
            self.animation_timer = 0.0
            if self.current_state != "idle":
                if isinstance(self.images[self.current_state], list):
                    self.animation_frame = (self.animation_frame + 1) % len(self.images[self.current_state])
                else:
                    self.animation_frame = 0
            else:
                self.animation_frame = 0
    
    def draw(self, screen_surface):
        if self.type == "turtle" and self.hiding:
            # Turtle saklanıyorsa hide animasyonunu göster
            img_to_draw = self.images["hide"][self.animation_frame % len(self.images["hide"])]
        elif self.type == "rat" and self.is_scared:
            # Rat korkmuşsa scared animasyonunu göster (daha hızlı)
            img_to_draw = self.images["scared"][self.animation_frame % len(self.images["scared"])]
        elif self.current_state == "idle":
            img_to_draw = self.images["idle"]
        else:
            if isinstance(self.images[self.current_state], list):
                img_to_draw = self.images[self.current_state][self.animation_frame]
            else:
                img_to_draw = self.images[self.current_state]

        screen_surface.blit(img_to_draw, (int(self.x), int(self.y)))




        
# 
tutorial_manager = TutorialManager()

# 
gold_amount = 5
carrot_count = 1

#  
SHOP_PROXIMITY_DISTANCE = 1.5 * TILE_SIZE
shop_dialog_visible = False
shop_dialog_text = []

shop_open = False
shop_current_tab = "crops_seeds"
current_buttons_in_shop = []
close_button_rect = pygame.Rect(0,0,0,0)

def update_task_progress(task_type, item_type=None, amount=1):
    global gold_amount, TASKS
    
    # 
    for task_id, task in list(TASKS.items()):
        if not task["completed"]:
            if task["type"] == task_type:
                if task_type == "harvest" and task["item"] == item_type:
                    task["progress"] += amount
                elif task_type == "till":
                    task["progress"] += amount
                elif task_type == "buy_dog":
                    task["progress"] += amount
                
                if task["progress"] >= task["target"]:
                    task["completed"] = True
                    gold_amount += task["reward"]
                    award_xp_for_action("complete_task")
                    print(f"Task '{task['name']}' completed! Earned {task['reward']} gold.")
                    
                    #  
                    if task["type"] == "harvest":
                        new_task_id = f"harvest_{task['target']*2}_{task['item']}"
                        new_task = {
                            "name": f"Harvest {task['target']*2} {task['item'].capitalize()}s",
                            "description": f"Harvest {task['target']*2} {task['item']}s from your farm",
                            "target": task["target"] * 2,
                            "progress": 0,
                            "reward": task["reward"] * 1.5,
                            "completed": False,
                            "type": "harvest",
                            "item": task["item"]
                        }
                        #  
                        del TASKS[task_id]
                        TASKS[new_task_id] = new_task
                        
                    elif task["type"] == "till":
                        new_task_id = f"till_{task['target']*2}_soil"
                        new_task = {
                            "name": f"Till {task['target']*2} Soil Patches",
                            "description": f"Till {task['target']*2} empty soil patches",
                            "target": task["target"] * 2,
                            "progress": 0,
                            "reward": task["reward"] * 1.5,
                            "completed": False,
                            "type": "till"
                        }
                        #  
                        del TASKS[task_id]
                        TASKS[new_task_id] = new_task

def draw_task_menu(screen):
    menu_width = SCREEN_WIDTH * 0.7
    menu_height = SCREEN_HEIGHT * 0.7
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2

    pygame.draw.rect(screen, BROWN, (menu_x, menu_y, menu_width, menu_height), border_radius=10)
    pygame.draw.rect(screen, WHITE, (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=8)

    # Sekmeler
    tab_x_start = menu_x + 20
    tab_y_start = menu_y + 15
    tab_width = 150
    tab_height = 40
    tab_spacing = 10

    tasks_tab_rect = pygame.Rect(tab_x_start, tab_y_start, tab_width, tab_height)
    achievements_tab_rect = pygame.Rect(tab_x_start + tab_width + tab_spacing, tab_y_start, tab_width, tab_height)
    
    pygame.draw.rect(screen, TASK_BUTTON if current_task_tab == "tasks" else (200, 200, 200), tasks_tab_rect, border_radius=5)
    pygame.draw.rect(screen, TASK_BUTTON if current_task_tab == "achievements" else (200, 200, 200), achievements_tab_rect, border_radius=5)
    
    tasks_text = font_main.render("Tasks", True, BLACK)
    achievements_text = font_main.render("Achievements", True, BLACK)
    
    screen.blit(tasks_text, (tasks_tab_rect.centerx - tasks_text.get_width() // 2, tasks_tab_rect.centery - tasks_text.get_height() // 2))
    screen.blit(achievements_text, (achievements_tab_rect.centerx - achievements_text.get_width() // 2, achievements_tab_rect.centery - achievements_text.get_height() // 2))

    # İçerik
    if current_task_tab == "tasks":
        draw_tasks_tab(screen, menu_x, menu_y, menu_width, menu_height)
    else:
        draw_achievements_tab(screen, menu_x, menu_y, menu_width, menu_height)

    # Kapat butonu
    close_button_rect = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 50, 80, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button_rect, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_button_rect.centerx - close_text.get_width() // 2, close_button_rect.centery - close_text.get_height() // 2))

    return close_button_rect, tasks_tab_rect, achievements_tab_rect

def draw_tasks_tab(screen, menu_x, menu_y, menu_width, menu_height):
    # Gold gösterimi
    gold_icon_in_shop_rect = icon_images["gold"].get_rect(topleft=(menu_x + menu_width - 60, menu_y + 60))
    screen.blit(icon_images["gold"], gold_icon_in_shop_rect)
    gold_text_surface = font_main.render(f"{gold_amount}", True, BLACK)
    screen.blit(gold_text_surface, (gold_icon_in_shop_rect.left - gold_text_surface.get_width() - 5, gold_icon_in_shop_rect.centery - gold_text_surface.get_height() // 2))

    # Görevler
    task_y_offset = 100
    for task_id, task in TASKS.items():
        task_rect = pygame.Rect(menu_x + 20, menu_y + task_y_offset, menu_width - 40, 80)
        pygame.draw.rect(screen, (230, 230, 230) if task["completed"] else (200, 200, 200), task_rect, border_radius=5)
        
        name_text = font_main.render(task["name"], True, BLACK)
        screen.blit(name_text, (task_rect.x + 10, task_rect.y + 10))
        
        desc_text = font_small.render(task["description"], True, BLACK)
        screen.blit(desc_text, (task_rect.x + 10, task_rect.y + 35))
        
        progress_text = font_small.render(f"Progress: {task['progress']}/{task['target']}", True, BLACK)
        screen.blit(progress_text, (task_rect.x + 10, task_rect.y + 55))
        
        reward_text = font_small.render(f"Reward: {task['reward']} ", True, BLACK)
        screen.blit(reward_text, (task_rect.right - 100, task_rect.y + 55))
        screen.blit(icon_images["gold"], (task_rect.right - 40, task_rect.y + 55))
        
        if task["completed"]:
            completed_text = font_main.render("✓", True, (0, 128, 0))
            screen.blit(completed_text, (task_rect.right - 20, task_rect.y + 10))
        
        task_y_offset += 90

def draw_achievements_tab(screen, menu_x, menu_y, menu_width, menu_height):
    title_text = font_main.render("Achievements", True, BLACK)
    screen.blit(title_text, (menu_x + menu_width // 2 - title_text.get_width() // 2, menu_y + 60))

    achievement_y_offset = 100
    for ach_id, achievement in ACHIEVEMENTS.items():
        ach_rect = pygame.Rect(menu_x + 20, menu_y + achievement_y_offset, menu_width - 40, 80)
        
        if achievement["completed"]:
            pygame.draw.rect(screen, (220, 255, 220), ach_rect, border_radius=5)
        else:
            pygame.draw.rect(screen, (230, 230, 230), ach_rect, border_radius=5)
        
        # Achievement icon
        if achievement["icon"] in achievement_images:
            screen.blit(achievement_images[achievement["icon"]], (ach_rect.x + 10, ach_rect.y + 16))
        
        # Achievement bilgileri
        name_text = font_main.render(achievement["name"], True, BLACK)
        screen.blit(name_text, (ach_rect.x + 70, ach_rect.y + 15))
        
        desc_text = font_small.render(achievement["description"], True, BLACK)
        screen.blit(desc_text, (ach_rect.x + 70, ach_rect.y + 40))
        
        # Durum
        if achievement["completed"]:
            status_text = font_main.render("COMPLETED", True, (0, 128, 0))
            screen.blit(status_text, (ach_rect.right - status_text.get_width() - 10, ach_rect.y + 15))
        elif achievement["hidden"] and not achievement["completed"]:
            status_text = font_small.render("???", True, (150, 150, 150))
            screen.blit(status_text, (ach_rect.right - status_text.get_width() - 10, ach_rect.y + 15))
        else:
            status_text = font_small.render("IN PROGRESS", True, (150, 150, 150))
            screen.blit(status_text, (ach_rect.right - status_text.get_width() - 10, ach_rect.y + 15))
        
        achievement_y_offset += 90



def show_message(text):
    global message_text, message_timer
    message_text = text
    message_timer = MESSAGE_DURATION



def draw_shop_menu_crops_seeds(screen, menu_x, menu_y, menu_width, menu_height):
    global current_buttons_in_shop, close_button_rect

    sell_section_title = font_main.render("  ", True, BLACK)
    screen.blit(sell_section_title, (menu_x + 30, menu_y + 60))

    item_y_offset = 100
    sell_buttons_in_menu = []

    for item_type in PRODUCT_PRICES.keys():
        item_icon = icon_images[item_type]
        price = PRODUCT_PRICES[item_type]

        screen.blit(item_icon, (menu_x + 30, menu_y + item_y_offset))

        item_name_text = font_main.render(f"{item_type.capitalize()}: {price} ", True, BLACK)
        screen.blit(item_name_text, (menu_x + 30 + item_icon.get_width() + 10, menu_y + item_y_offset + (item_icon.get_height() // 2) - (item_name_text.get_height() // 2)))

        gold_icon_rect = icon_images["gold"].get_rect(topleft=(menu_x + 30 + item_icon.get_width() + 10 + item_name_text.get_width(), menu_y + item_y_offset + (item_icon.get_height() // 2) - (icon_images["gold"].get_height() // 2)))
        screen.blit(icon_images["gold"], gold_icon_rect)

        count_text_surface = font_small.render(f"(You have: {get_item_count(item_type)})", True, BLACK)
        screen.blit(count_text_surface, (gold_icon_rect.right + 5, gold_icon_rect.centery - count_text_surface.get_height() // 2))

        # 
        sell_button_rect = pygame.Rect(menu_x + menu_width - 180, menu_y + item_y_offset, 80, 30)
        pygame.draw.rect(screen, GREEN_BUTTON, sell_button_rect, border_radius=5)
        sell_text = font_small.render("Sell", True, WHITE)
        screen.blit(sell_text, (sell_button_rect.centerx - sell_text.get_width() // 2, sell_button_rect.centery - sell_text.get_height() // 2))

      
        sell_buttons_in_menu.append({"rect": sell_button_rect, "action": "sell", "item_type": item_type})
      

        item_y_offset += 40

    buy_section_title = font_main.render("  ", True, BLACK)
    screen.blit(buy_section_title, (menu_x + 30, menu_y + item_y_offset + 30))

    item_y_offset += 70
    buy_buttons_in_menu = []

    for seed_type in SEED_PRICES.keys():
        seed_icon = icon_images[f"seed_{seed_type}"]
        price = SEED_PRICES[seed_type]

        screen.blit(seed_icon, (menu_x + 30, menu_y + item_y_offset))

        seed_name_text = font_main.render(f"{seed_type.capitalize()} Seed: {price} ", True, BLACK)
        screen.blit(seed_name_text, (menu_x + 30 + seed_icon.get_width() + 10, menu_y + item_y_offset + (seed_icon.get_height() // 2) - (seed_name_text.get_height() // 2)))

        gold_icon_rect_buy = icon_images["gold"].get_rect(topleft=(menu_x + 30 + seed_icon.get_width() + 10 + seed_name_text.get_width(), menu_y + item_y_offset + (seed_icon.get_height() // 2) - (icon_images["gold"].get_height() // 2)))
        screen.blit(icon_images["gold"], gold_icon_rect_buy)

        count_text_surface = font_small.render(f"(You have: {get_seed_count(seed_type)})", True, BLACK)
        screen.blit(count_text_surface, (gold_icon_rect_buy.right + 5, gold_icon_rect_buy.centery - count_text_surface.get_height() // 2))

        # 
        buy_button_rect = pygame.Rect(menu_x + menu_width - 180, menu_y + item_y_offset, 80, 30)
        pygame.draw.rect(screen, GREEN_BUTTON, buy_button_rect, border_radius=5)
        buy_text = font_small.render("Buy", True, WHITE)
        screen.blit(buy_text, (buy_button_rect.centerx - buy_text.get_width() // 2, buy_button_rect.centery - buy_text.get_height() // 2))

        
        buy_buttons_in_menu.append({"rect": buy_button_rect, "action": "buy", "item_type": seed_type})
        

        item_y_offset += 40

    current_buttons_in_shop = sell_buttons_in_menu + buy_buttons_in_menu
    

def draw_shop_menu_dogs(screen, menu_x, menu_y, menu_width, menu_height):
    global current_buttons_in_shop, shop_current_dog_index
    
    # Helper function to check if dog is owned by base name
    def is_dog_owned(dog_base_name):
        return any(dog.base_name == dog_base_name for dog in active_dogs)
    
    # Arka plan
    pygame.draw.rect(screen, WHITE, (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=8)
    
    # Köpek listesi
    dog_names = list(DOG_PRICES.keys())
    num_dogs = len(dog_names)
    
    # Oklar için kontrol
    left_arrow_active = shop_current_dog_index > 0
    right_arrow_active = shop_current_dog_index < num_dogs - 1
    
    # Sol ok butonu
    left_arrow = pygame.Rect(menu_x + 20, menu_y + menu_height // 2 - 25, 50, 50)
    if left_arrow_active:
        pygame.draw.polygon(screen, BLACK, [
            (left_arrow.x + 35, left_arrow.y + 10),
            (left_arrow.x + 15, left_arrow.y + 25),
            (left_arrow.x + 35, left_arrow.y + 40)
        ])
    else:
        pygame.draw.polygon(screen, (150, 150, 150), [
            (left_arrow.x + 35, left_arrow.y + 10),
            (left_arrow.x + 15, left_arrow.y + 25),
            (left_arrow.x + 35, left_arrow.y + 40)
        ])
    
    # Sağ ok butonu
    right_arrow = pygame.Rect(menu_x + menu_width - 70, menu_y + menu_height // 2 - 25, 50, 50)
    if right_arrow_active:
        pygame.draw.polygon(screen, BLACK, [
            (right_arrow.x + 15, right_arrow.y + 10),
            (right_arrow.x + 35, right_arrow.y + 25),
            (right_arrow.x + 15, right_arrow.y + 40)
        ])
    else:
        pygame.draw.polygon(screen, (150, 150, 150), [
            (right_arrow.x + 15, right_arrow.y + 10),
            (right_arrow.x + 35, right_arrow.y + 25),
            (right_arrow.x + 15, right_arrow.y + 40)
        ])

    # Mevcut köpeği göster
    current_dog = dog_names[shop_current_dog_index]
    
    # OWNED kontrolü - BASE isme göre
    owned = is_dog_owned(current_dog)
    
    if current_dog in dog_images:
        # Köpek görseli (orijinal boyutunda)
        dog_img = dog_images[current_dog]["idle"]
        img_x = menu_x + (menu_width - dog_img.get_width()) // 2
        img_y = menu_y + (menu_height - dog_img.get_height()) // 3
        screen.blit(dog_img, (img_x, img_y))
        
        # Buy/Owned butonu
        button_width, button_height = 120, 40
        button_x = menu_x + (menu_width - button_width) // 2
        button_y = img_y + dog_img.get_height() + 20
        
        button_rect = pygame.Rect(button_x, button_y, button_width, button_height)
        
        if owned:
            pygame.draw.rect(screen, (150, 150, 150), button_rect, border_radius=10)
            text = font_main.render("OWNED", True, WHITE)
        else:
            pygame.draw.rect(screen, GREEN_BUTTON, button_rect, border_radius=10)
            text = font_main.render(f"BUY - {DOG_PRICES[current_dog]}G", True, WHITE)
        
        screen.blit(text, (button_rect.centerx - text.get_width() // 2, 
                          button_rect.centery - text.get_height() // 2))
        
        # Köpek bilgileri
        dog_name_text = font_main.render(current_dog.capitalize(), True, BLACK)
        screen.blit(dog_name_text, (menu_x + menu_width//2 - dog_name_text.get_width()//2, button_y + button_height + 20))
        
        current_buttons_in_shop = [
            {"rect": button_rect, "action": "buy_dog", "dog_type": current_dog},
            {"rect": left_arrow, "action": "prev_dog", "active": left_arrow_active},
            {"rect": right_arrow, "action": "next_dog", "active": right_arrow_active}
        ]
    
    # Close button
    close_button_rect = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 60, 80, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button_rect, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_button_rect.centerx - close_text.get_width() // 2, 
                            close_button_rect.centery - close_text.get_height() // 2))
    
    current_buttons_in_shop.append({"rect": close_button_rect, "action": "close_shop"})
    
    # Gold gösterimi
    gold_icon_rect = icon_images["gold"].get_rect(topleft=(menu_x + 20, menu_y + 20))
    screen.blit(icon_images["gold"], gold_icon_rect)
    gold_text = font_main.render(f"{gold_amount}", True, BLACK)
    screen.blit(gold_text, (gold_icon_rect.right + 10, gold_icon_rect.centery - gold_text.get_height()//2))

def draw_shop_menu(screen):
    global shop_current_tab, close_button_rect, current_buttons_in_shop

    menu_width = SCREEN_WIDTH * 0.7
    menu_height = SCREEN_HEIGHT * 0.7
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2

    pygame.draw.rect(screen, BROWN, (menu_x, menu_y, menu_width, menu_height), border_radius=10)
    pygame.draw.rect(screen, WHITE, (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=8)

    title_text = font_main.render("Shop", True, BLACK)
    screen.blit(title_text, (menu_x + menu_width // 2 - title_text.get_width() // 2, menu_y + 15))

    gold_icon_in_shop_rect = icon_images["gold"].get_rect(topleft=(menu_x + menu_width - 60, menu_y + 20))
    screen.blit(icon_images["gold"], gold_icon_in_shop_rect)
    gold_text_surface = font_main.render(f"{gold_amount}", True, BLACK)
    screen.blit(gold_text_surface, (gold_icon_in_shop_rect.left - gold_text_surface.get_width() - 5, gold_icon_in_shop_rect.centery - gold_text_surface.get_height() // 2))

    # 
    tab_x_start = menu_x + 20
    tab_y_start = menu_y + 55
    tab_width = 150
    tab_height = 40
    tab_spacing = 10

    crops_seeds_tab_rect = pygame.Rect(tab_x_start, tab_y_start, tab_width, tab_height)
    pygame.draw.rect(screen, BLUE_BUTTON if shop_current_tab == "crops_seeds" else (100, 149, 237), crops_seeds_tab_rect, border_radius=5)
    crops_seeds_text = font_small.render("Crops & Seeds", True, WHITE)
    screen.blit(crops_seeds_text, (crops_seeds_tab_rect.centerx - crops_seeds_text.get_width() // 2, crops_seeds_tab_rect.centery - crops_seeds_text.get_height() // 2))

    dogs_tab_rect = pygame.Rect(tab_x_start + tab_width + tab_spacing, tab_y_start, tab_width, tab_height)
    pygame.draw.rect(screen, BLUE_BUTTON if shop_current_tab == "dogs" else (100, 149, 237), dogs_tab_rect, border_radius=5)
    dogs_text = font_small.render("Dogs", True, WHITE)
    screen.blit(dogs_text, (dogs_tab_rect.centerx - dogs_text.get_width() // 2, dogs_tab_rect.centery - dogs_text.get_height() // 2))

    if shop_current_tab == "crops_seeds":
        draw_shop_menu_crops_seeds(screen, menu_x, menu_y, menu_width, menu_height)
    elif shop_current_tab == "dogs":
        draw_shop_menu_dogs(screen, menu_x, menu_y, menu_width, menu_height)

    close_button_rect = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 50, 80, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button_rect, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_button_rect.centerx - close_text.get_width() // 2, close_button_rect.centery - close_text.get_height() // 2))

    current_buttons_in_shop.append({"rect": crops_seeds_tab_rect, "action": "change_tab", "tab_name": "crops_seeds"})
    current_buttons_in_shop.append({"rect": dogs_tab_rect, "action": "change_tab", "tab_name": "dogs"})
    current_buttons_in_shop.append({"rect": close_button_rect, "action": "close_shop"})


# Achievement kontrol fonksiyonları
def check_achievements():
    global ACHIEVEMENTS
    
    # Seed Collector: Her ekinden 100 adet biçmiş olma
    if (carrot_count >= 100 and wheat_count >= 100 and 
        corn_count >= 100 and cotton_count >= 100 and
        not ACHIEVEMENTS["seed_collector"]["completed"]):
        ACHIEVEMENTS["seed_collector"]["completed"] = True
        show_message(f"Achievement Unlocked: {ACHIEVEMENTS['seed_collector']['name']}!")
    

    # Dog Whisperer: 20 köpek sahibi olma  
    if len(active_dogs) >= 20 and not ACHIEVEMENTS["dog_whisperer"]["completed"]:
        ACHIEVEMENTS["dog_whisperer"]["completed"] = True
        show_message(f"Achievement Unlocked: {ACHIEVEMENTS['dog_whisperer']['name']}!")
    
    # Wealthy Farmer: 100,000 altın
    if gold_amount >= 100000 and not ACHIEVEMENTS["wealthy_farmer"]["completed"]:
        ACHIEVEMENTS["wealthy_farmer"]["completed"] = True
        show_message(f"Achievement Unlocked: {ACHIEVEMENTS['wealthy_farmer']['name']}!")
    
    # Farming Tycoon: Her ekinden 500 adet
    if (carrot_count >= 500 and wheat_count >= 500 and 
        corn_count >= 500 and cotton_count >= 500 and
        not ACHIEVEMENTS["farming_tycoon"]["completed"]):
        ACHIEVEMENTS["farming_tycoon"]["completed"] = True
        show_message(f"Achievement Unlocked: {ACHIEVEMENTS['farming_tycoon']['name']}!")


def draw_wardrobe_menu(screen):
    global current_character_style, wardrobe_current_dog_index, gold_amount
    
    menu_width = 450
    menu_height = 600
    menu_x = SCREEN_WIDTH - menu_width - 10
    menu_y = SCREEN_HEIGHT - menu_height - 60

    pygame.draw.rect(screen, BROWN, (menu_x, menu_y, menu_width, menu_height), border_radius=10)
    pygame.draw.rect(screen, WHITE, (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=8)

    title_text = font_main.render("Wardrobe", True, BLACK)
    screen.blit(title_text, (menu_x + menu_width // 2 - title_text.get_width() // 2, menu_y + 15))

    buttons = []
    
    # Karakter stilleri
    char_title = font_small.render("Character Styles", True, BLACK)
    screen.blit(char_title, (menu_x + 20, menu_y + 40))
    
    classic_button = pygame.Rect(menu_x + 20, menu_y + 70, menu_width - 40, 40)
    button_color = GREEN_BUTTON if current_character_style == "classic" else (200, 200, 200)
    pygame.draw.rect(screen, button_color, classic_button, border_radius=5)
    classic_text = font_main.render("Classic Bob", True, BLACK)
    screen.blit(classic_text, (classic_button.centerx - classic_text.get_width() // 2, classic_button.centery - classic_text.get_height() // 2))
    buttons.append({"rect": classic_button, "action": "classic"})

    odin_button = pygame.Rect(menu_x + 20, menu_y + 120, menu_width - 40, 40)
    button_color = GREEN_BUTTON if current_character_style == "odin" else (200, 200, 200)
    pygame.draw.rect(screen, button_color, odin_button, border_radius=5)
    odin_text = font_main.render("Arcade Bob", True, BLACK)
    screen.blit(odin_text, (odin_button.centerx - odin_text.get_width() // 2, odin_button.centery - odin_text.get_height() // 2))
    buttons.append({"rect": odin_button, "action": "odin"})

    # Köpek outfitleri
    dog_title = font_small.render("Dog Outfits", True, BLACK)
    screen.blit(dog_title, (menu_x + 20, menu_y + 180))
    
    # Outfit sahibi köpekleri filtrele
    outfit_dogs = [dog for dog in active_dogs if dog.base_name in ["banana", "dolly", "rex", "master", "choco", "momo", "bobbo", "skele-dog", "akbash", "sultan"]]
    num_dogs = len(outfit_dogs)
    
    if num_dogs > 0:
        current_dog = outfit_dogs[wardrobe_current_dog_index % num_dogs]
        
        # Köpek bilgisi
        dog_name_text = font_main.render(current_dog.base_name.capitalize(), True, BLACK)
        screen.blit(dog_name_text, (menu_x + menu_width//2 - dog_name_text.get_width()//2, menu_y + 210))
        
        # Mevcut outfit
        current_outfit_text = font_small.render(f"Current: {current_dog.current_outfit.title()}", True, BLACK)
        screen.blit(current_outfit_text, (menu_x + menu_width//2 - current_outfit_text.get_width()//2, menu_y + 240))
        
        # Ok butonları
        left_active = wardrobe_current_dog_index > 0
        right_active = wardrobe_current_dog_index < num_dogs - 1
        
        left_arrow = pygame.Rect(menu_x + 20, menu_y + 270, 30, 30)
        right_arrow = pygame.Rect(menu_x + menu_width - 50, menu_y + 270, 30, 30)
        
        pygame.draw.polygon(screen, BLACK if left_active else (150, 150, 150), 
                          [(left_arrow.x + 20, left_arrow.y + 5),
                           (left_arrow.x + 10, left_arrow.y + 15),
                           (left_arrow.x + 20, left_arrow.y + 25)])
        
        pygame.draw.polygon(screen, BLACK if right_active else (150, 150, 150), 
                          [(right_arrow.x + 10, right_arrow.y + 5),
                           (right_arrow.x + 20, right_arrow.y + 15),
                           (right_arrow.x + 10, right_arrow.y + 25)])
        
        buttons.append({"rect": left_arrow, "action": "prev_dog", "active": left_active})
        buttons.append({"rect": right_arrow, "action": "next_dog", "active": right_active})
        
        # Köpek görseli
        dog_img = None
        if current_dog.name in dog_images and "idle" in dog_images[current_dog.name]:
            dog_img = dog_images[current_dog.name]["idle"]
        elif current_dog.base_name in dog_images and "idle" in dog_images[current_dog.base_name]:
            dog_img = dog_images[current_dog.base_name]["idle"]
        
        if dog_img:
            img_width = min(120, dog_img.get_width())
            img_height = min(120, dog_img.get_height())
            scaled_img = pygame.transform.scale(dog_img, (img_width, img_height))
            screen.blit(scaled_img, (menu_x + menu_width//2 - img_width//2, menu_y + 310))
        
        # Outfit butonları
        y_offset = 440
        
        # Base outfit butonu (her zaman var)
        base_button = pygame.Rect(menu_x + 20, y_offset, menu_width - 40, 40)
        if current_dog.current_outfit == "base":
            pygame.draw.rect(screen, GREEN_BUTTON, base_button, border_radius=5)
            base_text = font_main.render("Default (Equipped)", True, BLACK)
        else:
            pygame.draw.rect(screen, (200, 200, 200), base_button, border_radius=5)
            base_text = font_main.render("Default (Equip)", True, BLACK)
        screen.blit(base_text, (base_button.centerx - base_text.get_width()//2, base_button.centery - base_text.get_height()//2))
        buttons.append({"rect": base_button, "action": "equip_outfit", "outfit": "base", "dog": current_dog})
        y_offset += 50
        
        # Özel outfit butonları
        for outfit_name, req in OUTFIT_REQUIREMENTS.items():
            if req["dog"] == current_dog.base_name:
                outfit_button = pygame.Rect(menu_x + 20, y_offset, menu_width - 40, 40)
                
                outfit_owned = outfit_name in current_dog.outfits
                is_equipped = current_dog.current_outfit == outfit_name
                
                # ÜCRETSİZ OUTFITLER için özel işlem (inferno gibi)
                if req["price"] == 0:
                    if outfit_owned:
                        if is_equipped:
                            pygame.draw.rect(screen, GREEN_BUTTON, outfit_button, border_radius=5)
                            outfit_text = font_main.render(f"{OUTFIT_DISPLAY_NAMES[outfit_name]} (Equipped)", True, BLACK)
                        else:
                            pygame.draw.rect(screen, BLUE_BUTTON, outfit_button, border_radius=5)
                            outfit_text = font_main.render(f"{OUTFIT_DISPLAY_NAMES[outfit_name]} (Equip)", True, BLACK)
                        # Sadece sahip olunan outfit'ler için buton ekle
                        buttons.append({
                            "rect": outfit_button, 
                            "action": "equip_outfit", 
                            "outfit": outfit_name, 
                            "dog": current_dog
                        })
                    else:
                        # Kilitli outfit - buton EKLEME, sadece görsel göster
                        pygame.draw.rect(screen, (150, 150, 150), outfit_button, border_radius=5)
                        outfit_text = font_main.render(f"{OUTFIT_DISPLAY_NAMES[outfit_name]} (Locked)", True, BLACK)
                        # Burada buton EKLEMİYORUZ, böylece tıklanamaz
                else:
                    # Normal ücretli outfitler için eski mantık
                    if is_equipped:
                        pygame.draw.rect(screen, GREEN_BUTTON, outfit_button, border_radius=5)
                        outfit_text = font_main.render(f"{OUTFIT_DISPLAY_NAMES[outfit_name]} (Equipped)", True, BLACK)
                        buttons.append({
                            "rect": outfit_button, 
                            "action": "equip_outfit", 
                            "outfit": outfit_name, 
                            "dog": current_dog
                        })
                    elif outfit_owned:
                        pygame.draw.rect(screen, BLUE_BUTTON, outfit_button, border_radius=5)
                        outfit_text = font_main.render(f"{OUTFIT_DISPLAY_NAMES[outfit_name]} (Equip)", True, BLACK)
                        buttons.append({
                            "rect": outfit_button, 
                            "action": "equip_outfit", 
                            "outfit": outfit_name, 
                            "dog": current_dog
                        })
                    else:
                        pygame.draw.rect(screen, (150, 150, 150), outfit_button, border_radius=5)
                        outfit_text = font_main.render(f"{OUTFIT_DISPLAY_NAMES[outfit_name]} ({req['price']}G)", True, BLACK)
                        # Satın alma butonu ekle
                        buttons.append({
                            "rect": outfit_button, 
                            "action": "buy_outfit", 
                            "outfit": outfit_name, 
                            "dog": current_dog,
                            "price": req["price"]
                        })
                
                screen.blit(outfit_text, (outfit_button.centerx - outfit_text.get_width()//2, outfit_button.centery - outfit_text.get_height()//2))
                
                y_offset += 50
    else:
        # Hiç outfit köpeği yoksa
        no_dogs_text = font_main.render("No outfit-compatible dogs", True, BLACK)
        screen.blit(no_dogs_text, (menu_x + menu_width//2 - no_dogs_text.get_width()//2, menu_y + 220))
        info_text = font_small.render("Get banana, dolly, rex, master, choco, momo, bobbo or skele-dog", True, BLACK)
        screen.blit(info_text, (menu_x + menu_width//2 - info_text.get_width()//2, menu_y + 250))

    # Close button
    close_button = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 50, 80, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_button.centerx - close_text.get_width() // 2, close_button.centery - close_text.get_height() // 2))
    
    buttons.append({"rect": close_button, "action": "close_wardrobe"})

    return buttons

def draw_phone_menu(screen):
    global current_buttons_in_phone, phone_current_tab
    
    menu_width = SCREEN_WIDTH * 0.7
    menu_height = SCREEN_HEIGHT * 0.7
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2

    pygame.draw.rect(screen, (70, 70, 90), (menu_x, menu_y, menu_width, menu_height), border_radius=10)
    pygame.draw.rect(screen, (100, 100, 120), (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=8)

    # Tab buttons
    tab_y = menu_y + 20
    tab_height = 40
    
    adopter_tab_rect = pygame.Rect(menu_x + 20, tab_y, 150, tab_height)
    halloween_tab_rect = pygame.Rect(menu_x + 180, tab_y, 150, tab_height)
    
    # Draw tab buttons
    pygame.draw.rect(screen, GREEN_BUTTON if phone_current_tab == "adopter" else (100, 149, 237), adopter_tab_rect, border_radius=5)
    screen.blit(icon_images["adopter"], (adopter_tab_rect.x + 10, adopter_tab_rect.y + 5))
    adopter_text = font_small.render("Adopter", True, WHITE)
    screen.blit(adopter_text, (adopter_tab_rect.x + 50, adopter_tab_rect.centery - adopter_text.get_height()//2))
    
    # Halloween tab - sadece event aktifse göster
    if halloween_event_active:
        pygame.draw.rect(screen, (255, 165, 0) if phone_current_tab == "halloween" else (200, 100, 50), halloween_tab_rect, border_radius=5)
        screen.blit(icon_images["ghost"], (halloween_tab_rect.x + 10, halloween_tab_rect.y + 5))
        halloween_text = font_small.render("Halloween", True, WHITE)
        screen.blit(halloween_text, (halloween_tab_rect.x + 50, halloween_tab_rect.centery - halloween_text.get_height()//2))

    # Content area
    current_buttons_in_phone = []
    
    if phone_current_tab == "adopter":
        buttons = draw_adopter_tab(screen, menu_x, menu_y, menu_width, menu_height)
        current_buttons_in_phone.extend(buttons)
    elif phone_current_tab == "halloween" and halloween_event_active:
        buttons = draw_halloween_tab(screen, menu_x, menu_y, menu_width, menu_height)
        current_buttons_in_phone.extend(buttons)

    # Close button
    close_button_rect = pygame.Rect(menu_x + menu_width - 50, menu_y + 20, 30, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button_rect, border_radius=15)
    close_text = font_main.render("X", True, WHITE)
    screen.blit(close_text, (close_button_rect.centerx - close_text.get_width()//2, 
                           close_button_rect.centery - close_text.get_height()//2))

    current_buttons_in_phone.append({"rect": close_button_rect, "action": "close_phone"})
    current_buttons_in_phone.append({"rect": adopter_tab_rect, "action": "switch_phone_tab", "tab": "adopter"})
    
    if halloween_event_active:
        current_buttons_in_phone.append({"rect": halloween_tab_rect, "action": "switch_phone_tab", "tab": "halloween"})

def draw_halloween_tab(screen, menu_x, menu_y, menu_width, menu_height):
    global treatcoin_count, carrotcake_count, vodoo_count, gold_amount, carrot_count, wheat_count, corn_count, cotton_count
    
    buttons = []
    
    # Başlık ve bilgiler
    title_text = font_main.render("HALLOWEEN EVENT - Until Nov 13", True, (255, 165, 0))
    screen.blit(title_text, (menu_x + menu_width//2 - title_text.get_width()//2, menu_y + 80))
    
    # Treatcoin gösterimi
    screen.blit(icon_images["treatcoin"], (menu_x + 30, menu_y + 120))
    treatcoin_text = font_main.render(f"{treatcoin_count}", True, WHITE)
    screen.blit(treatcoin_text, (menu_x + 70, menu_y + 120))
    
    # Lenny karakteri
    screen.blit(icon_images["lenny"], (menu_x + menu_width - 100, menu_y + 100))
    
    # Trade bölümü
    trade_title = font_main.render("Trade with Lenny", True, WHITE)
    screen.blit(trade_title, (menu_x + 30, menu_y + 160))
    
    # Carrot Cake trade
    cake_rect = pygame.Rect(menu_x + 30, menu_y + 200, menu_width - 60, 80)
    pygame.draw.rect(screen, (80, 80, 100), cake_rect, border_radius=5)
    
    screen.blit(icon_images["carrotcake"], (cake_rect.x + 10, cake_rect.y + 10))
    cake_desc = font_small.render("Carrot Cake - 50 Gold, 10 Carrot, 10 Wheat", True, WHITE)
    screen.blit(cake_desc, (cake_rect.x + 60, cake_rect.y + 15))
    
    cake_button = pygame.Rect(cake_rect.right - 120, cake_rect.y + 40, 100, 30)
    can_afford_cake = (gold_amount >= 50 and carrot_count >= 10 and wheat_count >= 10)
    pygame.draw.rect(screen, GREEN_BUTTON if can_afford_cake else (50, 50, 50), cake_button, border_radius=5)
    cake_btn_text = font_small.render("Craft" if can_afford_cake else "Need Items", True, WHITE)
    screen.blit(cake_btn_text, (cake_button.centerx - cake_btn_text.get_width()//2, cake_button.centery - cake_btn_text.get_height()//2))
    
    # Vodoo trade
    vodoo_rect = pygame.Rect(menu_x + 30, menu_y + 300, menu_width - 60, 80)
    pygame.draw.rect(screen, (80, 80, 100), vodoo_rect, border_radius=5)
    
    screen.blit(icon_images["vodoo"], (vodoo_rect.x + 10, vodoo_rect.y + 10))
    vodoo_desc = font_small.render("Vodoo Doll - 30 Gold, 10 Corn, 10 Cotton", True, WHITE)
    screen.blit(vodoo_desc, (vodoo_rect.x + 60, vodoo_rect.y + 15))
    
    vodoo_button = pygame.Rect(vodoo_rect.right - 120, vodoo_rect.y + 40, 100, 30)
    can_afford_vodoo = (gold_amount >= 30 and corn_count >= 10 and cotton_count >= 10)
    pygame.draw.rect(screen, GREEN_BUTTON if can_afford_vodoo else (50, 50, 50), vodoo_button, border_radius=5)
    vodoo_btn_text = font_small.render("Craft" if can_afford_vodoo else "Need Items", True, WHITE)
    screen.blit(vodoo_btn_text, (vodoo_button.centerx - vodoo_btn_text.get_width()//2, vodoo_button.centery - vodoo_btn_text.get_height()//2))
    
    # Halloween shop
    shop_title = font_main.render("Halloween Shop", True, WHITE)
    screen.blit(shop_title, (menu_x + 30, menu_y + 400))
    
    # Pumpkin Box
    box_rect = pygame.Rect(menu_x + 30, menu_y + 440, menu_width - 60, 80)
    pygame.draw.rect(screen, (80, 80, 100), box_rect, border_radius=5)
    
    screen.blit(icon_images["pumpkinbox"], (box_rect.x + 10, box_rect.y + 10))
    box_desc = font_small.render("Pumpkin Mystery Box - 10 Treatcoins", True, WHITE)
    screen.blit(box_desc, (box_rect.x + 90, box_rect.y + 25))
    
    box_button = pygame.Rect(box_rect.right - 120, box_rect.y + 25, 100, 30)
    can_afford_box = (treatcoin_count >= 10)
    pygame.draw.rect(screen, (255, 165, 0) if can_afford_box else (50, 50, 50), box_button, border_radius=5)
    box_btn_text = font_small.render("Open" if can_afford_box else "Need 10", True, WHITE)
    screen.blit(box_btn_text, (box_button.centerx - box_btn_text.get_width()//2, box_button.centery - box_btn_text.get_height()//2))
    
    # Butonları listeye ekle
    buttons.extend([
        {"rect": cake_button, "action": "craft_carrotcake", "enabled": can_afford_cake},
        {"rect": vodoo_button, "action": "craft_vodoo", "enabled": can_afford_vodoo},
        {"rect": box_button, "action": "open_halloween_box", "enabled": can_afford_box}
    ])
    
    return buttons

def craft_carrotcake():
    global gold_amount, carrot_count, wheat_count, carrotcake_count, treatcoin_count
    
    if gold_amount >= 50 and carrot_count >= 10 and wheat_count >= 10:
        gold_amount -= 50
        carrot_count -= 10
        wheat_count -= 10
        carrotcake_count += 1
        treatcoin_count += 2
        show_message("Carrot Cake crafted! +2 Treatcoin")
        return True
    return False

def craft_vodoo():
    global gold_amount, corn_count, cotton_count, vodoo_count, treatcoin_count
    
    if gold_amount >= 30 and corn_count >= 10 and cotton_count >= 10:
        gold_amount -= 30
        corn_count -= 10
        cotton_count -= 10
        vodoo_count += 1
        treatcoin_count += 2
        show_message("Vodoo Doll crafted! +2 Treatcoin")
        return True
    return False

def open_halloween_box():
    global treatcoin_count, halloween_box_animation_active
    
    if treatcoin_count >= 10:
        treatcoin_count -= 10
        
        # Rastgele ödül seç
        reward = get_random_halloween_reward()
        start_halloween_box_animation(reward)
        return True
    return False

def get_random_halloween_reward():
    rand = random.random()
    cumulative = 0.0
    
    for reward, chance in HALLOWEEN_BOX_REWARDS.items():
        cumulative += chance
        if rand <= cumulative:
            return reward
    
    return "candycorn"  # Fallback

def start_halloween_box_animation(reward):
    global halloween_box_animation_active, halloween_box_animation_timer, halloween_box_reward, halloween_box_animation_stage
    
    halloween_box_animation_active = True
    halloween_box_animation_timer = 0
    halloween_box_reward = reward
    halloween_box_animation_stage = 0

def draw_halloween_box_animation(screen):
    global halloween_box_animation_active, halloween_box_animation_timer, halloween_box_animation_duration
    global halloween_box_animation_stage, halloween_box_reward
    
    if not halloween_box_animation_active:
        return
    
    current_timer = halloween_box_animation_timer
    current_duration = halloween_box_animation_duration
    current_stage = halloween_box_animation_stage
    current_reward = halloween_box_reward
    
    # Dark background
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    screen.blit(overlay, (0, 0))
    
    if current_stage == 0:
        # Kutu görünümü
        anim_progress = current_timer / (current_duration * 0.4)
        box_img = icon_images["pumpkinbox"]
        screen.blit(box_img, (SCREEN_WIDTH//2 - box_img.get_width()//2, SCREEN_HEIGHT//2 - box_img.get_height()//2))
        
    elif current_stage == 1:
        # Ghost jumpscare
        anim_progress = current_timer / (current_duration * 0.3)
        ghost_img = icon_images["ghostjs"]
        
        # Titreme efekti
        shake_x = random.randint(-10, 10)
        shake_y = random.randint(-10, 10)
        
        screen.blit(ghost_img, (SCREEN_WIDTH//2 - ghost_img.get_width()//2 + shake_x, 
                              SCREEN_HEIGHT//2 - ghost_img.get_height()//2 + shake_y))
        
    elif current_stage == 2:
        # Ödül gösterimi
        anim_progress = current_timer / (current_duration * 0.3)
        
        # Ödül bilgisi
        reward_info = {
            "pumpkin_bobbo": {"name": "Pumpkin Bobbo Outfit", "icon": "dog_bobbo_pumpkin_icon"},
            "inferno_skele-dog": {"name": "Inferno Skele-Dog Outfit", "icon": "dog_skele-dog_inferno_icon"},
            "ghost_akbash": {"name": "Ghost Akbash Outfit", "icon": "dog_akbash_icon"},
            "zombie_sultan": {"name": "Zombie Sultan Outfit", "icon": "dog_sultan_icon"},
            "cerberus": {"name": "Cerberus Dog", "icon": "dog_cerberus_icon"},
            "candycorn": {"name": "Candycorn Dog", "icon": "dog_candycorn_icon"}
        }
        
        info = reward_info.get(current_reward, {"name": "Unknown Reward", "icon": "trendshop"})
        
        # Ödül ikonu
        if info["icon"] in icon_images:
            reward_icon = icon_images[info["icon"]]
            screen.blit(reward_icon, (SCREEN_WIDTH//2 - reward_icon.get_width()//2, SCREEN_HEIGHT//2 - 100))
        
        # Ödül ismi
        reward_text = font_main.render(info["name"], True, (255, 165, 0))
        screen.blit(reward_text, (SCREEN_WIDTH//2 - reward_text.get_width()//2, SCREEN_HEIGHT//2 + 50))
        
        # Tebrik mesajı
        congrats_text = font_small.render("Congratulations!", True, WHITE)
        screen.blit(congrats_text, (SCREEN_WIDTH//2 - congrats_text.get_width()//2, SCREEN_HEIGHT//2 + 90))

def update_halloween_box_animation(dt):
    global halloween_box_animation_active, halloween_box_animation_timer, halloween_box_animation_duration
    global halloween_box_animation_stage, halloween_box_reward, active_dogs
    
    if not halloween_box_animation_active:
        return False
    
    halloween_box_animation_timer += dt
    
    # Animation stages
    stage_durations = [0.4, 0.3, 0.3]  # Her aşama için süreler
    
    if halloween_box_animation_stage < len(stage_durations):
        current_stage_duration = halloween_box_animation_duration * stage_durations[halloween_box_animation_stage]
        
        if halloween_box_animation_timer >= current_stage_duration:
            halloween_box_animation_stage += 1
            halloween_box_animation_timer = 0
            
            if halloween_box_animation_stage >= len(stage_durations):
                # Animasyon bitti, ödülü uygula
                apply_halloween_reward(halloween_box_reward)
                halloween_box_animation_active = False
                return True
    
    return False

def apply_halloween_reward(reward):
    global active_dogs, treatcoin_count
    
    if reward in ["pumpkin_bobbo", "inferno_skele-dog", "ghost_akbash", "zombie_sultan"]:
        # Outfit ödülü
        outfit_map = {
            "pumpkin_bobbo": ("bobbo", "pumpkin"),
            "inferno_skele-dog": ("skele-dog", "inferno"), 
            "ghost_akbash": ("akbash", "ghost"),
            "zombie_sultan": ("sultan", "zombie")
        }
        
        base_dog, outfit_name = outfit_map[reward]
        
        # Köpeği bul ve outfit'i ekle
        for dog in active_dogs:
            if dog.base_name == base_dog:
                if outfit_name not in dog.outfits:
                    dog.outfits.append(outfit_name)
                    show_message(f"🎃 Won {outfit_name} outfit for {base_dog}!")
                else:
                    show_message(f"🎃 Already have this outfit! +5 Treatcoins")
                    treatcoin_count += 5
                break
        else:
            # Köpek yoksa treatcoin ver
            show_message(f"🎃 Don't have {base_dog}! +10 Treatcoins")
            treatcoin_count += 10
            
    else:
        # Köpek ödülü
        if not any(dog.base_name == reward for dog in active_dogs):
            valid_position = False
            attempts = 0
            max_attempts = 20
            
            while not valid_position and attempts < max_attempts:
                spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[reward]["idle"].get_width())
                spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[reward]["idle"].get_height())
                
                temp_dog = Dog(reward, spawn_x, spawn_y)
                valid_position = temp_dog.is_position_valid(spawn_x, spawn_y)
                attempts += 1
            
            if valid_position:
                new_dog = Dog(reward, spawn_x, spawn_y)
                active_dogs.append(new_dog)
                show_message(f"🎃 Won {reward.capitalize()} dog!")
            else:
                show_message(f"🎃 No space for {reward}! +10 Treatcoins")
                treatcoin_count += 10
        else:
            show_message(f"🎃 Already have {reward}! +10 Treatcoins")
            treatcoin_count += 10

def draw_finance_menu(screen):
    global finance_current_index, active_finances, finance_cookie_count, gold_amount
    
    menu_width = SCREEN_WIDTH * 0.8
    menu_height = SCREEN_HEIGHT * 0.8
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2

    # Arka plan
    pygame.draw.rect(screen, (60, 60, 80), (menu_x, menu_y, menu_width, menu_height), border_radius=15)
    pygame.draw.rect(screen, (80, 80, 100), (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=10)

    # Başlık
    title_text = font_main.render("FINANCES", True, (255, 215, 0))
    screen.blit(title_text, (menu_x + menu_width // 2 - title_text.get_width() // 2, menu_y + 20))

    # Kaynaklar
    screen.blit(icon_images["gold"], (menu_x + 30, menu_y + 60))
    gold_text = font_main.render(f"{gold_amount}", True, WHITE)
    screen.blit(gold_text, (menu_x + 70, menu_y + 60))

    screen.blit(icon_images["cookie"], (menu_x + 150, menu_y + 60))
    cookie_text = font_main.render(f"{finance_cookie_count}", True, WHITE)
    screen.blit(cookie_text, (menu_x + 190, menu_y + 60))

    # Aktif finansmanlar
    active_text = font_small.render(f"Active Finances: {len(active_finances)}/2", True, WHITE)
    screen.blit(active_text, (menu_x + menu_width - 200, menu_y + 60))

    finance_names = list(FINANCES.keys())
    current_finance = finance_names[finance_current_index]
    finance_data = FINANCES[current_finance]

    # Navigasyon okları
    left_active = finance_current_index > 0
    right_active = finance_current_index < len(finance_names) - 1
    
    left_arrow = pygame.Rect(menu_x + 30, menu_y + 120, 50, 50)
    right_arrow = pygame.Rect(menu_x + menu_width - 80, menu_y + 120, 50, 50)
    
    pygame.draw.polygon(screen, WHITE if left_active else (100, 100, 100), 
                       [(left_arrow.x + 35, left_arrow.y + 10),
                        (left_arrow.x + 15, left_arrow.y + 25),
                        (left_arrow.x + 35, left_arrow.y + 40)])
    
    pygame.draw.polygon(screen, WHITE if right_active else (100, 100, 100), 
                       [(right_arrow.x + 15, right_arrow.y + 10),
                        (right_arrow.x + 35, right_arrow.y + 25),
                        (right_arrow.x + 15, right_arrow.y + 40)])

    # Finansman bilgileri
    icon_img = icon_images[current_finance]
    screen.blit(icon_img, (menu_x + menu_width // 2 - icon_img.get_width() // 2, menu_y + 120))
    
    name_text = font_main.render(finance_data["name"], True, WHITE)
    screen.blit(name_text, (menu_x + menu_width // 2 - name_text.get_width() // 2, menu_y + 180))
    
    desc_text = font_small.render(finance_data["description"], True, (200, 200, 200))
    screen.blit(desc_text, (menu_x + menu_width // 2 - desc_text.get_width() // 2, menu_y + 210))

    # Seviye bilgileri
    current_level = finance_data["current_level"]
    level_text = font_main.render(f"Current Level: {current_level}/3", True, WHITE)
    screen.blit(level_text, (menu_x + menu_width // 2 - level_text.get_width() // 2, menu_y + 240))

    # Seviye özellikleri
    y_offset = 280
    for level in [1, 2, 3]:
        level_data = finance_data["levels"][level]
        color = GREEN_BUTTON if current_level >= level else (100, 100, 100)
        
        level_rect = pygame.Rect(menu_x + 50, menu_y + y_offset, menu_width - 100, 60)
        pygame.draw.rect(screen, color, level_rect, border_radius=5)
        
        # Seviye özellikleri
        if current_finance == "jackolantern":
            feature_text = font_small.render(f"Level {level}: +{int(level_data['speed_boost']*100)}% Speed, {level_data['seeds']} seeds at midnight", True, BLACK)
        elif current_finance == "grandmaj":
            feature_text = font_small.render(f"Level {level}: +{level_data['cookies']} cookies every morning", True, BLACK)
        elif current_finance == "molefriend":
            feature_text = font_small.render(f"Level {level}: +{int(level_data['growth_speed']*100)}% Growth Speed", True, BLACK)
        elif current_finance == "kingmidas":
            feature_text = font_small.render(f"Level {level}: {level_data['gold_per_interval']} gold every {level_data['interval_minutes']} minutes", True, BLACK)
    
            
        screen.blit(feature_text, (level_rect.x + 10, level_rect.y + 10))
        
        # Fiyat
        price_text = font_small.render(f"Price: {level_data['price']} Gold or {level_data['cookie_price']} Cookies", True, BLACK)
        screen.blit(price_text, (level_rect.x + 10, level_rect.y + 35))
        
        y_offset += 70

    # Butonlar
    buttons = []
    
    # Satın alma/yükseltme butonu
    if current_level < 3:
        next_level = current_level + 1
        level_data = finance_data["levels"][next_level]
        
        upgrade_rect = pygame.Rect(menu_x + menu_width // 2 - 100, menu_y + menu_height - 120, 200, 40)
        
        can_afford_gold = gold_amount >= level_data["price"]
        can_afford_cookies = finance_cookie_count >= level_data["cookie_price"]
        
        if can_afford_gold or can_afford_cookies:
            pygame.draw.rect(screen, GREEN_BUTTON, upgrade_rect, border_radius=5)
        else:
            pygame.draw.rect(screen, (100, 100, 100), upgrade_rect, border_radius=5)
        
        upgrade_text = font_main.render(f"Upgrade to Level {next_level}", True, WHITE)
        screen.blit(upgrade_text, (upgrade_rect.centerx - upgrade_text.get_width() // 2, 
                                 upgrade_rect.centery - upgrade_text.get_height() // 2))
        
        buttons.append({"rect": upgrade_rect, "action": "upgrade_finance", "finance": current_finance})

    # Aktifleştirme butonu
    is_active = current_finance in active_finances
    activate_rect = pygame.Rect(menu_x + menu_width // 2 - 100, menu_y + menu_height - 70, 200, 40)
    
    if current_level > 0:
        if is_active:
            pygame.draw.rect(screen, RED_BUTTON, activate_rect, border_radius=5)
            activate_text = font_main.render("Deactivate", True, WHITE)
        else:
            if len(active_finances) < 2:
                pygame.draw.rect(screen, BLUE_BUTTON, activate_rect, border_radius=5)
                activate_text = font_main.render("Activate", True, WHITE)
            else:
                pygame.draw.rect(screen, (100, 100, 100), activate_rect, border_radius=5)
                activate_text = font_main.render("Max 2 Active", True, WHITE)
    else:
        pygame.draw.rect(screen, (100, 100, 100), activate_rect, border_radius=5)
        activate_text = font_main.render("Purchase First", True, WHITE)
    
    screen.blit(activate_text, (activate_rect.centerx - activate_text.get_width() // 2, 
                              activate_rect.centery - activate_text.get_height() // 2))
    
    buttons.append({"rect": activate_rect, "action": "toggle_finance", "finance": current_finance})

    # Kapatma butonu
    close_rect = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 30, 80, 25)
    pygame.draw.rect(screen, RED_BUTTON, close_rect, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_rect.centerx - close_text.get_width() // 2, 
                           close_rect.centery - close_text.get_height() // 2))
    
    buttons.append({"rect": close_rect, "action": "close_finance"})
    buttons.append({"rect": left_arrow, "action": "prev_finance", "active": left_active})
    buttons.append({"rect": right_arrow, "action": "next_finance", "active": right_active})

    return buttons

def upgrade_finance(finance_name):
    global gold_amount, finance_cookie_count
    
    finance_data = FINANCES[finance_name]
    current_level = finance_data["current_level"]
    
    if current_level >= 3:
        return False
    
    next_level = current_level + 1
    level_data = finance_data["levels"][next_level]
    
    # Gold ile satın alma
    if gold_amount >= level_data["price"]:
        gold_amount -= level_data["price"]
        finance_data["current_level"] = next_level
        return True
    # Cookie ile satın alma
    elif finance_cookie_count >= level_data["cookie_price"]:
        finance_cookie_count -= level_data["cookie_price"]
        finance_data["current_level"] = next_level
        return True
    
    return False

def toggle_finance(finance_name):
    global active_finances
    
    finance_data = FINANCES[finance_name]
    
    if finance_data["current_level"] == 0:
        print(f"Cannot toggle {finance_name}: Level 0")
        return False
    
    if finance_name in active_finances:
        active_finances.remove(finance_name)
        finance_data["activated_time"] = None
        print(f"Deactivated {finance_name}")
        return True
    else:
        if len(active_finances) < 2:
            active_finances.append(finance_name)
            finance_data["activated_time"] = time.time()
            
            # Finansman ses efektlerini çal - DEBUG MESAJI EKLEYELİM
            print(f"Activating {finance_name} - playing sound...")
            if finance_name == "jackolantern":
                jacko_sound.play()
                print("Jack-O-Lantern sound played")
            elif finance_name == "grandmaj":
                gjo_sound.play()
                print("Grandma J sound played")
            elif finance_name == "molefriend":
                mole_sound.play()
                print("Mole Friend sound played")
            elif finance_name == "kingmidas":
                midas_sound.play()
                print("King Midas sound played")
            
            print(f"Successfully activated {finance_name}")
            return True
        else:
            print(f"Cannot activate {finance_name}: Maximum 2 active finances")
    
    return False

def apply_finance_effects():
    global gold_amount, character_speed, seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count, finance_cookie_count
    global last_midnight_check, last_morning_check
    
    current_time = time.time()
    
    # Hareket hızı bonusu (sadece oyuncu aktifken)
    if current_game_state == GAME_STATE_PLAYING:
        speed_multiplier = 1.0
        for finance_name in active_finances:
            finance_data = FINANCES[finance_name]
            if finance_name == "jackolantern" and finance_data["current_level"] > 0:
                speed_multiplier += finance_data["levels"][finance_data["current_level"]]["speed_boost"]
        
        character_speed = base_character_speed * speed_multiplier
    
    # Gece yarısı tohum kontrolü (Jack-O-Lantern) - her zaman çalışır
    now = datetime.now()
    
    # Jack-O-Lantern: Gece yarısı tohum dağıtımı
    for finance_name in active_finances:
        finance_data = FINANCES[finance_name]
        if (finance_name == "jackolantern" and finance_data["current_level"] > 0 and
            finance_data["activated_time"] is not None):
            
            # Son kontrol zamanını al veya başlangıç zamanını kullan
            if last_midnight_check is None:
                last_midnight_check = datetime.fromtimestamp(finance_data["activated_time"])
            
            # Bugün gece yarısını kontrol et
            today_midnight = datetime(now.year, now.month, now.day, 0, 0, 0)
            
            # Eğer bugün gece yarısı geçtiyse ve henüz ödül verilmediyse
            if now >= today_midnight and last_midnight_check < today_midnight:
                level_data = finance_data["levels"][finance_data["current_level"]]
                seeds_to_add = level_data["seeds"]
                
                # Rastgele tohum dağıt
                seed_types = ["carrot", "wheat", "corn", "cotton"]
                for _ in range(seeds_to_add):
                    seed_type = random.choice(seed_types)
                    if seed_type == "carrot":
                        seed_carrot_count += 1
                    elif seed_type == "wheat":
                        seed_wheat_count += 1
                    elif seed_type == "corn":
                        seed_corn_count += 1
                    elif seed_type == "cotton":
                        seed_cotton_count += 1
                
                print(f"Jack-O-Lantern: {seeds_to_add} seeds added at midnight")
                last_midnight_check = today_midnight
                
                # Oyun verilerini kaydet
                if current_user:
                    save_game_data(current_user)
    
    # Sabah kurabiye kontrolü (Grandma J) - her zaman çalışır
    for finance_name in active_finances:
        finance_data = FINANCES[finance_name]
        if (finance_name == "grandmaj" and finance_data["current_level"] > 0 and
            finance_data["activated_time"] is not None):
            
            # Son kontrol zamanını al veya başlangıç zamanını kullan
            if last_morning_check is None:
                last_morning_check = datetime.fromtimestamp(finance_data["activated_time"])
            
            # Bugün sabah 6'yı kontrol et
            today_morning = datetime(now.year, now.month, now.day, 6, 0, 0)
            
            # Eğer bugün sabah 6 geçtiyse ve henüz ödül verilmediyse
            if now >= today_morning and last_morning_check < today_morning:
                level_data = finance_data["levels"][finance_data["current_level"]]
                cookies_to_add = level_data["cookies"]
                finance_cookie_count += cookies_to_add
                
                print(f"Grandma J: {cookies_to_add} cookies added at morning")
                last_morning_check = today_morning
                
    for finance_name in active_finances:
        finance_data = FINANCES[finance_name]
        if (finance_name == "kingmidas" and finance_data["current_level"] > 0 and
            finance_data["activated_time"] is not None):
            
            level_data = finance_data["levels"][finance_data["current_level"]]
            interval_seconds = level_data["interval_minutes"] * 60
            
            # Son ödül zamanını kontrol et
            if finance_data.get("last_reward_time") is None:
                finance_data["last_reward_time"] = current_time
            
            # Belirli aralıklarla altın ver
            if current_time - finance_data["last_reward_time"] >= interval_seconds:
                gold_to_add = level_data["gold_per_interval"]
                gold_amount += gold_to_add
                finance_data["last_reward_time"] = current_time
                

                # Oyun verilerini kaydet
                if current_user:
                    save_game_data(current_user)

def get_growth_multiplier():
    """Büyüme hızı çarpanını döndürür - her zaman çalışır"""
    growth_multiplier = 1.0
    for finance_name in active_finances:
        finance_data = FINANCES[finance_name]
        if finance_name == "molefriend" and finance_data["current_level"] > 0:
            growth_multiplier += finance_data["levels"][finance_data["current_level"]]["growth_speed"]
    return growth_multiplier

def check_finance_rewards_on_login():
    """Oyuncu giriş yaptığında kaçırılan ödülleri kontrol et"""
    global last_midnight_check, last_morning_check, seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count, finance_cookie_count, gold_amount
    
    now = datetime.now()
    current_time = time.time()
    
    # Eğer hiç kontrol yapılmamışsa, finansman aktivasyon zamanını kullan
    if last_midnight_check is None:
        # Aktif finansmanlardan en eski aktivasyon zamanını bul
        oldest_activation = None
        for finance_name in active_finances:
            finance_data = FINANCES[finance_name]
            if finance_data.get("activated_time"):
                if oldest_activation is None or finance_data["activated_time"] < oldest_activation:
                    oldest_activation = finance_data["activated_time"]
        
        if oldest_activation:
            last_midnight_check = datetime.fromtimestamp(oldest_activation)
            last_morning_check = datetime.fromtimestamp(oldest_activation)
        else:
            last_midnight_check = now
            last_morning_check = now
    
    for finance_name in active_finances:
        finance_data = FINANCES[finance_name]
        
        if finance_name == "jackolantern" and finance_data["current_level"] > 0:
            level_data = finance_data["levels"][finance_data["current_level"]]
            seeds_per_night = level_data["seeds"]
            
            # Son gece yarısı kontrolünden bu yana kaç gün geçmiş
            today_midnight = datetime(now.year, now.month, now.day, 0, 0, 0)
            last_midnight = datetime(last_midnight_check.year, last_midnight_check.month, last_midnight_check.day, 0, 0, 0)
            
            days_since_last_check = (today_midnight - last_midnight).days
            
            if days_since_last_check > 0:
                total_seeds = days_since_last_check * seeds_per_night
                
                # Rastgele tohum dağıt
                seed_types = ["carrot", "wheat", "corn", "cotton"]
                for _ in range(total_seeds):
                    seed_type = random.choice(seed_types)
                    if seed_type == "carrot":
                        seed_carrot_count += 1
                    elif seed_type == "wheat":
                        seed_wheat_count += 1
                    elif seed_type == "corn":
                        seed_corn_count += 1
                    elif seed_type == "cotton":
                        seed_cotton_count += 1
                
                print(f"Jack-O-Lantern: {total_seeds} seeds added for {days_since_last_check} missed nights")
                # Son kontrol zamanını güncelle
                last_midnight_check = today_midnight
        
        elif finance_name == "grandmaj" and finance_data["current_level"] > 0:
            level_data = finance_data["levels"][finance_data["current_level"]]
            cookies_per_morning = level_data["cookies"]
            
            # Son sabah kontrolünden bu yana kaç gün geçmiş
            today_morning = datetime(now.year, now.month, now.day, 6, 0, 0)
            last_morning = datetime(last_morning_check.year, last_morning_check.month, last_morning_check.day, 6, 0, 0)
            
            days_since_last_check = (today_morning - last_morning).days
            
            if days_since_last_check > 0:
                total_cookies = days_since_last_check * cookies_per_morning
                finance_cookie_count += total_cookies
                
                print(f"Grandma J: {total_cookies} cookies added for {days_since_last_check} missed mornings")
                # Son kontrol zamanını güncelle
                last_morning_check = today_morning
        
        elif finance_name == "kingmidas" and finance_data["current_level"] > 0:
            # King Midas için ayrı bir kontrol yapmaya gerek yok, 
            # apply_finance_effects fonksiyonu zaten çalışıyor
            pass

    # Oyun verilerini kaydet
    if current_user:
        save_game_data(current_user)

def get_growth_multiplier():
    """Büyüme hızı çarpanını döndürür"""
    growth_multiplier = 1.0
    for finance_name in active_finances:
        finance_data = FINANCES[finance_name]
        if finance_name == "molefriend" and finance_data["current_level"] > 0:
            growth_multiplier += finance_data["levels"][finance_data["current_level"]]["growth_speed"]
    return growth_multiplier

def draw_adopter_tab(screen, menu_x, menu_y, menu_width, menu_height):
    global jamal_current_dog_index
    
    buttons = []
    
    # Draw Jamal's dogs - TÜM köpekleri al, filtreleme yapma
    jamal_title = font_main.render("Secret Boy's Dogs", True, WHITE)
    screen.blit(jamal_title, (menu_x + 20, menu_y + 80))
    
    # Tüm özel köpekleri al (filtreleme yapma)
    dog_names = sorted(SPECIAL_DOG_REQUIREMENTS.keys())
    num_dogs = len(dog_names)
    
    # Eğer hiç köpek yoksa, hata önleme
    if num_dogs == 0:
        return buttons
    
    # Geçerli indeksi sınırla
    jamal_current_dog_index = max(0, min(jamal_current_dog_index, num_dogs - 1))
    
    # Left/right arrows
    left_active = jamal_current_dog_index > 0
    right_active = jamal_current_dog_index < num_dogs - 1
    
    left_arrow = pygame.Rect(menu_x + 20, menu_y + menu_height//2 - 25, 50, 50)
    right_arrow = pygame.Rect(menu_x + menu_width - 70, menu_y + menu_height//2 - 25, 50, 50)
    
    pygame.draw.polygon(screen, (255, 255, 255) if left_active else (100, 100, 100), 
                       [(left_arrow.x + 35, left_arrow.y + 10),
                        (left_arrow.x + 15, left_arrow.y + 25),
                        (left_arrow.x + 35, left_arrow.y + 40)])
    
    pygame.draw.polygon(screen, (255, 255, 255) if right_active else (100, 100, 100), 
                       [(right_arrow.x + 15, right_arrow.y + 10),
                        (right_arrow.x + 35, right_arrow.y + 25),
                        (right_arrow.x + 15, right_arrow.y + 40)])

    # Current dog display
    current_dog = dog_names[jamal_current_dog_index]
    if current_dog in dog_images:
        dog_img = dog_images[current_dog]["idle"]
        img_x = menu_x + (menu_width - dog_img.get_width()) // 2
        img_y = menu_y + 150
        screen.blit(dog_img, (img_x, img_y))
        
        # Köpeğin sahip olunup olunmadığını kontrol et
        owned = any(dog.base_name == current_dog for dog in active_dogs)
        
        # Requirements - sadece sahip değilse göster
        if not owned:
            requirements = SPECIAL_DOG_REQUIREMENTS[current_dog]
            req_text = []
            for item, amount in requirements.items():
                current_amount = globals()[f"{item}_count"]
                req_text.append(f"{current_amount}/{amount} {item}")
            
            req_surface = font_small.render(f"Requires: {', '.join(req_text)}", True, WHITE)
            screen.blit(req_surface, (menu_x + menu_width//2 - req_surface.get_width()//2, img_y + dog_img.get_height() + 10))
        else:
            # Sahip olunan köpek için mesaj göster
            owned_text = font_small.render("OWNED", True, (0, 255, 0))
            screen.blit(owned_text, (menu_x + menu_width//2 - owned_text.get_width()//2, img_y + dog_img.get_height() + 10))

    # Trade button - sadece sahip değilse göster
    if not owned:
        button_rect = pygame.Rect(menu_x + menu_width//2 - 60, img_y + dog_img.get_height() + 40, 120, 40)
        can_afford = all(globals()[f"{item}_count"] >= amount for item, amount in requirements.items())
        
        if can_afford:
            pygame.draw.rect(screen, GREEN_BUTTON, button_rect, border_radius=5)
            text = font_main.render("ADOPT", True, WHITE)
        else:
            pygame.draw.rect(screen, (50, 50, 50), button_rect, border_radius=5)
            text = font_main.render("NEED MORE", True, WHITE)
        
        screen.blit(text, (button_rect.centerx - text.get_width()//2, button_rect.centery - text.get_height()//2))
        
        # Butonu listeye ekle
        buttons.append({"rect": button_rect, "action": "trade_dog", "dog_type": current_dog})
    else:
        # Sahip olunan köpek için bilgi mesajı
        owned_msg = font_main.render("ALREADY OWNED", True, (0, 255, 0))
        screen.blit(owned_msg, (menu_x + menu_width//2 - owned_msg.get_width()//2, img_y + dog_img.get_height() + 40))

    # Add navigation buttons to list
    buttons.extend([
        {"rect": left_arrow, "action": "prev_jamal_dog", "active": left_active},
        {"rect": right_arrow, "action": "next_jamal_dog", "active": right_active}
    ])
    
    return buttons


def draw_trendshop_tab(screen, buttons, current_tab):
    # Colors
    TAB_COLOR = (200, 200, 200)
    ACTIVE_TAB_COLOR = (240, 240, 240)
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)
    BLUE_BUTTON = (70, 130, 180)
    
    # Fonts
    font_small = pygame.font.SysFont("Arial", 14)
    font_medium = pygame.font.SysFont("Arial", 16)
    font_large = pygame.font.SysFont("Arial", 24, bold=True)
    
    # Menu dimensions
    menu_width = 800
    menu_height = 600
    menu_x = (screen.get_width() - menu_width) // 2
    menu_y = (screen.get_height() - menu_height) // 2
    
    # Draw menu background
    pygame.draw.rect(screen, ACTIVE_TAB_COLOR, (menu_x, menu_y, menu_width, menu_height), border_radius=10)
    
    # Draw tab title
    title_text = font_large.render("Trend Shop", True, BLACK)
    screen.blit(title_text, (menu_x + 20, menu_y + 20))
    
    # Add Adopter button
    adopter_button = pygame.Rect(menu_x + menu_width - 180, menu_y + 20, 150, 30)
    pygame.draw.rect(screen, BLUE_BUTTON, adopter_button, border_radius=5)
    adopter_text = font_small.render("Go to Adopter", True, WHITE)
    screen.blit(adopter_text, (adopter_button.centerx - adopter_text.get_width()//2, 
                             adopter_button.centery - adopter_text.get_height()//2))
    
    buttons.append({
        "rect": adopter_button,
        "action": "switch_to_adopter"  
    })
    
    # Draw tab content area (placeholder)
    content_rect = pygame.Rect(menu_x + 20, menu_y + 70, menu_width - 40, menu_height - 90)
    pygame.draw.rect(screen, WHITE, content_rect, border_radius=5)
    
    # Placeholder text
    placeholder = font_medium.render("Trend Shop Content Goes Here", True, (150, 150, 150))
    screen.blit(placeholder, (content_rect.centerx - placeholder.get_width()//2, 
                             content_rect.centery - placeholder.get_height()//2))
    
    return buttons

def add_xp(amount, source_position=None):
    global xp_amount, player_level, xp_to_next_level, gold_amount
    
    xp_amount += amount
    
    # Animasyon ekle
    if source_position:
        xp_collection_animations.append(XPAnimation(source_position[0], source_position[1], amount))
    
    # Seviye atlama kontrolü - SABİT 7,500 XP
    while xp_amount >= xp_to_next_level:
        xp_amount -= xp_to_next_level
        player_level += 1
        xp_to_next_level = 5000  # <-- SABİT DEĞER
        show_message(f"Level Up! Now Level {player_level}")
        
        # Seviye atlama bonusu
        gold_amount += player_level * 10
        show_message(f"Level bonus: {player_level * 10} gold!")

def award_xp_for_action(action_type, position=None):
    xp_values = {
        "harvest": 150,
        "plant": 50,
        "till": 30,
        "buy_dog": 500,
        "complete_task": 300,
        "achievement": 1000
    }
    
    if action_type in xp_values:
        add_xp(xp_values[action_type], position)

def draw_xp_path_menu(screen):
    global claimed_rewards, xp_current_page
    
    menu_width = SCREEN_WIDTH * 0.8
    menu_height = SCREEN_HEIGHT * 0.7
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2

    # Background
    pygame.draw.rect(screen, (40, 40, 60), (menu_x, menu_y, menu_width, menu_height), border_radius=15)
    pygame.draw.rect(screen, (60, 60, 80), (menu_x + 5, menu_y + 5, menu_width - 10, menu_height - 10), border_radius=10)

    # Title
    title_text = font_main.render("XP PATH - LEVEL PROGRESSION", True, (255, 215, 0))
    screen.blit(title_text, (menu_x + menu_width // 2 - title_text.get_width() // 2, menu_y + 20))

    # Current level and XP
    level_text = font_main.render(f"Level {player_level}", True, WHITE)
    screen.blit(level_text, (menu_x + 30, menu_y + 60))
    
    xp_text = font_small.render(f"XP: {xp_amount}/{xp_to_next_level}", True, WHITE)
    screen.blit(xp_text, (menu_x + 30, menu_y + 90))
    
    # XP bar
    xp_bar_width = menu_width - 100
    xp_bar_rect = pygame.Rect(menu_x + 50, menu_y + 120, xp_bar_width, 20)
    pygame.draw.rect(screen, (50, 50, 50), xp_bar_rect, border_radius=10)
    
    if xp_to_next_level > 0:
        fill_width = (xp_amount / xp_to_next_level) * xp_bar_width
        fill_rect = pygame.Rect(menu_x + 50, menu_y + 120, fill_width, 20)
        pygame.draw.rect(screen, (255, 215, 0), fill_rect, border_radius=10)
    
    pygame.draw.rect(screen, WHITE, xp_bar_rect, 2, border_radius=10)

    # Page navigation
    total_rewards = len(XP_REWARDS)
    total_pages = (total_rewards + xp_rewards_per_page - 1) // xp_rewards_per_page
    
    page_text = font_small.render(f"Page {xp_current_page + 1}/{total_pages}", True, WHITE)
    screen.blit(page_text, (menu_x + menu_width // 2 - page_text.get_width() // 2, menu_y + 150))

    # Horizontal scrollable rewards
    buttons = []
    reward_width = (menu_width - 100) // xp_rewards_per_page
    start_index = xp_current_page * xp_rewards_per_page
    
    for i in range(xp_rewards_per_page):
        reward_index = start_index + i
        if reward_index >= total_rewards:
            break
            
        level = list(sorted(XP_REWARDS.keys()))[reward_index]
        reward = XP_REWARDS[level]
        
        # Reward box position
        reward_x = menu_x + 50 + (i * reward_width)
        reward_y = menu_y + 180
        reward_rect = pygame.Rect(reward_x, reward_y, reward_width - 20, 200)
        
        # Color: reached? reward claimed?
        if level <= player_level:
            if level in claimed_rewards:
                color = (100, 100, 100)  # Claimed
            else:
                color = (0, 150, 0)  # Claimable
        else:
            color = (50, 50, 50)  # Unreachable
        
        pygame.draw.rect(screen, color, reward_rect, border_radius=8)
        pygame.draw.rect(screen, WHITE, reward_rect, 2, border_radius=8)
        
        # Level info
        level_label = font_main.render(f"Level {level}", True, WHITE)
        screen.blit(level_label, (reward_rect.centerx - level_label.get_width() // 2, reward_rect.y + 15))
        
        # Reward icon
        if reward["icon"] in icon_images:
            icon_img = icon_images[reward["icon"]]
            icon_x = reward_rect.centerx - icon_img.get_width() // 2
            icon_y = reward_rect.y + 45
            screen.blit(icon_img, (icon_x, icon_y))
        
        # Reward info - Now shows "Mystery Box"
        reward_text = get_reward_description(reward)
        reward_label = font_small.render(reward_text, True, WHITE)
        screen.blit(reward_label, (reward_rect.centerx - reward_label.get_width() // 2, 
                                 reward_rect.y + 100))
        
        # Button (only for claimable rewards)
        if level <= player_level and level not in claimed_rewards:
            claim_button = pygame.Rect(reward_rect.centerx - 40, reward_rect.bottom - 35, 80, 30)
            pygame.draw.rect(screen, BLUE_BUTTON, claim_button, border_radius=5)
            claim_text = font_small.render("Open", True, WHITE)
            screen.blit(claim_text, (claim_button.centerx - claim_text.get_width() // 2, 
                                   claim_button.centery - claim_text.get_height() // 2))
            
            buttons.append({"rect": claim_button, "action": "claim_reward", "level": level})
        elif level in claimed_rewards:
            claimed_text = font_small.render("OPENED", True, (200, 200, 200))
            screen.blit(claimed_text, (reward_rect.centerx - claimed_text.get_width() // 2, 
                                     reward_rect.bottom - 30))

    # Navigation buttons
    left_active = xp_current_page > 0
    right_active = xp_current_page < total_pages - 1
    
    left_arrow = pygame.Rect(menu_x + 20, menu_y + menu_height // 2 - 25, 50, 50)
    right_arrow = pygame.Rect(menu_x + menu_width - 70, menu_y + menu_height // 2 - 25, 50, 50)
    
    pygame.draw.polygon(screen, WHITE if left_active else (100, 100, 100), 
                       [(left_arrow.x + 35, left_arrow.y + 10),
                        (left_arrow.x + 15, left_arrow.y + 25),
                        (left_arrow.x + 35, left_arrow.y + 40)])
    
    pygame.draw.polygon(screen, WHITE if right_active else (100, 100, 100), 
                       [(right_arrow.x + 15, right_arrow.y + 10),
                        (right_arrow.x + 35, right_arrow.y + 25),
                        (right_arrow.x + 15, right_arrow.y + 40)])

    # Close button
    close_button = pygame.Rect(menu_x + menu_width // 2 - 40, menu_y + menu_height - 50, 80, 30)
    pygame.draw.rect(screen, RED_BUTTON, close_button, border_radius=5)
    close_text = font_main.render("Close", True, WHITE)
    screen.blit(close_text, (close_button.centerx - close_text.get_width() // 2, 
                           close_button.centery - close_text.get_height() // 2))
    
    buttons.extend([
        {"rect": left_arrow, "action": "prev_xp_page", "active": left_active},
        {"rect": right_arrow, "action": "next_xp_page", "active": right_active},
        {"rect": close_button, "action": "close_xp_path"}
    ])
    
    return buttons

def wrap_text(text, font, max_width):
    """Metni belirli genişliğe sığacak şekilde sarar"""
    words = text.split(' ')
    lines = []
    current_line = []
    
    for word in words:
        test_line = ' '.join(current_line + [word])
        if font.size(test_line)[0] <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    
    if current_line:
        lines.append(' '.join(current_line))
    
    return lines

def get_reward_description(reward):
    if reward["type"] == "gold":
        return f"{reward['amount']} Gold"
    elif reward["type"] == "cookie":
        return f"{reward['amount']} Cookies"
    elif reward["type"] == "seeds":
        return f"{reward['amount']} Seed Pack"
    elif reward["type"] == "ticket":
        return f"{reward['amount']} Ticket"
    elif reward["type"] == "special_dog":
        return f"Special Dog: {reward['dog_type'].capitalize()}"
    elif reward["type"] == "special_outfit":
        return f"Outfit: {reward['outfit'].capitalize()}"
    return "Unknown Reward"



def toggle_outfit(outfit_name):
    global active_dogs
    base_dog = outfit_name.split("_")[0]
    
    # Find the base dog in active_dogs
    base_dog_index = next((i for i, d in enumerate(active_dogs) if d.name == base_dog), None)
    
    if base_dog_index is not None:
        # If the base dog exists, update its outfit
        active_dogs[base_dog_index].change_outfit(outfit_name)
    else:
        # If base dog doesn't exist, we shouldn't be able to buy/equip outfits for it
        print(f"Error: Base dog {base_dog} not found for outfit {outfit_name}")

def claim_xp_reward(level):
    global claimed_rewards, gold_amount, finance_cookie_count, ticket_count, active_dogs
    global seed_cotton_count, seed_corn_count, seed_carrot_count, seed_wheat_count
    
    if level not in XP_REWARDS or level in claimed_rewards or level > player_level:
        return False
    
    reward_data = XP_REWARDS[level]
    
    if reward_data["type"] == "mystery_box":
        box_rarity = get_random_box_rarity()
        reward_pool = MYSTERY_BOX_REWARDS[box_rarity]
        
        # Ödülü BİR KEZ seç
        selected_reward = select_reward_from_pool(reward_pool, box_rarity)
        
        # Animasyonu başlat - seçilen ödülü ve kutu türünü gönder
        start_box_animation(selected_reward, box_rarity)
        
        def apply_reward():
            apply_mystery_box_reward(selected_reward, box_rarity)
        
        global pending_reward_function
        pending_reward_function = apply_reward
    
    claimed_rewards.add(level)
    
    def save_after_animation():
        if current_user:
            save_game_data(current_user)
    
    global pending_save_function
    pending_save_function = save_after_animation
    
    return True

def select_reward_from_pool(reward_pool, box_rarity):
    """Ödülü doğru şekilde seçer - GÜNCELLENDİ"""
    # Finansman ödüllerini kontrol et
    finance_rewards = [r for r in reward_pool if r["type"] == "finance"]
    if finance_rewards and random.random() <= finance_rewards[0].get("chance", 0.5):
        return get_random_finance_reward()
    
    # Outfit ödüllerini kontrol et
    outfit_rewards = [r for r in reward_pool if r["type"] == "outfit"]
    if outfit_rewards and random.random() <= outfit_rewards[0].get("chance", 0.5):
        return get_random_outfit_reward()
    
    # Normal ödüllerden seç
    normal_rewards = [r for r in reward_pool if r["type"] not in ["finance", "outfit"]]
    selected_reward = random.choice(normal_rewards)
    
    # Special dog için şans kontrolü
    if selected_reward["type"] == "special_dog" and "chance" in selected_reward:
        if random.random() > selected_reward["chance"]:
            # Şans tutmazsa başka normal ödül seç
            normal_rewards = [r for r in normal_rewards if r["type"] != "special_dog"]
            if normal_rewards:
                selected_reward = random.choice(normal_rewards)
            else:
                selected_reward = {"type": "gold", "amount": (100, 200)}
    
    return selected_reward

def apply_mystery_box_reward(selected_reward, box_rarity):
    """Mystery Box ödülünü uygular"""
    global gold_amount, finance_cookie_count, seed_carrot_count, seed_corn_count, seed_cotton_count, seed_wheat_count, ticket_count, active_dogs
    
    reward_type = selected_reward["type"]
    
    if reward_type == "gold":
        amount = random.randint(selected_reward["amount"][0], selected_reward["amount"][1])
        gold_amount += amount
        show_message(f"🎁 {box_rarity.upper()} Box: {amount} gold!")
        
    elif reward_type == "cookie":
        amount = random.randint(selected_reward["amount"][0], selected_reward["amount"][1])
        finance_cookie_count += amount
        show_message(f"🎁 {box_rarity.upper()} Box: {amount} cookie!")
        
    elif reward_type == "seeds":
        amount = random.randint(selected_reward["amount"][0], selected_reward["amount"][1])
        seed_types = ["carrot", "wheat", "corn", "cotton"]
        for _ in range(amount):
            seed_type = random.choice(seed_types)
            if seed_type == "carrot":
                seed_carrot_count += 1
            elif seed_type == "wheat":
                seed_wheat_count += 1
            elif seed_type == "corn":
                seed_corn_count += 1
            elif seed_type == "cotton":
                seed_cotton_count += 1
        show_message(f"🎁 {box_rarity.upper()} Box: {amount} random seed!")
        
    elif reward_type == "ticket":
        amount = random.randint(selected_reward["amount"][0], selected_reward["amount"][1])
        ticket_count += amount
        show_message(f"🎁 {box_rarity.upper()} Box: {amount} ticket!")
        
    elif reward_type == "special_dog":
        dog_type = selected_reward["dog_type"]
        if not any(dog.base_name == dog_type for dog in active_dogs):
            valid_position = False
            attempts = 0
            max_attempts = 20
            
            while not valid_position and attempts < max_attempts:
                spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[dog_type]["idle"].get_width())
                spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[dog_type]["idle"].get_height())
                
                temp_dog = Dog(dog_type, spawn_x, spawn_y)
                valid_position = temp_dog.is_position_valid(spawn_x, spawn_y)
                attempts += 1
            
            if valid_position:
                new_dog = Dog(dog_type, spawn_x, spawn_y)
                active_dogs.append(new_dog)
                show_message(f"🎁 {box_rarity.upper()} Box: Special {dog_type.capitalize()} dog!")
            else:
                show_message(f"🎁 {box_rarity.upper()} Box: {dog_type} dog didn't like you, you earned 200 gold!")
                gold_amount += 200
        else:
            show_message(f"🎁 {box_rarity.upper()} Box: You already have {dog_type} , you earned 150 gold!")
            gold_amount += 150
            
    elif reward_type == "finance":
        # Finansman ödülü - şansa bağlı
        if random.random() <= selected_reward.get("chance", 0.5):
            finance_reward = get_random_finance_reward()
            apply_finance_mystery_reward(finance_reward, box_rarity)
        else:
            # Şans tutmazsa normal ödül
            normal_rewards = [r for r in MYSTERY_BOX_REWARDS[box_rarity] if r["type"] in ["gold", "cookie", "seeds", "ticket"]]
            if normal_rewards:
                fallback_reward = random.choice(normal_rewards)
                apply_mystery_box_reward(fallback_reward, box_rarity)
            else:
                gold_amount += 100
                show_message(f"🎁 {box_rarity.upper()} Box: 100 gold!")
                
    elif reward_type == "outfit":
        # Outfit ödülü - şansa bağlı
        if random.random() <= selected_reward.get("chance", 0.5):
            outfit_reward = get_random_outfit_reward()
            apply_outfit_mystery_reward(outfit_reward, box_rarity)
        else:
            # Şans tutmazsa normal ödül
            normal_rewards = [r for r in MYSTERY_BOX_REWARDS[box_rarity] if r["type"] in ["gold", "cookie", "seeds", "ticket"]]
            if normal_rewards:
                fallback_reward = random.choice(normal_rewards)
                apply_mystery_box_reward(fallback_reward, box_rarity)
            else:
                gold_amount += 100
                show_message(f"🎁 {box_rarity.upper()} Box: 100 gold!")
                
def apply_finance_mystery_reward(finance_reward, box_rarity):
    """Finansman mystery box ödülünü uygular - YENİ SİSTEM"""
    global active_finances
    
    finance_name = finance_reward["finance"]
    reward_type = finance_reward["reward_type"]
    
    if reward_type == "new_finance":
        # Yeni finansman kazanma
        FINANCES[finance_name]["current_level"] = 1
        show_message(f"🎁 {box_rarity.upper()} Box: You unlocked {FINANCES[finance_name]['name']}!")
        
    elif reward_type == "upgrade":
        # Mevcut finansmanı yükseltme
        current_level = FINANCES[finance_name]["current_level"]
        if current_level < 3:
            FINANCES[finance_name]["current_level"] += 1
            new_level = FINANCES[finance_name]["current_level"]
            show_message(f"🎁 {box_rarity.upper()} Box: {FINANCES[finance_name]['name']} upgraded to level {new_level}!")
        else:
            # Zaten maksimum seviyedeyse altın ver
            gold_amount += 200
            show_message(f"🎁 {box_rarity.upper()} Box: Financier is maxed out, you earned 200 gold!")
            
def get_random_outfit_reward():
    """Rastgele bir outfit ödülü döndürür"""
    unowned_outfits = get_unowned_outfits()
    
    if unowned_outfits:
        # Sahip olunmayan outfit'lerden rastgele seç
        selected_outfit = random.choice(unowned_outfits)
        return {"type": "outfit_reward", "outfit": selected_outfit}
    else:
        # Tüm outfit'ler sahipse, altın ödülü ver
        return {"type": "gold", "amount": (200, 300)}

def apply_outfit_mystery_reward(outfit_reward, box_rarity):
    """Outfit mystery box ödülünü uygular"""
    global gold_amount
    
    reward_type = outfit_reward["type"]
    
    if reward_type == "outfit_reward":
        outfit_name = outfit_reward["outfit"]
        base_dog = OUTFIT_REQUIREMENTS[outfit_name]["dog"]
        
        # Köpeği bul ve outfit'i ekle
        for dog in active_dogs:
            if dog.base_name == base_dog:
                if outfit_name not in dog.outfits:
                    dog.outfits.append(outfit_name)
                    show_message(f"🎁 {box_rarity.upper()} Box: {base_dog.capitalize()}  got {OUTFIT_DISPLAY_NAMES[outfit_name]} outfit!")
                    print(f"Outfit kazanıldı: {outfit_name} for {base_dog}")
                    return
                else:
                    # Zaten sahipse altın ver
                    gold_amount += 150
                    show_message(f"🎁 {box_rarity.upper()} Box: Your dog already has that outfit, you got 150 gold!")
                    return
        
        # Köpek yoksa altın ver
        gold_amount += 100
        show_message(f"🎁 {box_rarity.upper()} Box: You don't have that dog, you got 100 gold!")
        
    elif reward_type == "gold":
        amount = random.randint(outfit_reward["amount"][0], outfit_reward["amount"][1])
        gold_amount += amount
        show_message(f"🎁 {box_rarity.upper()} Box: You got {amount} gold!")





        


def trade_for_dog(dog_type):
    global carrot_count, wheat_count, corn_count, cotton_count, active_dogs
    
    if dog_type not in SPECIAL_DOG_REQUIREMENTS:
        return False
    
    # Check if already owned - BASE isme göre kontrol et  
    if is_dog_owned(dog_type):
        print(f"You already own a {dog_type.capitalize()}!")
        return False
    
    requirements = SPECIAL_DOG_REQUIREMENTS[dog_type]
    
    # Check if player meets all requirements
    meets_requirements = True
    for item, amount in requirements.items():
        if globals()[f"{item}_count"] < amount:
            meets_requirements = False
            break
    
    if meets_requirements:
        # Deduct resources
        for item, amount in requirements.items():
            globals()[f"{item}_count"] -= amount
        
        # Create new dog
        spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[dog_type]["idle"].get_width())
        spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[dog_type]["idle"].get_height())
        new_dog = Dog(dog_type, spawn_x, spawn_y)
        
        # SKELEDOG ÖZEL: Inferno outfitini otomatik ekle
        if dog_type == "skele-dog":
            new_dog.outfits.append("inferno")
        
        active_dogs.append(new_dog)
        return True
    
    return False





def get_item_count(item_type):
    global carrot_count, wheat_count, corn_count, cotton_count
    if item_type == "carrot":
        return carrot_count
    elif item_type == "wheat":
        return wheat_count
    elif item_type == "corn":
        return corn_count
    elif item_type == "cotton":
        return cotton_count
    return 0

def get_seed_count(seed_type):
    global seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count
    if seed_type == "carrot":
        return seed_carrot_count
    elif seed_type == "wheat":
        return seed_wheat_count
    elif seed_type == "corn":
        return seed_corn_count
    elif seed_type == "cotton":
        return seed_cotton_count
    return 0

def sell_item(item_type, sell_all=False):
    global carrot_count, wheat_count, corn_count, cotton_count, gold_amount
    if item_type == "carrot" and carrot_count > 0:
        if sell_all:
            sold = carrot_count
            carrot_count = 0
            gold_amount += PRODUCT_PRICES["carrot"] * sold
            print(f"Sold {sold} Carrots for {PRODUCT_PRICES['carrot'] * sold} gold. Total gold: {gold_amount}")
        else:
            carrot_count -= 1
            gold_amount += PRODUCT_PRICES["carrot"]
            print(f"Sold 1 Carrot for {PRODUCT_PRICES['carrot']} gold. Total gold: {gold_amount}")
        coin_sound.play()  # <- Bu satırı ekleyin
    elif item_type == "wheat" and wheat_count > 0:
        if sell_all:
            sold = wheat_count
            wheat_count = 0
            gold_amount += PRODUCT_PRICES["wheat"] * sold
            print(f"Sold {sold} Wheat for {PRODUCT_PRICES['wheat'] * sold} gold. Total gold: {gold_amount}")
        else:
            wheat_count -= 1
            gold_amount += PRODUCT_PRICES["wheat"]
            print(f"Sold 1 Wheat for {PRODUCT_PRICES['wheat']} gold. Total gold: {gold_amount}")
        coin_sound.play()  # <- Bu satırı ekleyin
    elif item_type == "corn" and corn_count > 0:
        if sell_all:
            sold = corn_count
            corn_count = 0
            gold_amount += PRODUCT_PRICES["corn"] * sold
            print(f"Sold {sold} Corn for {PRODUCT_PRICES['corn'] * sold} gold. Total gold: {gold_amount}")
        else:
            corn_count -= 1
            gold_amount += PRODUCT_PRICES["corn"]
            print(f"Sold 1 Corn for {PRODUCT_PRICES['corn']} gold. Total gold: {gold_amount}")
        coin_sound.play()  # <- Bu satırı ekleyin
    elif item_type == "cotton" and cotton_count > 0:
        if sell_all:
            sold = cotton_count
            cotton_count = 0
            gold_amount += PRODUCT_PRICES["cotton"] * sold
            print(f"Sold {sold} Cotton for {PRODUCT_PRICES['cotton'] * sold} gold. Total gold: {gold_amount}")
        else:
            cotton_count -= 1
            gold_amount += PRODUCT_PRICES["cotton"]
            print(f"Sold 1 Cotton for {PRODUCT_PRICES['cotton']} gold. Total gold: {gold_amount}")
        coin_sound.play()  # <- Bu satırı ekleyin
    else:
        print(f"No {item_type.capitalize()} to sell.")
        
def buy_seed(seed_type, buy_all=False):
    global seed_carrot_count, seed_wheat_count, seed_corn_count, seed_cotton_count, gold_amount
    price = SEED_PRICES[seed_type]
    
    if buy_all:
        max_affordable = int(gold_amount // price)
        if max_affordable > 0:
            gold_amount -= max_affordable * price
            if seed_type == "carrot":
                seed_carrot_count += max_affordable
            elif seed_type == "wheat":
                seed_wheat_count += max_affordable
            elif seed_type == "corn":
                seed_corn_count += max_affordable
            elif seed_type == "cotton":  
                seed_cotton_count += max_affordable
            print(f"Bought {max_affordable} {seed_type.capitalize()} seeds for {max_affordable * price} gold. Total gold: {gold_amount}")
        else:
            print(f"Not enough gold to buy any {seed_type.capitalize()} seeds. Need {price} gold.")
    else:
        if gold_amount >= price:
            gold_amount -= price
            if seed_type == "carrot":
                seed_carrot_count += 1
            elif seed_type == "wheat":
                seed_wheat_count += 1
            elif seed_type == "corn":
                seed_corn_count += 1
            elif seed_type == "cotton":  
                seed_cotton_count += 1
            print(f"Bought 1 {seed_type.capitalize()} seed for {price} gold. Total gold: {gold_amount}")
        else:
            print(f"Not enough gold to buy {seed_type.capitalize()} seed. Need {price} gold.")


def is_dog_owned(dog_base_name):
    """Aynı base köpeğin herhangi bir outfitinin owned olup olmadığını kontrol eder"""
    return any(dog.base_name == dog_base_name for dog in active_dogs)


dog_animation_dog_type = None
dog_animation_position = (0, 0)


  # 3 saniye
dog_animation_dog_type = None
dog_animation_stage = 0
dog_reward_display_timer = 0
dog_reward_display_duration = 2.0  # Ödül gösterim süresi

def start_dog_animation(dog_type):
    """Köpek satın alma animasyonunu başlatır - kutu animasyonu gibi"""
    global dog_animation_active, dog_animation_timer, dog_animation_dog_type, dog_animation_stage, dog_reward_display_timer
    
    dog_animation_active = True
    dog_animation_timer = 0
    dog_animation_dog_type = dog_type
    dog_animation_stage = 0
    dog_reward_display_timer = 0

def draw_dog_animation(screen):
    """Köpek satın alma animasyonunu çizer - kutu animasyonu gibi"""
    global dog_animation_timer, dog_animation_duration, dog_animation_stage
    global dog_animation_dog_type, dog_reward_display_timer, dog_reward_display_duration
    
    if not dog_animation_active:
        return
    
    current_timer = dog_animation_timer
    current_duration = dog_animation_duration
    current_stage = dog_animation_stage
    current_dog_type = dog_animation_dog_type
    
    # Dark background overlay - TÜM EKRANI kaplasın
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))  # Daha koyu overlay
    screen.blit(overlay, (0, 0))
    
    if current_stage == 0:  
        # Köpek belirme animasyonu
        anim_progress = current_timer / (current_duration * 0.3)
        alpha = min(255, int(anim_progress * 255))
        scale = 0.5 + (anim_progress * 0.5)
        
        if current_dog_type in dog_images:
            dog_img = dog_images[current_dog_type]["idle"]
            scaled_dog = pygame.transform.scale(dog_img, 
                                              (int(dog_img.get_width() * scale), 
                                               int(dog_img.get_height() * scale)))
            scaled_dog.set_alpha(alpha)
            
            screen.blit(scaled_dog, 
                       (SCREEN_WIDTH//2 - scaled_dog.get_width()//2, 
                        SCREEN_HEIGHT//2 - scaled_dog.get_height()//2))
    
    elif current_stage == 1:  
        # Köpek sallanma animasyonu
        anim_progress = current_timer / (current_duration * 0.3)
        shake_intensity = 15 * (1 - anim_progress)  # Daha fazla sallanma
        shake_x = random.randint(-int(shake_intensity), int(shake_intensity))
        shake_y = random.randint(-int(shake_intensity), int(shake_intensity))
        
        if current_dog_type in dog_images:
            dog_img = dog_images[current_dog_type]["idle"]
            screen.blit(dog_img, 
                       (SCREEN_WIDTH//2 - dog_img.get_width()//2 + shake_x, 
                        SCREEN_HEIGHT//2 - dog_img.get_height()//2 + shake_y))
            
            # Glow effect - farklı renkler
            if random.random() < 0.4:
                glow_color = (100, 200, 255, 100)  # Mavi glow
                glow = pygame.Surface((dog_img.get_width() + 30, dog_img.get_height() + 30), pygame.SRCALPHA)
                pygame.draw.rect(glow, glow_color, glow.get_rect(), border_radius=15)
                screen.blit(glow, 
                           (SCREEN_WIDTH//2 - glow.get_width()//2 + shake_x, 
                            SCREEN_HEIGHT//2 - glow.get_height()//2 + shake_y))
    
    elif current_stage == 2:  
        # Işık patlaması animasyonu
        anim_progress = current_timer / (current_duration * 0.4)
        flash_alpha = int(255 * (1 - anim_progress))
        flash = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        
        # Köpek türüne göre renk
        colors = {
            "banana": (255, 255, 100),
            "dolly": (255, 100, 255),
            "shelby": (100, 255, 255),
            "rex": (255, 100, 100),
            "skele-dog": (150, 150, 150),
            "fire": (255, 50, 50),
            "emerald": (50, 255, 50)
        }
        color = colors.get(current_dog_type, (255, 255, 255))
        
        pygame.draw.circle(flash, (*color, flash_alpha), 
                          (SCREEN_WIDTH//2, SCREEN_HEIGHT//2), 
                          int(300 * (1 - anim_progress)))
        screen.blit(flash, (0, 0))
    
    elif current_stage == 3: 
        # Köpek gösterimi - bu aşama daha uzun sürer
        display_progress = dog_reward_display_timer / dog_reward_display_duration
        
        # Köpek görseli
        if current_dog_type in dog_images:
            dog_img = dog_images[current_dog_type]["idle"]
            
            # Köpek animasyonu (hafif zıplama)
            dog_scale = 1.0 + 0.1 * math.sin(dog_reward_display_timer * 4)
            scaled_dog = pygame.transform.scale(dog_img, 
                                              (int(dog_img.get_width() * dog_scale), 
                                               int(dog_img.get_height() * dog_scale)))
            
            screen.blit(scaled_dog, 
                       (SCREEN_WIDTH//2 - scaled_dog.get_width()//2, 
                        SCREEN_HEIGHT//2 - scaled_dog.get_height()//2 - 50))
        
        # Başlık
        title_text = font_main.render("NEW COMPANION JOINED!", True, (255, 215, 0))
        screen.blit(title_text, 
                   (SCREEN_WIDTH//2 - title_text.get_width()//2, 
                    SCREEN_HEIGHT//2 - 150))
        
        # Köpek ismi
        name_text = font_main.render(current_dog_type.upper(), True, (255, 255, 255))
        screen.blit(name_text, 
                   (SCREEN_WIDTH//2 - name_text.get_width()//2, 
                    SCREEN_HEIGHT//2 + 50))
        
        # Tebrik mesajı
        congrats_text = font_small.render("Congratulations on your new friend!", True, (200, 200, 200))
        screen.blit(congrats_text, 
                   (SCREEN_WIDTH//2 - congrats_text.get_width()//2, 
                    SCREEN_HEIGHT//2 + 90))
        
        # Geri sayım (son 1 saniye)
        if dog_reward_display_timer > dog_reward_display_duration - 1.0:
            countdown_alpha = int(255 * (1 - (dog_reward_display_duration - dog_reward_display_timer)))
            countdown_text = font_small.render("Closing...", True, (255, 255, 255))
            countdown_text.set_alpha(countdown_alpha)
            screen.blit(countdown_text, 
                       (SCREEN_WIDTH//2 - countdown_text.get_width()//2, 
                        SCREEN_HEIGHT//2 + 120))


def update_dog_animation(dt):
    """Köpek animasyonunu günceller - kutu animasyonu gibi"""
    global dog_animation_active, dog_animation_timer, dog_animation_duration
    global dog_reward_display_timer, dog_reward_display_duration, dog_animation_stage
    
    if not dog_animation_active:
        return False
    
    dog_animation_timer += dt
    
    # Animation stages
    if dog_animation_stage < 3:
        # İlk 3 aşama normal hızda
        stage_durations = [0.3, 0.3, 0.4]  # Her aşama için süreler
        current_stage_duration = dog_animation_duration * stage_durations[dog_animation_stage]
        
        if dog_animation_timer >= current_stage_duration:
            dog_animation_stage += 1
            dog_animation_timer = 0
            
            if dog_animation_stage >= 3:
                # Son aşamaya ulaşıldı, ödül gösterim zamanlayıcısını başlat
                dog_reward_display_timer = 0
    else:
        # Son aşama - köpek gösterimi
        dog_reward_display_timer += dt
        if dog_reward_display_timer >= dog_reward_display_duration:
            dog_animation_active = False
            return True
    
    return False



def buy_dog(dog_type):
    global gold_amount, active_dogs
    
    if dog_type not in DOG_PRICES:
        return False
    
    # Check if already owned - BASE isme göre kontrol et
    if is_dog_owned(dog_type):
        print(f"You already own a {dog_type.capitalize()}!")
        return False
    
    if gold_amount >= DOG_PRICES[dog_type]:
        gold_amount -= DOG_PRICES[dog_type]
        
        # Find a valid spawn position
        valid_position = False
        attempts = 0
        max_attempts = 20
        
        while not valid_position and attempts < max_attempts:
            spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[dog_type]["idle"].get_width())
            spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[dog_type]["idle"].get_height())
            
            # Create temporary dog to check position
            temp_dog = Dog(dog_type, spawn_x, spawn_y)
            valid_position = temp_dog.is_position_valid(spawn_x, spawn_y)
            attempts += 1
        
        if valid_position:
            new_dog = Dog(dog_type, spawn_x, spawn_y)
            active_dogs.append(new_dog)
            update_task_progress("buy_dog")
            award_xp_for_action("buy_dog", (spawn_x, spawn_y))
            
            # Köpek animasyonunu başlat - pozisyon gerekmez
            start_dog_animation(dog_type)
            
            return True
    
    return False

def start_box_animation(reward_data, box_rarity):
    """Kutu animasyonunu başlatır - artık enderlik parametre olarak geliyor"""
    global box_animation_active, box_animation_timer, box_animation_reward, box_animation_box_type, box_animation_stage
    
    box_animation_active = True
    box_animation_timer = 0
    box_animation_reward = reward_data
    box_animation_box_type = box_rarity  # Artık parametreden gelen enderlik
    box_animation_stage = 0
    
    print(f"🎁 Box rarity: {box_rarity}, Reward: {reward_data}")

def draw_box_animation(screen):
    global box_animation_timer, box_animation_duration, box_animation_stage
    global box_animation_reward, box_animation_box_type, reward_display_timer, reward_display_duration
    
    if not box_animation_active:
        return
    
    current_timer = box_animation_timer
    current_duration = box_animation_duration
    current_stage = box_animation_stage
    current_box_type = box_animation_box_type
    current_reward = box_animation_reward
    
    # Dark background overlay
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))  
    screen.blit(overlay, (0, 0))
    
    if current_stage == 0:  
        # Box appearance animation
        anim_progress = current_timer / (current_duration * 0.3)
        alpha = min(255, int(anim_progress * 255))
        scale = 0.5 + (anim_progress * 0.5)
        
        box_img = icon_images["trendshop"]
        scaled_box = pygame.transform.scale(box_img, 
                                          (int(box_img.get_width() * scale), 
                                           int(box_img.get_height() * scale)))
        scaled_box.set_alpha(alpha)
        
        screen.blit(scaled_box, 
                   (SCREEN_WIDTH//2 - scaled_box.get_width()//2, 
                    SCREEN_HEIGHT//2 - scaled_box.get_height()//2))
    
    elif current_stage == 1:  
        # Box shaking animation
        anim_progress = current_timer / (current_duration * 0.3)
        shake_intensity = 10 * (1 - anim_progress)
        shake_x = random.randint(-int(shake_intensity), int(shake_intensity))
        shake_y = random.randint(-int(shake_intensity), int(shake_intensity))
        
        box_img = icon_images["trendshop"]
        screen.blit(box_img, 
                   (SCREEN_WIDTH//2 - box_img.get_width()//2 + shake_x, 
                    SCREEN_HEIGHT//2 - box_img.get_height()//2 + shake_y))
        
        # Glow effect
        if random.random() < 0.3:
            glow = pygame.Surface((box_img.get_width() + 20, box_img.get_height() + 20), pygame.SRCALPHA)
            pygame.draw.rect(glow, (255, 255, 100, 100), glow.get_rect(), border_radius=10)
            screen.blit(glow, 
                       (SCREEN_WIDTH//2 - glow.get_width()//2 + shake_x, 
                        SCREEN_HEIGHT//2 - glow.get_height()//2 + shake_y))
    
    elif current_stage == 2:  
        # Light burst animation
        anim_progress = current_timer / (current_duration * 0.4)
        flash_alpha = int(255 * (1 - anim_progress))
        flash = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        
        colors = {
            "common": (200, 200, 200),
            "rare": (100, 200, 255),
            "epic": (180, 100, 255),
            "legendary": (255, 215, 0),
            "mythical": (255, 50, 50)
        }
        color = colors.get(current_box_type, (255, 255, 255))
        
        pygame.draw.circle(flash, (*color, flash_alpha), 
                          (SCREEN_WIDTH//2, SCREEN_HEIGHT//2), 
                          int(200 * (1 - anim_progress)))
        screen.blit(flash, (0, 0))
    
    elif current_stage == 3: 
        # Reward display - this stage lasts longer
        display_progress = reward_display_timer / reward_display_duration
        
        reward_type = current_reward["type"]
        if reward_type == "gold":
            icon = icon_images["gold"]
            amount = current_reward["amount"]
            if isinstance(amount, tuple):
                text = f"{amount[0]}-{amount[1]} Gold!"
            else:
                text = f"{amount} Gold!"
        elif reward_type == "cookie":
            icon = icon_images["cookie"]
            amount = current_reward["amount"]
            if isinstance(amount, tuple):
                text = f"{amount[0]}-{amount[1]} Cookies!"
            else:
                text = f"{amount} Cookies!"
        elif reward_type == "seeds":
            icon = icon_images["seed_carrot"]
            amount = current_reward["amount"]
            if isinstance(amount, tuple):
                text = f"{amount[0]}-{amount[1]} Seed Pack!"
            else:
                text = f"{amount} Seed Pack!"
        elif reward_type == "ticket":
            icon = icon_images["ticket"]
            amount = current_reward["amount"]
            if isinstance(amount, tuple):
                text = f"{amount[0]}-{amount[1]} Tickets!"
            else:
                text = f"{amount} Tickets!"
        elif reward_type == "special_dog":
            dog_type = current_reward["dog_type"]
            icon = icon_images.get(f"dog_{dog_type}_icon", icon_images["trendshop"])
            text = f"Special {dog_type.capitalize()} Dog!"
        elif reward_type == "finance":
            icon = icon_images["finance"]
            text = "New Finance!"
        elif reward_type == "outfit":
            icon = icon_images["wardrobe"]
            text = "New Outfit!"
        else:
            icon = icon_images["trendshop"]
            text = "Mystery Reward!"
        
        # Icon animation (slight bouncing)
        icon_scale = 1.0 + 0.1 * math.sin(reward_display_timer * 5)
        scaled_icon = pygame.transform.scale(icon, 
                                           (int(icon.get_width() * icon_scale), 
                                            int(icon.get_height() * icon_scale)))
        
        screen.blit(scaled_icon, 
                   (SCREEN_WIDTH//2 - scaled_icon.get_width()//2, 
                    SCREEN_HEIGHT//2 - scaled_icon.get_height()//2 - 50))
        
        # Box info
        box_text = font_main.render(f"{current_box_type.upper()} MYSTERY BOX", True, (255, 215, 0))
        screen.blit(box_text, 
                   (SCREEN_WIDTH//2 - box_text.get_width()//2, 
                    SCREEN_HEIGHT//2 - 150))
        
        # Reward text
        text_surface = font_main.render(text, True, (255, 255, 255))
        screen.blit(text_surface, 
                   (SCREEN_WIDTH//2 - text_surface.get_width()//2, 
                    SCREEN_HEIGHT//2 + 50))
        
        # Countdown (last 1 second)
        if reward_display_timer > reward_display_duration - 1.0:
            countdown_alpha = int(255 * (1 - (reward_display_duration - reward_display_timer)))
            countdown_text = font_small.render("Closing...", True, (255, 255, 255))
            countdown_text.set_alpha(countdown_alpha)
            screen.blit(countdown_text, 
                       (SCREEN_WIDTH//2 - countdown_text.get_width()//2, 
                        SCREEN_HEIGHT//2 + 100))
        
def update_box_animation(dt):
    global box_animation_active, box_animation_timer, box_animation_duration
    global reward_display_timer, reward_display_duration, box_animation_stage
    
    if not box_animation_active:
        return False
    
    box_animation_timer += dt
    
    # Animation stages
    if box_animation_stage < 3:
        # First 3 stages at normal speed
        stage_durations = [0.3, 0.3, 0.4]  # Adjusted durations for each stage
        current_stage_duration = box_animation_duration * stage_durations[box_animation_stage]
        
        if box_animation_timer >= current_stage_duration:
            box_animation_stage += 1
            box_animation_timer = 0
            
            if box_animation_stage >= 3:
                # Final stage reached, start reward display timer
                reward_display_timer = 0
    else:
        # Final stage - reward display
        reward_display_timer += dt
        if reward_display_timer >= reward_display_duration:
            box_animation_active = False
            return True
    
    return False

def trade_for_dog(dog_type):
    global carrot_count, wheat_count, corn_count, cotton_count, active_dogs
    
    if dog_type not in SPECIAL_DOG_REQUIREMENTS:
        return False
    
    # Check if already owned - BASE isme göre kontrol et  
    if is_dog_owned(dog_type):
        print(f"You already own a {dog_type.capitalize()}!")
        return False
    
    requirements = SPECIAL_DOG_REQUIREMENTS[dog_type]
    
    # Check if player meets all requirements
    meets_requirements = True
    for item, amount in requirements.items():
        if globals()[f"{item}_count"] < amount:
            meets_requirements = False
            break
    
    if meets_requirements:
        # Deduct resources
        for item, amount in requirements.items():
            globals()[f"{item}_count"] -= amount
        
        # Create new dog
        spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[dog_type]["idle"].get_width())
        spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[dog_type]["idle"].get_height())
        new_dog = Dog(dog_type, spawn_x, spawn_y)
        
        # SKELEDOG ÖZEL: Inferno outfitini otomatik ekle
        if dog_type == "skele-dog":
            new_dog.outfits.append("inferno")
        
        active_dogs.append(new_dog)
        
        # Köpek animasyonunu başlat - pozisyon gerekmez
        start_dog_animation(dog_type)
        
        return True
    
    return False


def draw_vip_shop_menu(screen):
    global current_buttons_in_jamal_shop, vip_current_dog_index
    
    # Kullanıcı verilerini yükle
    user_data = load_user_data()
    vip_dogs_owned = []
    if current_user in user_data and "game_data" in user_data[current_user]:
        vip_dogs_owned = user_data[current_user]["game_data"].get("vip_dogs_owned", [])
    
    vip_dogs = sorted(VIP_DOG_REQUIREMENTS.keys(), 
                     key=lambda x: VIP_DOG_REQUIREMENTS[x]["tickets"])
    
    num_dogs = len(vip_dogs)
    
    # 
    menu_width = min(800, SCREEN_WIDTH - 40)
    menu_height = min(600, SCREEN_HEIGHT - 40)
    menu_x = (SCREEN_WIDTH - menu_width) // 2
    menu_y = (SCREEN_HEIGHT - menu_height) // 2
    
    # 
    pygame.draw.rect(screen, (40, 40, 60), (menu_x, menu_y, menu_width, menu_height), border_radius=15)
    pygame.draw.rect(screen, (70, 70, 90), (menu_x+5, menu_y+5, menu_width-10, menu_height-10), border_radius=10)
    
    #
    title = font_main.render("VIP ELITE DOGS", True, (255, 215, 0))
    screen.blit(title, (menu_x + menu_width//2 - title.get_width()//2, menu_y + 20))
    
    # 
    screen.blit(icon_images["ticket"], (menu_x + 30, menu_y + 25))
    ticket_text = font_main.render(f"{ticket_count}", True, (255, 255, 255))
    screen.blit(ticket_text, (menu_x + 60, menu_y + 30))

    ticket_button = pygame.Rect(menu_x + menu_width - 150, menu_y + 25, 120, 30)
    pygame.draw.rect(screen, (255, 215, 0), ticket_button, border_radius=5)
    ticket_text = font_small.render("Buy Ticket", True, (40, 40, 40))
    screen.blit(ticket_text, (ticket_button.centerx - ticket_text.get_width()//2, 
                             ticket_button.centery - ticket_text.get_height()//2))

    # 
    current_dog = vip_dogs[vip_current_dog_index]
    requirements = VIP_DOG_REQUIREMENTS[current_dog]

    
    # 
    if current_dog in dog_images:
        dog_img = dog_images[current_dog]["idle"]
        img_width = min(300, dog_img.get_width())
        img_height = min(300, dog_img.get_height())
        dog_img = pygame.transform.scale(dog_img, (img_width, img_height))
        screen.blit(dog_img, (menu_x + menu_width//2 - img_width//2, menu_y + 100))
    else:
        print(f"Uyarı: {current_dog} görseli bulunamadı!")
    
    # 
    name_text = font_main.render(current_dog.upper(), True, (255, 215, 0))
    screen.blit(name_text, (menu_x + menu_width//2 - name_text.get_width()//2, menu_y + 80))
    
    #
    req_text = f"Requires: {requirements['tickets']} tickets"
    if not all(dog in [d.name for d in active_dogs] for dog in DOG_PRICES.keys()):
        req_text += " + ALL BASIC DOGS"
    
    req_surface = font_small.render(req_text, True, (200, 200, 200))
    screen.blit(req_surface, (menu_x + menu_width//2 - req_surface.get_width()//2, menu_y + 420))
    
    # Trade butonu
    button_width, button_height = 200, 50
    button_rect = pygame.Rect(menu_x + menu_width//2 - button_width//2, menu_y + 450, button_width, button_height)
    
    owned = current_dog in vip_dogs_owned  # Artık user_data'dan kontrol ediyoruz
    can_afford = ticket_count >= requirements["tickets"] and all(dog in [d.name for d in active_dogs] for dog in DOG_PRICES.keys())
    
    if owned:
        pygame.draw.rect(screen, (100, 100, 100), button_rect, border_radius=10)
        btn_text = font_main.render("OWNED", True, (200, 200, 200))
    elif can_afford:
        pygame.draw.rect(screen, (255, 215, 0), button_rect, border_radius=10)
        btn_text = font_main.render(f"BUY ({requirements['tickets']} tickets)", True, (40, 40, 40))
    else:
        pygame.draw.rect(screen, (BLUE_BUTTON), button_rect, border_radius=10)
        btn_text = font_main.render(f"NEED {requirements['tickets']} tickets", True, (150, 150, 150))
        
    screen.blit(btn_text, (button_rect.centerx - btn_text.get_width()//2, button_rect.centery - btn_text.get_height()//2))
    left_active = vip_current_dog_index > 0
    right_active = vip_current_dog_index < num_dogs - 1
    

    left_arrow = pygame.Rect(menu_x + 30, menu_y + menu_height//2 - 25, 50, 50)
    pygame.draw.polygon(screen, (255, 215, 0) if left_active else (100, 100, 100), 
                       [(left_arrow.x + 35, left_arrow.y + 10),
                        (left_arrow.x + 15, left_arrow.y + 25),
                        (left_arrow.x + 35, left_arrow.y + 40)])
    

    right_arrow = pygame.Rect(menu_x + menu_width - 80, menu_y + menu_height//2 - 25, 50, 50)
    pygame.draw.polygon(screen, (255, 215, 0) if right_active else (100, 100, 100), 
                       [(right_arrow.x + 15, right_arrow.y + 10),
                        (right_arrow.x + 35, right_arrow.y + 25),
                        (right_arrow.x + 15, right_arrow.y + 40)])
    

    close_rect = pygame.Rect(menu_x + menu_width//2 - 40, menu_y + menu_height - 60, 80, 30)
    pygame.draw.rect(screen, (180, 50, 50), close_rect, border_radius=5)
    close_text = font_main.render("Close", True, (255, 255, 255))
    screen.blit(close_text, (close_rect.centerx - close_text.get_width()//2, close_rect.centery - close_text.get_height()//2))
    

    current_buttons_in_jamal_shop = [
        {"rect": button_rect, "action": "trade_vip_dog", "dog_type": current_dog},
        {"rect": left_arrow, "action": "prev_vip_dog", "active": left_active},
        {"rect": right_arrow, "action": "next_vip_dog", "active": right_active},
        {"rect": close_rect, "action": "close_vip_shop"},
        {"rect": ticket_button, "action": "buy_ticket"}  # Add this line
    ]
# 
def buy_ticket():
    global gold_amount, ticket_count
    ticket_price = 200
    if gold_amount >= ticket_price:
        gold_amount -= ticket_price
        ticket_count += 1
        print(f"Bought 1 ticket for {ticket_price} gold. Total tickets: {ticket_count}")
    else:
        print(f"Not enough gold to buy ticket. Need {ticket_price} gold.")




def trade_for_vip_dog(dog_type):
    global ticket_count, active_dogs
    
    if dog_type not in VIP_DOG_REQUIREMENTS:
        return False
    
    # Load user data
    user_data = load_user_data()  # Add this line
    
    # Check if already owned - BASE isme göre kontrol et
    if is_dog_owned(dog_type):  # Değişiklik burada
        print(f"You already own a {dog_type.capitalize()}!")
        return False
    
    # Initialize game_data if it doesn't exist
    if current_user not in user_data or "game_data" not in user_data[current_user]:
        user_data[current_user] = {"game_data": {}}
    
    # Initialize vip_dogs_owned list if it doesn't exist
    if "vip_dogs_owned" not in user_data[current_user]["game_data"]:
        user_data[current_user]["game_data"]["vip_dogs_owned"] = []
    
    # Check if already owned
    if dog_type in user_data[current_user]["game_data"]["vip_dogs_owned"]:
        print(f"You already own a {dog_type.capitalize()}!")
        return False
    
    requirements = VIP_DOG_REQUIREMENTS[dog_type]
    
    if ticket_count >= requirements["tickets"]:
        ticket_count -= requirements["tickets"]
        
        # Add the dog
        spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - dog_images[dog_type]["idle"].get_width())
        spawn_y = random.uniform(0, SCREEN_HEIGHT - dog_images[dog_type]["idle"].get_height())
        new_dog = Dog(dog_type, spawn_x, spawn_y)
        active_dogs.append(new_dog)
        
        # Update VIP dogs list
        if dog_type not in user_data[current_user]["game_data"]["vip_dogs_owned"]:
            user_data[current_user]["game_data"]["vip_dogs_owned"].append(dog_type)
            save_user_data(user_data)
        
        return True
    
    return False

#  
skip_button_rect = pygame.Rect(10, SCREEN_HEIGHT - 50, 150, 40)
skip_button_text = "Skip Tutorial"

# Main game loop
running = True
clock = pygame.time.Clock()
current_task_tab = "tasks"

pending_reward_function = None
pending_save_function = None

# Initialize box animation system
initialize_box_animation()

while running:
    dt = clock.tick(60) / 1000.0

    draw_dog_animation(screen) 
    update_dog_animation(dt)

    
    now = datetime.now()
    if halloween_event_active and now > halloween_event_end_date:
        halloween_event_active = False

    if halloween_box_animation_active:
       update_halloween_box_animation(dt)
    
    if box_animation_active:
     if update_box_animation(dt):  # Animasyon bitti
        if pending_reward_function:
            pending_reward_function()
            pending_reward_function = None
        if pending_save_function:
            pending_save_function()
            pending_save_function = None
            
    mouse_clicked_this_frame = False
    keys = pygame.key.get_pressed()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            if current_user:
                save_game_data(current_user)
            running = False

        if box_animation_active or halloween_box_animation_active:
             continue 
            
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F11:
                FULLSCREEN = not FULLSCREEN
                if FULLSCREEN:
                    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                    current_screen_width, current_screen_height = screen.get_size()
                else:
                    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
                    current_screen_width, current_screen_height = SCREEN_WIDTH, SCREEN_HEIGHT
                    character_x = SCREEN_WIDTH // 2 - character_images[current_character_style]["idle"].get_width() // 2
                    character_y = SCREEN_HEIGHT // 2 - character_images[current_character_style]["idle"].get_height() // 2
            
            if login_screen_active or register_screen_active:
                if event.key == pygame.K_BACKSPACE:
                    if event.mod & pygame.KMOD_CTRL:
                        if username_input and pygame.Rect(SCREEN_WIDTH//2 - 150, 200, 300, 40).collidepoint(pygame.mouse.get_pos()):
                            username_input = ""
                        elif password_input and pygame.Rect(SCREEN_WIDTH//2 - 150, 260, 300, 40).collidepoint(pygame.mouse.get_pos()):
                            password_input = ""
                    else:
                        if username_input and pygame.Rect(SCREEN_WIDTH//2 - 150, 200, 300, 40).collidepoint(pygame.mouse.get_pos()):
                            username_input = username_input[:-1]
                        elif password_input and pygame.Rect(SCREEN_WIDTH//2 - 150, 260, 300, 40).collidepoint(pygame.mouse.get_pos()):
                            password_input = password_input[:-1]
                elif event.key == pygame.K_RETURN:
                    if login_screen_active:
                        success, message = login_user(username_input, password_input)
                        if success:
                            current_user = username_input
                            load_game_data(current_user)
                            login_screen_active = False
                            current_game_state = GAME_STATE_TUTORIAL
                        else:
                            login_error = message
                    elif register_screen_active:
                        success, message = register_user(username_input, password_input)
                        if success:
                            current_user = username_input
                            load_game_data(current_user)
                            register_screen_active = False
                            login_screen_active = False
                            current_game_state = GAME_STATE_TUTORIAL
                        else:
                            register_error = message
                elif event.key == pygame.K_TAB:
                    if username_input and pygame.Rect(SCREEN_WIDTH//2 - 150, 200, 300, 40).collidepoint(pygame.mouse.get_pos()):
                        pygame.mouse.set_pos((SCREEN_WIDTH//2, 260))
                    elif password_input and pygame.Rect(SCREEN_WIDTH//2 - 150, 260, 300, 40).collidepoint(pygame.mouse.get_pos()):
                        pygame.mouse.set_pos((SCREEN_WIDTH//2, 200))
                else:
                    if pygame.Rect(SCREEN_WIDTH//2 - 150, 200, 300, 40).collidepoint(pygame.mouse.get_pos()):
                        username_input += event.unicode
                    elif pygame.Rect(SCREEN_WIDTH//2 - 150, 260, 300, 40).collidepoint(pygame.mouse.get_pos()):
                        password_input += event.unicode
            elif not shop_open and not vip_shop_open and current_game_state == GAME_STATE_PLAYING:
                if event.key == pygame.K_1:
                    selected_seed_type = "carrot"
                elif event.key == pygame.K_2:
                    selected_seed_type = "wheat"
                elif event.key == pygame.K_3:
                    selected_seed_type = "corn"
                elif event.key == pygame.K_4:
                    selected_seed_type = "cotton"
                elif event.key == pygame.K_SPACE and not hoe_animation_playing:
                    character_tile_x = (character_x + character_images[current_character_style]["idle"].get_width() // 2) // TILE_SIZE
                    character_tile_y = (character_y + character_images[current_character_style]["idle"].get_height() // 2) // TILE_SIZE

                    # Check if near shop
                    is_near_shop = False
                    if abs(character_tile_x - shop_karo_x) <= 2 and abs(character_tile_y - shop_karo_y) <= 2:
                        if 0 <= shop_karo_y < MAP_HEIGHT_TILES and 0 <= shop_karo_x < MAP_WIDTH_TILES:
                            if game_map[shop_karo_y][shop_karo_x]["type"] == "shop_stand":
                                is_near_shop = True


                    
                    # Check if near agent
                    is_near_agent = False
                    if abs(character_tile_x - agent_tile_x) <= 2 and abs(character_tile_y - agent_tile_y) <= 2:
                        if 0 <= agent_tile_y < MAP_HEIGHT_TILES and 0 <= agent_tile_x < MAP_WIDTH_TILES:
                            if game_map[agent_tile_y][agent_tile_x]["type"] == "agent":
                                is_near_agent = True

                    if is_near_shop:
                        shop_open = True
                        shop_current_tab = "crops_seeds"
                    elif is_near_agent:
                        vip_shop_open = True
                    elif 0 <= character_tile_x < MAP_WIDTH_TILES and 0 <= character_tile_y < MAP_HEIGHT_TILES:
                        if character_tile_x >= half_width_tiles:
                            target_tile_coords = (character_tile_x, character_tile_y)
                            hoe_animation_playing = True
                            hoe_current_frame = 0
                            hoe_animation_timer = 0.0
            elif current_game_state == GAME_STATE_TUTORIAL:
                if event.key == pygame.K_SPACE and not hoe_animation_playing:
                    if tutorial_manager.active and tutorial_manager.current_action_index < len(tutorial_manager.tutorial_actions):
                        current_tut_action = tutorial_manager.tutorial_actions[tutorial_manager.current_action_index]
                        if current_tut_action["type"] == "action" and current_tut_action["action_type"] == "open_shop":
                            character_tile_x = (character_x + character_images[current_character_style]["idle"].get_width() // 2) // TILE_SIZE
                            character_tile_y = (character_y + character_images[current_character_style]["idle"].get_height() // 2) // TILE_SIZE
                            if abs(character_tile_x - shop_karo_x) <= 2 and abs(character_tile_y - shop_karo_y) <= 2:
                                shop_open = True
                                shop_current_tab = "crops_seeds"
                                tutorial_manager.current_action_index += 1
                                tutorial_manager.is_performing_action = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                mouse_x, mouse_y = event.pos
                
                if login_screen_active:
                    login_button = pygame.Rect(SCREEN_WIDTH//2 - 150, 320, 140, 40)
                    register_button = pygame.Rect(SCREEN_WIDTH//2 + 10, 320, 140, 40)
                    
                    if login_button.collidepoint(mouse_x, mouse_y):
                        success, message = login_user(username_input, password_input)
                        if success:
                            current_user = username_input
                            load_game_data(current_user)
                            login_screen_active = False
                            current_game_state = GAME_STATE_TUTORIAL
                        else:
                            login_error = message
                    elif register_button.collidepoint(mouse_x, mouse_y):
                        login_screen_active = False
                        register_screen_active = True
                        register_error = ""
                        
                elif xp_button_rect.collidepoint(mouse_x, mouse_y):
                     xp_open = not xp_open
    
                elif finance_button_rect.collidepoint(mouse_x, mouse_y):
                         finance_open = not finance_open

                elif register_screen_active:
                    register_button = pygame.Rect(SCREEN_WIDTH//2 - 150, 320, 300, 40)
                    back_button = pygame.Rect(SCREEN_WIDTH//2 - 150, 370, 300, 40)
                    
                    if register_button.collidepoint(mouse_x, mouse_y):
                        success, message = register_user(username_input, password_input)
                        if success:
                            current_user = username_input
                            load_game_data(current_user)
                            register_screen_active = False
                            login_screen_active = False
                            current_game_state = GAME_STATE_TUTORIAL
                        else:
                            register_error = message
                    elif back_button.collidepoint(mouse_x, mouse_y):
                        register_screen_active = False
                        login_screen_active = True
                        login_error = ""


                elif wardrobe_button_rect.collidepoint(mouse_x, mouse_y):
                        wardrobe_open = not wardrobe_open

                elif phone_button_rect.collidepoint(mouse_x, mouse_y):
                        phone_open = not phone_open
                        
                elif phone_open:
                        for button in current_buttons_in_phone:
                            if button["rect"].collidepoint(mouse_x, mouse_y):
                                if button["action"] == "switch_phone_tab":
                                   phone_current_tab = button["tab"]
                                elif button["action"] == "change_tab":
                                    phone_current_tab = button["tab"]
                                elif button["action"] == "close_phone":
                                    phone_open = False
                                elif button["action"] == "switch_to_adopter":
                                    phone_current_tab = "adopter"
                                elif button["action"] == "prev_jamal_dog":
                                    jamal_current_dog_index = max(0, jamal_current_dog_index - 1)
                                elif button["action"] == "next_jamal_dog":
                                    jamal_current_dog_index = min(len([d for d in SPECIAL_DOG_REQUIREMENTS.keys() if d not in ["sultan", "akbash", "kangal"]]) - 1, jamal_current_dog_index + 1)
                                elif button["action"] == "craft_carrotcake" and button.get("enabled", False):
                                    if craft_carrotcake():
                                       show_message("Carrot Cake crafted! +1 Treatcoin")
                                elif button["action"] == "craft_vodoo" and button.get("enabled", False):
                                    if craft_vodoo():
                                       show_message("Vodoo Doll crafted! +1 Treatcoin")
                                elif button["action"] == "open_halloween_box" and button.get("enabled", False):
                                    if open_halloween_box():
                                       show_message("Opening Halloween Box...")
                                elif button["action"] == "trade_dog":
                                    if trade_for_dog(button["dog_type"]):
                                        print(f"Adopted {button['dog_type']}!")
                                elif button["action"] == "outfit":
                                     if button["type"] == "buy" and gold_amount >= button["price"]:
                                        # Outfit satın al
                                        gold_amount -= button["price"]
                                        dog = next((d for d in active_dogs if d.base_name == button["dog"]), None)
                                        if dog:
                                           dog.add_outfit(button["outfit"])
                                     elif button["type"] == "equip":
                                         # Outfit giydir
                                         dog = next((d for d in active_dogs if d.base_name == button["dog"]), None)
                                         if dog:
                                            if dog.current_outfit == button["outfit"]:
                                              # Aynı outfit tekrar tıklandı, outfit çıkar
                                              dog.change_outfit("base")
                                            else:
                                               # Yeni outfit giydir
                                               dog.change_outfit(button["outfit"])


                
                elif xp_open:
                     buttons = draw_xp_path_menu(screen)
                     for button in buttons:
                        if button["rect"].collidepoint(mouse_x, mouse_y):
                            if button["action"] == "claim_reward":
                              claim_xp_reward(button["level"])
                            elif button["action"] == "close_xp_path":
                              xp_open = False
                            elif button["action"] == "prev_xp_page" and button.get("active", True):
                              xp_current_page = max(0, xp_current_page - 1)
                            elif button["action"] == "next_xp_page" and button.get("active", True):
                              xp_current_page = min((len(XP_REWARDS) + xp_rewards_per_page - 1) // xp_rewards_per_page - 1, xp_current_page + 1)


                elif shop_open:
                    for button in current_buttons_in_shop:
                        if button["rect"].collidepoint(mouse_x, mouse_y):
                            if button["action"] == "sell":
                                sell_item(button["item_type"])
                            elif button["action"] == "buy":
                                buy_seed(button["item_type"])
                            elif button["action"] == "prev_dog" and button.get("active", True):
                                shop_current_dog_index = max(0, shop_current_dog_index - 1)
                            elif button["action"] == "next_dog" and button.get("active", True):
                                shop_current_dog_index = min(len(DOG_PRICES) - 1, shop_current_dog_index + 1)
                            elif button["action"] == "buy_dog":
                                buy_dog(button["dog_type"])
                            elif button["action"] == "close_shop":
                                shop_open = False
                                if current_game_state == GAME_STATE_TUTORIAL and tutorial_manager.active and \
                                   tutorial_manager.current_action_index < len(tutorial_manager.tutorial_actions) and \
                                   tutorial_manager.tutorial_actions[tutorial_manager.current_action_index]["type"] == "action" and \
                                   tutorial_manager.tutorial_actions[tutorial_manager.current_action_index]["action_type"] == "close_shop":
                                    tutorial_manager.current_action_index += 1
                            elif button["action"] == "change_tab":
                                shop_current_tab = button["tab_name"]
                                current_buttons_in_shop = []

 
                elif finance_open:
                     buttons = draw_finance_menu(screen)
                     for button in buttons:
                         if button["rect"].collidepoint(mouse_x, mouse_y):
                             if button["action"] == "upgrade_finance":
                                if upgrade_finance(button["finance"]):
                                   show_message(f"Upgraded {button['finance']}!")
                             elif button["action"] == "toggle_finance":
                                if toggle_finance(button["finance"]):
                                   show_message(f"Toggled {button['finance']}!")
                                else:
                                   show_message("Cannot activate - max 2 finances active")
                             elif button["action"] == "close_finance":
                                  finance_open = False
                             elif button["action"] == "prev_finance" and button.get("active", True):
                                  finance_current_index = max(0, finance_current_index - 1)
                             elif button["action"] == "next_finance" and button.get("active", True):
                                  finance_current_index = min(len(FINANCES) - 1, finance_current_index + 1)

                                
                elif wardrobe_open:
                     buttons = draw_wardrobe_menu(screen)
                     for button in buttons:
                         if button["rect"].collidepoint(mouse_x, mouse_y):
                            if button["action"] == "prev_dog" and button.get("active", True):
                               wardrobe_current_dog_index = max(0, wardrobe_current_dog_index - 1)
                            elif button["action"] == "next_dog" and button.get("active", True):
                                 wardrobe_current_dog_index = min(len([d for d in active_dogs if d.base_name in ["banana", "dolly", "rex", "master", "choco", "momo", "bobbo", "skele-dog", "akbash", "sultan"]]) - 1, wardrobe_current_dog_index + 1)
                            elif button["action"] == "classic":  # Bob outfit değiştirme
                                 current_character_style = "classic"
                                 show_message("Classic Bob outfit equipped")
                            elif button["action"] == "odin":  # Bob outfit değiştirme
                                 current_character_style = "odin"
                                 show_message("Dragon Bob outfit equipped")
                            elif button["action"] == "equip_outfit":
                                 dog = button["dog"]
                                 outfit_name = button["outfit"]
                                 if dog.change_outfit(outfit_name):
                                    show_message(f"Equipped {outfit_name} outfit")
                            elif button["action"] == "outfit_action":
                                    dog = button["dog"]
                                    outfit_name = button["outfit"]
                
                                    if button["owned"]:
                                       # Outfit zaten sahip olunan, equip yap
                                       if dog.change_outfit(outfit_name):
                                          show_message(f"Equipped {outfit_name} outfit")
                                    else:
                                           # Outfit satın alma
                                           price = button["price"]
                                           if gold_amount >= price:
                                              gold_amount -= price
                                              dog.outfits.append(outfit_name)  # Outfit'i ekle
                                              if dog.change_outfit(outfit_name):  # Ve giydir
                                                 show_message(f"Purchased and equipped {outfit_name}!")
                                                 if current_user:
                                                    save_game_data(current_user)
                                           else:
                                               show_message(f"Not enough gold! Need {price} gold.")
                            elif button["action"] == "close_wardrobe":
                                 wardrobe_open = False


                
                elif vip_shop_open:
                    for button in current_buttons_in_jamal_shop:
                        if button["rect"].collidepoint(mouse_x, mouse_y):
                            if button["action"] == "buy_ticket":
                                buy_ticket()
                            elif button["action"] == "prev_vip_dog" and button.get("active", True):
                                vip_current_dog_index = max(0, vip_current_dog_index - 1)
                            elif button["action"] == "next_vip_dog" and button.get("active", True):
                                vip_current_dog_index = min(len(VIP_DOG_REQUIREMENTS) - 1, vip_current_dog_index + 1)
                            elif button["action"] == "trade_vip_dog":
                                if trade_for_vip_dog(button["dog_type"]):
                                    print(f"Traded for VIP dog {button['dog_type']}!")
                            elif button["action"] == "close_vip_shop":
                                vip_shop_open = False
                
                elif current_game_state == GAME_STATE_PLAYING:
                    # NPC spawning and updating logic
                    if current_game_state == GAME_STATE_PLAYING:
                       if active_npc is None:
                          npc_spawn_timer += dt
                          if npc_spawn_timer >= npc_spawn_interval:
                            # Spawn new NPC
                            npc_type = random.choice(["rat", "turtle"])
                            spawn_x = random.uniform(0, (half_width_tiles * TILE_SIZE) - npc_images[npc_type]["idle"].get_width())
                            spawn_y = random.uniform(0, SCREEN_HEIGHT - npc_images[npc_type]["idle"].get_height())
                            active_npc = NPC(npc_type, spawn_x, spawn_y)
                            npc_spawn_timer = 0
                            npc_spawn_interval = random.uniform(30, 60)
                       else:
                            # Update existing NPC
                            active_npc.update(dt)
        
                            # Remove NPC if it goes off-screen
                            if (active_npc.x < -active_npc.width or active_npc.x > SCREEN_WIDTH or
                               active_npc.y < -active_npc.height or active_npc.y > SCREEN_HEIGHT):
                               active_npc = None

                 
                    # Visit friends button
                    elif visit_button_rect.collidepoint(mouse_x, mouse_y):
                        current_game_state = FARM_VISIT_MENU
                    # Task menu button
                    elif task_button_rect.collidepoint(mouse_x, mouse_y):
                        current_game_state = TASK_MENU_OPEN
                    else:
                        character_tile_x = (character_x + character_images[current_character_style]["idle"].get_width() // 2) // TILE_SIZE
                        character_tile_y = (character_y + character_images[current_character_style]["idle"].get_height() // 2) // TILE_SIZE
                        tile_x = mouse_x // TILE_SIZE
                        tile_y = mouse_y // TILE_SIZE

                        # Check if clicked on shop
                        is_near_shop_click = False
                        if 0 <= tile_y < MAP_HEIGHT_TILES and 0 <= tile_x < MAP_WIDTH_TILES:
                            if game_map[tile_y][tile_x]["type"] == "shop_stand" and \
                            abs(character_tile_x - tile_x) <= 2 and abs(character_tile_y - tile_y) <= 2:
                                is_near_shop_click = True

                        # Check if clicked on agent
                        is_near_agent_click = False
                        if 0 <= tile_y < MAP_HEIGHT_TILES and 0 <= tile_x < MAP_WIDTH_TILES:
                            if game_map[tile_y][tile_x]["type"] == "agent" and \
                            abs(character_tile_x - tile_x) <= 2 and abs(character_tile_y - tile_y) <= 2:
                                is_near_agent_click = True

                        if is_near_shop_click:
                            shop_open = True
                            shop_current_tab = "crops_seeds"
                        elif is_near_agent_click:
                            vip_shop_open = True
                        elif abs(character_tile_x - tile_x) <= 1 and abs(character_tile_y - tile_y) <= 1:
                            if tile_x >= half_width_tiles:
                                target_tile_coords = (tile_x, tile_y)
                                hoe_animation_playing = True
                                hoe_current_frame = 0
                                hoe_animation_timer = 0.0
                
                elif current_game_state == TASK_MENU_OPEN:
                     close_button, tasks_tab, achievements_tab = draw_task_menu(screen)
                     if close_button.collidepoint(mouse_x, mouse_y):
                        current_game_state = GAME_STATE_PLAYING
                     elif tasks_tab.collidepoint(mouse_x, mouse_y):
                        current_task_tab = "tasks"
                     elif achievements_tab.collidepoint(mouse_x, mouse_y):
                        current_task_tab = "achievements"
                
                elif current_game_state == FARM_VISIT_MENU:
                    farm_buttons, close_button = draw_visit_farm_menu(screen)
                    
                    if close_button.collidepoint(mouse_x, mouse_y):
                        current_game_state = GAME_STATE_PLAYING
                    else:
                        for button in farm_buttons:
                            if button["rect"].collidepoint(mouse_x, mouse_y):
                                visited_farm_owner = button["owner"]
                                visited_farm_data = load_farm_data(visited_farm_owner)
                                current_game_state = VISITING_FARM
                
                elif current_game_state == VISITING_FARM:
                    exit_button = draw_visited_farm(screen, visited_farm_data)
                    if exit_button.collidepoint(mouse_x, mouse_y):
                        current_game_state = GAME_STATE_PLAYING
                        visited_farm_owner = None
                        visited_farm_data = None
                
                if current_game_state == GAME_STATE_TUTORIAL and skip_button_rect.collidepoint(mouse_x, mouse_y):
                    current_game_state = GAME_STATE_PLAYING
                    tutorial_manager.active = False
                    character_x = SCREEN_WIDTH // 2 - character_images[current_character_style]["idle"].get_width() // 2
                    character_y = SCREEN_HEIGHT // 2 - character_images[current_character_style]["idle"].get_height() // 2
                    current_state = "idle"

    # Get current screen dimensions
    current_screen_width, current_screen_height = screen.get_size()

    if login_screen_active or register_screen_active:
        pass
    else:
        if current_game_state == GAME_STATE_TUTORIAL:
            tutorial_manager.update(dt)
            if not tutorial_manager.active:
                current_game_state = GAME_STATE_PLAYING
                character_x = SCREEN_WIDTH // 2 - character_images[current_character_style]["idle"].get_width() // 2
                character_y = SCREEN_HEIGHT // 2 - character_images[current_character_style]["idle"].get_height() // 2
                current_state = "idle"
        elif current_game_state == GAME_STATE_PLAYING and not hoe_animation_playing and not shop_open and not vip_shop_open and not phone_open:
            fire_dog_present = any(dog.name == "fire" for dog in active_dogs)
            character_speed = base_character_speed * (1.15 if fire_dog_present else 1.0)
            is_moving = False

            if keys[pygame.K_a]:
                character_x -= character_speed * dt
                current_state = "walk_left"
                is_moving = True
            elif keys[pygame.K_d]:
                character_x += character_speed * dt
                current_state = "walk_right"
                is_moving = True
            elif keys[pygame.K_w]:
                character_y -= character_speed * dt
                current_state = "walk_up"
                is_moving = True
            elif keys[pygame.K_s]:
                character_y += character_speed * dt
                current_state = "walk_down"
                is_moving = True

            if not is_moving:
                current_state = "idle"

            character_x = max(0, min(character_x, current_screen_width - character_images[current_character_style]["idle"].get_width()))
            character_y = max(0, min(character_y, current_screen_height - character_images[current_character_style]["idle"].get_height()))

            animation_timer += dt
            if animation_timer >= animation_speed:
                animation_timer = 0.0
                if current_state != "idle":
                    if isinstance(character_images[current_character_style][current_state], list):
                        current_animation_frame = (current_animation_frame + 1) % len(character_images[current_character_style][current_state])
                    else:
                        current_animation_frame = 0
                else:
                    current_animation_frame = 0

        # Update dogs
        if current_game_state == GAME_STATE_PLAYING and not visiting_farm:
            for dog in active_dogs:
                dog.update(dt)
                
            if task_button_rect.collidepoint(mouse_x, mouse_y):
                current_game_state = TASK_MENU_OPEN
        
            if active_npc is None:
               npc_spawn_timer += dt
               if npc_spawn_timer >= npc_spawn_interval:
                    npc_type = random.choice(["rat", "turtle"])
                    spawn_x = random.uniform(50, (half_width_tiles * TILE_SIZE) - 50)  # Kenarlardan 50 piksel içerde
                    spawn_y = random.uniform(50, SCREEN_HEIGHT - 50)
                    active_npc = NPC(npc_type, spawn_x, spawn_y)
                    print(f"SPAWNED: {npc_type} at ({spawn_x:.0f}, {spawn_y:.0f})")
                    npc_spawn_timer = 0
                    npc_spawn_interval = random.uniform(20, 40)
            else:
                    active_npc.update(dt)
                    # Ekran dışı kontrolü
                    if (active_npc.x < -100 or active_npc.x > SCREEN_WIDTH + 100 or
                      active_npc.y < -100 or active_npc.y > SCREEN_HEIGHT + 100):
                      active_npc = None

            

        if hoe_animation_playing:
            hoe_animation_timer += dt
            if hoe_animation_timer >= hoe_animation_speed:
                hoe_animation_timer = 0.0
                hoe_current_frame = (hoe_current_frame + 1) % len(scaled_hoe_animation_images if current_character_style == "classic" else scaled_odin_hoe_animation_images)
                if hoe_current_frame == 0:
                    hoe_animation_playing = False
                    if target_tile_coords:
                        process_tile(int(target_tile_coords[0]), int(target_tile_coords[1]), selected_seed_type)
                        target_tile_coords = None

                    if current_game_state == GAME_STATE_TUTORIAL:
                        tutorial_manager.current_action_index += 1
                        tutorial_manager.is_performing_action = False

        # Update plant growth
        if current_game_state != VISITING_FARM:  # Don't update plants when visiting other farms
            for y in range(MAP_HEIGHT_TILES):
                for x in range(MAP_WIDTH_TILES):
                    tile = game_map[y][x]
                    if tile["plant_stage"] > 0 and tile["plant_type"] is not None:
                        plant_growth_stages = PLANT_GROWTH_DURATIONS.get(tile["plant_type"])

                        if plant_growth_stages:
                            last_stage_index = len(plant_growth_stages) - 1
                            last_stage_image = plant_growth_stages.get(last_stage_index, {}).get("image")

                            if tile["type"] != last_stage_image:
                                tile["growth_time"] += dt
                                current_stage_info = plant_growth_stages.get(tile["plant_stage"])

                                if current_stage_info:
                                    next_stage_index = tile["plant_stage"] + 1
                                    next_stage_info = plant_growth_stages.get(next_stage_index)

                                    if next_stage_info and tile["growth_time"] >= current_stage_info["duration"]:
                                        tile["plant_stage"] = next_stage_index
                                        tile["growth_time"] = 0
                                        tile["type"] = next_stage_info["image"]


            growth_multiplier = get_growth_multiplier()
            for y in range(MAP_HEIGHT_TILES):
                   for x in range(MAP_WIDTH_TILES):
                       tile = game_map[y][x]
                       if tile["plant_stage"] > 0 and tile["plant_type"] is not None:
                          plant_growth_stages = PLANT_GROWTH_DURATIONS.get(tile["plant_type"])
                          if plant_growth_stages:
                             last_stage_index = len(plant_growth_stages) - 1
                             last_stage_image = plant_growth_stages.get(last_stage_index, {}).get("image")
                             if tile["type"] != last_stage_image:
                                 tile["growth_time"] += dt * growth_multiplier  # Finance multiplier applied here
                                 current_stage_info = plant_growth_stages.get(tile["plant_stage"])
                                 if current_stage_info:
                                    next_stage_index = tile["plant_stage"] + 1
                                    next_stage_info = plant_growth_stages.get(next_stage_index)
                                    if next_stage_info and tile["growth_time"] >= current_stage_info["duration"]:
                                       tile["plant_stage"] = next_stage_index
                                       tile["growth_time"] = 0
                                       tile["type"] = next_stage_info["image"]


        
        if message_timer > 0:
           message_timer -= dt
           if message_timer <= 0:
              message_text = ""
    
    # Drawing
    if login_screen_active:
        draw_login_screen(screen)
    elif register_screen_active:
        draw_register_screen(screen)
    else:
        if current_game_state == VISITING_FARM:
            exit_button = draw_visited_farm(screen, visited_farm_data)
        else:
            screen.fill(LIGHT_GREEN)

            for y in range(MAP_HEIGHT_TILES):
                for x in range(half_width_tiles, MAP_WIDTH_TILES):
                    screen.blit(tile_images["empty_soil"], (x * TILE_SIZE, y * TILE_SIZE))

            for y in range(MAP_HEIGHT_TILES):
                for x in range(MAP_WIDTH_TILES):
                    tile = game_map[y][x]
                    if tile["type"] == "shop_stand":
                        shop_display_x = x * TILE_SIZE - (tile_images["shop_stand"].get_width() - TILE_SIZE) // 2
                        shop_display_y = y * TILE_SIZE - (tile_images["shop_stand"].get_height() - TILE_SIZE) // 2
                        screen.blit(tile_images["shop_stand"], (shop_display_x, shop_display_y))
                    elif tile["type"] == "agent":
                        agent_display_x = x * TILE_SIZE - (tile_images["agent"].get_width() - TILE_SIZE) // 2
                        agent_display_y = y * TILE_SIZE - (tile_images["agent"].get_height() - TILE_SIZE) // 2
                        screen.blit(tile_images["agent"], (agent_display_x, agent_display_y))
                    elif tile["type"] != "empty_soil" and tile["type"] in tile_images:
                        screen.blit(tile_images[tile["type"]], (x * TILE_SIZE, y * TILE_SIZE))


            if active_npc is not None and current_game_state == GAME_STATE_PLAYING and not visiting_farm:
               active_npc.draw(screen)

            if active_npc:
               active_npc.draw(screen)

            if current_game_state == GAME_STATE_PLAYING:
                for dog in active_dogs:
                    dog.draw(screen)

            character_to_draw = None
            if hoe_animation_playing:
                if current_character_style == "classic":
                    character_to_draw = scaled_hoe_animation_images[hoe_current_frame]
                else:
                    character_to_draw = scaled_odin_hoe_animation_images[hoe_current_frame]
            else:
                if current_state == "idle":
                    character_to_draw = character_images[current_character_style]["idle"]
                else:
                    if isinstance(character_images[current_character_style][current_state], list):
                        character_to_draw = character_images[current_character_style][current_state][current_animation_frame]
                    else:
                        character_to_draw = character_images[current_character_style][current_state]

            screen.blit(character_to_draw, (int(character_x), int(character_y)))

            # XP butonlarını çiz
            screen.blit(icon_images["xp_icon"], xp_button_rect.topleft)
            if xp_button_rect.collidepoint(pygame.mouse.get_pos()):
               pygame.draw.rect(screen, (255, 255, 255, 100), xp_button_rect, 2, border_radius=5)

            # XP animasyonlarını güncelle ve çiz
            xp_collection_animations = [anim for anim in xp_collection_animations if anim.update(dt)]
            for anim in xp_collection_animations:
                anim.draw(screen)

            draw_box_animation(screen)
            draw_dog_animation(screen)
            draw_halloween_box_animation(screen)
            
            # Draw inventory and UI
            if current_game_state != VISITING_FARM:

                draw_dog_animation(screen)
                
                inventory_x_offset = 10
                current_y_pos_items = current_screen_height - 30 - (len(seed_types) * 35)


                if message_text and message_timer > 0:
                   message_surface = font_main.render(message_text, True, (255, 255, 255))
                   message_bg = pygame.Rect(SCREEN_WIDTH//2 - message_surface.get_width()//2 - 10, 
                          50, 
                          message_surface.get_width() + 20, 
                          message_surface.get_height() + 10)
                   pygame.draw.rect(screen, (0, 100, 0), message_bg, border_radius=5)
                   screen.blit(message_surface, (SCREEN_WIDTH//2 - message_surface.get_width()//2, 55))


                
                for i, item_type in enumerate(seed_types):
                    count = get_item_count(item_type)

                    if item_type in icon_images:
                        icon_rect = icon_images[item_type].get_rect(topleft=(inventory_x_offset, current_y_pos_items + i * 35))
                        screen.blit(icon_images[item_type], icon_rect.topleft)

                        amount_text_surface = font_small.render(f"x{count}", True, BLACK)
                        screen.blit(amount_text_surface, (icon_rect.right + 5, icon_rect.centery - amount_text_surface.get_height() // 2))

                current_y_pos_seeds = current_screen_height - 30 - (len(seed_types) * 35 * 2)

                for i, seed_type in enumerate(seed_types):
                    count = get_seed_count(seed_type)

                    seed_icon_name = f"seed_{seed_type}"
                    if seed_icon_name in icon_images:
                        icon_rect = icon_images[seed_icon_name].get_rect(topleft=(inventory_x_offset, current_y_pos_seeds + i * 35))
                        screen.blit(icon_images[seed_icon_name], icon_rect.topleft)

                        amount_text_surface = font_small.render(f"x{count}", True, BLACK)
                        screen.blit(amount_text_surface, (icon_rect.right + 5, icon_rect.centery - amount_text_surface.get_height() // 2))

                gold_icon_rect = icon_images["gold"].get_rect(topleft=(10, 10))
                screen.blit(icon_images["gold"], gold_icon_rect)
                gold_text_surface = font_gold.render(f"{gold_amount}", True, BLACK)
                screen.blit(gold_text_surface, (gold_icon_rect.right + 5, gold_icon_rect.centery - gold_text_surface.get_height() // 2))

                # Finance button
                screen.blit(icon_images["finance"], finance_button_rect.topleft)
                if finance_button_rect.collidepoint(pygame.mouse.get_pos()):
                   pygame.draw.rect(screen, (255, 255, 255, 100), finance_button_rect, 2, border_radius=5)

                # Draw kebab count if we have any
                if kebab_count > 0:
                    kebab_icon_rect = icon_images["kebab"].get_rect(topleft=(10, 50))
                    screen.blit(icon_images["kebab"], kebab_icon_rect)
                    kebab_text = font_small.render(f"x{kebab_count}", True, BLACK)
                    screen.blit(kebab_text, (kebab_icon_rect.right + 5, kebab_icon_rect.centery - kebab_text.get_height() // 2))


                if xp_amount > 0:
                   screen.blit(icon_images["xp"], (10, 170))
                   xp_ui_text = font_small.render(f"Lv.{player_level} ({xp_amount}/{xp_to_next_level})", True, BLACK)
                   screen.blit(xp_ui_text, (40, 170))

                # Draw tickets if we have any VIP dogs
                if any(dog.name in ["paraoh", "charlie", "master", "sam", "akita"] for dog in active_dogs):
                    screen.blit(icon_images["ticket"], (10, 90))
                    ticket_text = font_small.render(f"Tickets: {ticket_count}", True, BLACK)
                    screen.blit(ticket_text, (40, 90))

                # Draw treatcoin count if we have any
                if treatcoin_count > 0:
                   treatcoin_icon_rect = icon_images["treatcoin"].get_rect(topleft=(10, 210))
                   screen.blit(icon_images["treatcoin"], treatcoin_icon_rect)
                   treatcoin_text = font_small.render(f"x{treatcoin_count}", True, BLACK)
                   screen.blit(treatcoin_text, (treatcoin_icon_rect.right + 5, treatcoin_icon_rect.centery - treatcoin_text.get_height() // 2))
    
                # Cookie count display
                if finance_cookie_count > 0:
                   cookie_icon_rect = icon_images["cookie"].get_rect(topleft=(10, 130))
                   screen.blit(icon_images["cookie"], cookie_icon_rect)
                   cookie_text = font_small.render(f"x{finance_cookie_count}", True, BLACK)
                   screen.blit(cookie_text, (cookie_icon_rect.right + 5, cookie_icon_rect.centery - cookie_text.get_height() // 2))
                 
                if current_game_state == GAME_STATE_PLAYING:
                    # Visit friends button
                    pygame.draw.rect(screen, BLUE_BUTTON, visit_button_rect, border_radius=5)
                    visit_text = font_small.render("Visit Friends", True, WHITE)
                    screen.blit(visit_text, (visit_button_rect.centerx - visit_text.get_width() // 2, 
                                            visit_button_rect.centery - visit_text.get_height() // 2))

                    # Task button
                    screen.blit(icon_images["tasks"], task_button_rect.topleft)
                    if task_button_rect.collidepoint(pygame.mouse.get_pos()):
                        pygame.draw.rect(screen, (255, 255, 255, 100), task_button_rect, 2, border_radius=5)

                    # Phone button
                    screen.blit(icon_images["phone"], phone_button_rect.topleft)
                    if phone_button_rect.collidepoint(pygame.mouse.get_pos()):
                        pygame.draw.rect(screen, (255, 255, 255, 100), phone_button_rect, 2, border_radius=5)

                    # Wardrobe button
                    screen.blit(icon_images["wardrobe"], wardrobe_button_rect.topleft)
                    if wardrobe_button_rect.collidepoint(pygame.mouse.get_pos()):
                        pygame.draw.rect(screen, (255, 255, 255, 100), wardrobe_button_rect, 2, border_radius=5)
                    
                    if wardrobe_open:
                        draw_wardrobe_menu(screen)
                        
        if current_game_state == GAME_STATE_PLAYING:
           check_achievements()

        # Finansman efektlerini uygula
        if current_game_state == GAME_STATE_PLAYING:
           apply_finance_effects()
        
        if current_game_state == GAME_STATE_TUTORIAL:
            tutorial_manager.draw(screen)

            pygame.draw.rect(screen, RED_BUTTON, skip_button_rect, border_radius=5)
            skip_text_surface = font_main.render(skip_button_text, True, WHITE)
            screen.blit(skip_text_surface, (skip_button_rect.centerx - skip_text_surface.get_width()//2,
                                            skip_button_rect.centery - skip_text_surface.get_height()//2))
        if not login_screen_active and not register_screen_active:
             apply_finance_effects()
    
        if shop_open:
            draw_shop_menu(screen)

        if finance_open:
            draw_finance_menu(screen)
    
        if vip_shop_open:
            draw_vip_shop_menu(screen)
        
        if phone_open:
            draw_phone_menu(screen)

        if xp_open:
            draw_xp_path_menu(screen)
    
        if current_game_state == TASK_MENU_OPEN:
            draw_task_menu(screen)
        
        if current_game_state == FARM_VISIT_MENU:
            draw_visit_farm_menu(screen)

        if box_animation_active:
            draw_box_animation(screen)
            
        if halloween_box_animation_active:
            draw_halloween_box_animation(screen)

        if dog_animation_active:
            draw_dog_animation(screen)

    pygame.display.flip()

pygame.quit()
