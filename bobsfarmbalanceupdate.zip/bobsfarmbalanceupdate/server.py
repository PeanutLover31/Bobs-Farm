from flask import Flask, request, jsonify

app = Flask(__name__)
users = {}  # Basit veritabanı (gerçek projede SQLite kullanın)

@app.route("/")
def home():
    return "Sunucu çalışıyor!"

@app.route("/register", methods=["POST"])
def register():
    data = request.json
    username = data.get("username")
    
    if username in users:
        return jsonify({"error": "Kullanıcı zaten var"}), 400
    users[username] = {"password": data.get("password"), "game_data": {}}
    return jsonify({"success": True})

@app.route("/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")
    
    if username not in users or users[username]["password"] != password:
        return jsonify({"error": "Kullanıcı adı veya şifre hatalı"}), 400
    return jsonify({"success": True})

@app.route("/get_user_data", methods=["GET"])
def get_user_data():
    return jsonify(users)

@app.route("/save_user_data", methods=["POST"])
def save_user_data():
    data = request.json
    username = data.get("username")
    game_data = data.get("game_data")
    
    if username in users:
        users[username]["game_data"] = game_data
        return jsonify({"success": True})
    return jsonify({"error": "Kullanıcı bulunamadı"}), 400

@app.route("/get_farm_data", methods=["GET"])
def get_farm_data():
    username = request.args.get("username")
    if username in users:
        return jsonify(users[username]["game_data"])
    return jsonify({"error": "Kullanıcı bulunamadı"}), 400

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
